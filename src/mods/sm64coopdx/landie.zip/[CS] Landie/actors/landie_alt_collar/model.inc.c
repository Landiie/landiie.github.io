Lights1 landie_alt_collar_Fur__Skin__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x70,
	0xFF, 0xFF, 0xE2, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Cap_No_Cull_lights = gdSPDefLights1(
	0x64, 0x7F, 0x51,
	0xCB, 0xFF, 0xA7, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Cuffs__Gloves__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFE, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Tail__Hair__lights = gdSPDefLights1(
	0x17, 0x17, 0x16,
	0x39, 0x38, 0x37, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Metal__CAP__lights = gdSPDefLights1(
	0xCB, 0xFF, 0xA7,
	0x0, 0x0, 0x0, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Shirt_L__Gloves__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFE, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Collar__Shirt__lights = gdSPDefLights1(
	0x5C, 0x4, 0x8,
	0xBC, 0x12, 0x1B, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Metal_Bell_lights = gdSPDefLights1(
	0xE5, 0xBD, 0x62,
	0x0, 0x0, 0x0, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Collar_Holes__Shirt__lights = gdSPDefLights1(
	0x5C, 0x4, 0x8,
	0xBC, 0x12, 0x1B, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Shirt_Heart__Gloves__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFE, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Bell_Hole_lights = gdSPDefLights1(
	0x0, 0x0, 0x0,
	0x0, 0x0, 0x0, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Hair_lights = gdSPDefLights1(
	0x17, 0x17, 0x16,
	0x39, 0x38, 0x37, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Inner_Ear__Shoes__lights = gdSPDefLights1(
	0x5B, 0x5B, 0x4A,
	0xB9, 0xB9, 0x9A, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Inside_Hair__Eyeless___Skin__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x70,
	0xFF, 0xFF, 0xE2, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Mouth_Neutral__Skin__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x70,
	0xFF, 0xFF, 0xE2, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Fur_Spots__Shoes__lights = gdSPDefLights1(
	0x5B, 0x5B, 0x4A,
	0xB9, 0xB9, 0x9A, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Mouth_Dead__Skin__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x70,
	0xFF, 0xFF, 0xE2, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Cap_lights = gdSPDefLights1(
	0x64, 0x7F, 0x51,
	0xCB, 0xFF, 0xA7, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Gloves_lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFE, 0x28, 0x28, 0x28);

Lights1 landie_alt_collar_Paw_Beans__Gloves__lights = gdSPDefLights1(
	0x7F, 0x7F, 0x7F,
	0xFF, 0xFF, 0xFE, 0x28, 0x28, 0x28);

Gfx landie_alt_collar_Metal_Shade_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_Metal_Shade_rgba16_rgba16[] = {
	#include "actors/landie/Metal_Shade.rgba16.inc.c"
};

Gfx landie_alt_collar_Metal_Light_rgba16_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_Metal_Light_rgba16_rgba16[] = {
	#include "actors/landie/Metal_Light.rgba16.inc.c"
};

Gfx landie_alt_collar_landie_shirt_emblem_ia4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_shirt_emblem_ia4[] = {
	#include "actors/landie/landie_shirt_emblem.ia4.inc.c"
};

Gfx landie_alt_collar_Metal_Shade_rgba16_i4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_Metal_Shade_rgba16_i4[] = {
	#include "actors/landie/Metal_Shade.rgba16.i4.inc.c"
};

Gfx landie_alt_collar_Metal_Light_rgba16_i4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_Metal_Light_rgba16_i4[] = {
	#include "actors/landie/Metal_Light.rgba16.i4.inc.c"
};

Gfx landie_alt_collar_landie_collar_holes_ia4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_collar_holes_ia4[] = {
	#include "actors/landie/landie_collar_holes.ia4.inc.c"
};

Gfx landie_alt_collar_landie_shirt_heart_ia8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_shirt_heart_ia8[] = {
	#include "actors/landie/landie_shirt_heart.ia8.inc.c"
};

Gfx landie_alt_collar_landie_bell_hole_ia4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_bell_hole_ia4[] = {
	#include "actors/landie/landie_bell_hole.ia4.inc.c"
};

Gfx landie_alt_collar_landie_inner_hair_gradient_ia4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_inner_hair_gradient_ia4[] = {
	#include "actors/landie/landie_inner_hair_gradient.ia4.inc.c"
};

Gfx landie_alt_collar_landie_mouth_neutral_ia4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_mouth_neutral_ia4[] = {
	#include "actors/landie/landie_mouth_neutral.ia4.inc.c"
};

Gfx landie_alt_collar_landie_fur_spots_ia8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_fur_spots_ia8[] = {
	#include "actors/landie/landie_fur_spots.ia8.inc.c"
};

Gfx landie_alt_collar_landie_eyes_blink_ci8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_blink_ci8[] = {
	#include "actors/landie/landie_eyes_blink.ci8.inc.c"
};

Gfx landie_alt_collar_landie_eyes_blink_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_blink_pal_rgba16[] = {
	#include "actors/landie/landie_eyes_blink.rgba16.pal"
};

Gfx landie_alt_collar_landie_eyes_closed_ci4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_closed_ci4[] = {
	#include "actors/landie/landie_eyes_closed.ci4.inc.c"
};

Gfx landie_alt_collar_landie_eyes_closed_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_closed_pal_rgba16[] = {
	#include "actors/landie/landie_eyes_closed.rgba16.pal"
};

Gfx landie_alt_collar_landie_eyes_lookLeft_ci8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookLeft_ci8[] = {
	#include "actors/landie/landie_eyes_lookLeft.ci8.inc.c"
};

Gfx landie_alt_collar_landie_eyes_lookLeft_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookLeft_pal_rgba16[] = {
	#include "actors/landie/landie_eyes_lookLeft.rgba16.pal"
};

Gfx landie_alt_collar_landie_eyes_lookRight_ci8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookRight_ci8[] = {
	#include "actors/landie/landie_eyes_lookRight.ci8.inc.c"
};

Gfx landie_alt_collar_landie_eyes_lookRight_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookRight_pal_rgba16[] = {
	#include "actors/landie/landie_eyes_lookRight.rgba16.pal"
};

Gfx landie_alt_collar_landie_eyes_lookUp_ci8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookUp_ci8[] = {
	#include "actors/landie/landie_eyes_lookUp.ci8.inc.c"
};

Gfx landie_alt_collar_landie_eyes_lookUp_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookUp_pal_rgba16[] = {
	#include "actors/landie/landie_eyes_lookUp.rgba16.pal"
};

Gfx landie_alt_collar_landie_eyes_lookDown_ci8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookDown_ci8[] = {
	#include "actors/landie/landie_eyes_lookDown.ci8.inc.c"
};

Gfx landie_alt_collar_landie_eyes_lookDown_pal_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_eyes_lookDown_pal_rgba16[] = {
	#include "actors/landie/landie_eyes_lookDown.rgba16.pal"
};

Gfx landie_alt_collar_landie_mouth_dead_rgba16_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_mouth_dead_rgba16[] = {
	#include "actors/landie/landie_mouth_dead.rgba16.inc.c"
};

Gfx landie_alt_collar_wing_2_ia8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_wing_2_ia8[] = {
	#include "actors/landie/wing_2.ia8.inc.c"
};

Gfx landie_alt_collar_wing1_ia8_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_wing1_ia8[] = {
	#include "actors/landie/wing1.ia8.inc.c"
};

Gfx landie_alt_collar_landie_paw_beans_ia4_aligner[] = {gsSPEndDisplayList()};
u8 landie_alt_collar_landie_paw_beans_ia4[] = {
	#include "actors/landie/landie_paw_beans.ia4.inc.c"
};

Vtx landie_alt_collar_Butt_mesh_layer_1_vtx_0[19] = {
	{{ {-7, 46, 47}, 0, {368, 240}, {180, 80, 64, 255} }},
	{{ {50, 49, 62}, 0, {496, 240}, {236, 92, 86, 255} }},
	{{ {48, 66, 0}, 0, {496, 112}, {244, 126, 0, 255} }},
	{{ {-8, -4, 76}, 0, {368, 368}, {178, 254, 100, 255} }},
	{{ {-29, -7, 0}, 0, {240, 368}, {129, 252, 0, 255} }},
	{{ {-9, 63, 0}, 0, {240, 240}, {181, 103, 0, 255} }},
	{{ {-7, 46, -47}, 0, {368, 240}, {180, 80, 192, 255} }},
	{{ {-8, -4, -76}, 0, {368, 368}, {178, 254, 156, 255} }},
	{{ {50, 49, -62}, 0, {496, 240}, {236, 92, 170, 255} }},
	{{ {-9, 63, 0}, 0, {368, 112}, {181, 103, 0, 255} }},
	{{ {49, -7, -86}, 0, {496, 368}, {227, 249, 132, 255} }},
	{{ {-9, -45, -48}, 0, {368, 496}, {177, 176, 197, 255} }},
	{{ {49, -55, -59}, 0, {496, 496}, {230, 156, 183, 255} }},
	{{ {-10, -59, 0}, 0, {368, 624}, {180, 154, 0, 255} }},
	{{ {49, -66, 0}, 0, {496, 624}, {234, 131, 0, 255} }},
	{{ {49, -55, 59}, 0, {496, 496}, {230, 156, 73, 255} }},
	{{ {-9, -45, 48}, 0, {368, 496}, {177, 176, 59, 255} }},
	{{ {49, -7, 86}, 0, {496, 368}, {227, 249, 124, 255} }},
	{{ {-10, -59, 0}, 0, {240, 496}, {180, 154, 0, 255} }},
};

Gfx landie_alt_collar_Butt_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_0 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 0, 5, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(7, 6, 8, 0, 6, 2, 8, 0),
	gsSP2Triangles(6, 9, 2, 0, 0, 2, 9, 0),
	gsSP2Triangles(7, 8, 10, 0, 11, 7, 10, 0),
	gsSP2Triangles(11, 10, 12, 0, 13, 11, 12, 0),
	gsSP2Triangles(13, 12, 14, 0, 13, 14, 15, 0),
	gsSP2Triangles(13, 15, 16, 0, 16, 15, 17, 0),
	gsSP2Triangles(16, 17, 3, 0, 3, 17, 1, 0),
	gsSP2Triangles(16, 3, 4, 0, 16, 4, 18, 0),
	gsSP2Triangles(11, 18, 4, 0, 11, 4, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Butt_mesh_layer_1_vtx_1[10] = {
	{{ {59, -2, 92}, 0, {496, 368}, {34, 7, 122, 255} }},
	{{ {-1, 55, 83}, 0, {496, 240}, {10, 96, 83, 255} }},
	{{ {0, -4, 107}, 0, {496, 368}, {13, 1, 126, 255} }},
	{{ {29, -58, 83}, 0, {496, 496}, {20, 164, 86, 255} }},
	{{ {55, 72, 0}, 0, {496, 112}, {15, 126, 0, 255} }},
	{{ {0, 73, 0}, 0, {496, 112}, {252, 127, 0, 255} }},
	{{ {-1, 55, -83}, 0, {496, 240}, {10, 96, 173, 255} }},
	{{ {59, -2, -92}, 0, {496, 368}, {34, 7, 134, 255} }},
	{{ {0, -4, -107}, 0, {496, 368}, {13, 1, 130, 255} }},
	{{ {29, -58, -83}, 0, {496, 496}, {20, 164, 170, 255} }},
};

Gfx landie_alt_collar_Butt_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 1, 0, 4, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 7, 9, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Butt_mesh_layer_1_vtx_2[15] = {
	{{ {0, -4, 107}, 0, {496, 368}, {13, 1, 126, 255} }},
	{{ {-33, 54, 83}, 0, {496, 240}, {254, 98, 81, 255} }},
	{{ {-32, -4, 107}, 0, {496, 368}, {0, 7, 127, 255} }},
	{{ {-1, 55, 83}, 0, {496, 240}, {10, 96, 83, 255} }},
	{{ {-31, 70, 0}, 0, {496, 112}, {246, 127, 0, 255} }},
	{{ {0, 73, 0}, 0, {496, 112}, {252, 127, 0, 255} }},
	{{ {-1, 55, -83}, 0, {496, 240}, {10, 96, 173, 255} }},
	{{ {-33, 54, -83}, 0, {496, 240}, {254, 98, 175, 255} }},
	{{ {0, -4, -107}, 0, {496, 368}, {13, 1, 130, 255} }},
	{{ {-32, -4, -107}, 0, {496, 368}, {0, 7, 129, 255} }},
	{{ {-3, -58, -83}, 0, {496, 496}, {0, 170, 162, 255} }},
	{{ {29, -58, -83}, 0, {496, 496}, {20, 164, 170, 255} }},
	{{ {35, -79, 0}, 0, {496, 624}, {19, 130, 0, 255} }},
	{{ {-3, -58, 83}, 0, {496, 496}, {0, 170, 94, 255} }},
	{{ {29, -58, 83}, 0, {496, 496}, {20, 164, 86, 255} }},
};

Gfx landie_alt_collar_Butt_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_2 + 0, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 4, 1, 0, 3, 5, 4, 0),
	gsSP2Triangles(6, 4, 5, 0, 6, 7, 4, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 8, 11, 10, 0),
	gsSP2Triangles(11, 12, 10, 0, 0, 2, 13, 0),
	gsSP2Triangles(0, 13, 14, 0, 14, 13, 12, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Butt_mesh_layer_1_vtx_3[135] = {
	{{ {3, -200, 0}, 0, {502, 403}, {48, 138, 0, 255} }},
	{{ {40, -99, 0}, 0, {624, 280}, {127, 6, 0, 255} }},
	{{ {58, -197, 28}, 0, {624, 416}, {97, 235, 177, 255} }},
	{{ {76, -168, 82}, 0, {752, 416}, {125, 22, 0, 255} }},
	{{ {38, -51, 11}, 0, {752, 240}, {101, 72, 227, 255} }},
	{{ {36, -62, 0}, 0, {678, 240}, {122, 35, 0, 255} }},
	{{ {76, -168, -82}, 0, {752, 416}, {125, 22, 0, 255} }},
	{{ {58, -197, -28}, 0, {624, 416}, {97, 235, 79, 255} }},
	{{ {3, -200, 0}, 0, {502, 410}, {48, 138, 0, 255} }},
	{{ {-1, -270, -29}, 0, {496, 459}, {11, 188, 107, 255} }},
	{{ {-66, -256, -44}, 0, {368, 459}, {175, 206, 84, 255} }},
	{{ {-59, -194, -15}, 0, {368, 416}, {179, 237, 99, 255} }},
	{{ {-98, -224, -96}, 0, {240, 459}, {129, 251, 10, 255} }},
	{{ {-88, -164, -63}, 0, {240, 416}, {135, 26, 27, 255} }},
	{{ {-38, -130, 0}, 0, {368, 327}, {130, 12, 0, 255} }},
	{{ {3, -200, 0}, 0, {496, 402}, {48, 138, 0, 255} }},
	{{ {-26, -50, 0}, 0, {240, 242}, {142, 55, 0, 255} }},
	{{ {-88, -164, 63}, 0, {240, 416}, {135, 26, 229, 255} }},
	{{ {-59, -194, 15}, 0, {368, 416}, {179, 237, 157, 255} }},
	{{ {3, -200, 0}, 0, {498, 413}, {48, 138, 0, 255} }},
	{{ {-66, -256, 44}, 0, {368, 459}, {175, 206, 172, 255} }},
	{{ {-1, -270, 29}, 0, {496, 459}, {11, 188, 149, 255} }},
	{{ {59, -258, 58}, 0, {624, 459}, {96, 205, 191, 255} }},
	{{ {79, -227, 116}, 0, {752, 459}, {126, 248, 17, 255} }},
	{{ {48, -196, 168}, 0, {624, 459}, {81, 37, 91, 255} }},
	{{ {47, -139, 130}, 0, {624, 416}, {81, 66, 72, 255} }},
	{{ {30, -44, 37}, 0, {624, 240}, {74, 95, 40, 255} }},
	{{ {-13, -126, 144}, 0, {496, 416}, {247, 85, 94, 255} }},
	{{ {4, -34, 35}, 0, {496, 240}, {0, 121, 37, 255} }},
	{{ {7, -37, 0}, 0, {496, 128}, {8, 127, 0, 255} }},
	{{ {10, -38, 0}, 0, {512, 128}, {50, 117, 0, 255} }},
	{{ {17, -42, 0}, 0, {536, 112}, {63, 110, 0, 255} }},
	{{ {30, -44, 37}, 0, {624, 240}, {74, 95, 40, 255} }},
	{{ {38, -51, 11}, 0, {624, 112}, {101, 72, 227, 255} }},
	{{ {17, -42, 0}, 0, {536, 112}, {63, 110, 0, 255} }},
	{{ {36, -62, 0}, 0, {624, 186}, {122, 35, 0, 255} }},
	{{ {38, -51, -11}, 0, {624, 112}, {101, 72, 29, 255} }},
	{{ {30, -44, -37}, 0, {624, 240}, {74, 95, 216, 255} }},
	{{ {10, -38, 0}, 0, {512, 128}, {50, 117, 0, 255} }},
	{{ {7, -37, 0}, 0, {496, 128}, {8, 127, 0, 255} }},
	{{ {4, -34, -35}, 0, {496, 240}, {0, 121, 219, 255} }},
	{{ {-13, -126, -144}, 0, {496, 416}, {247, 85, 162, 255} }},
	{{ {47, -139, -130}, 0, {624, 416}, {81, 66, 184, 255} }},
	{{ {38, -51, -11}, 0, {752, 240}, {101, 72, 29, 255} }},
	{{ {76, -168, -82}, 0, {752, 416}, {125, 22, 0, 255} }},
	{{ {36, -62, 0}, 0, {678, 240}, {122, 35, 0, 255} }},
	{{ {48, -196, -168}, 0, {624, 459}, {81, 37, 165, 255} }},
	{{ {-17, -182, -183}, 0, {496, 459}, {245, 56, 143, 255} }},
	{{ {-21, -259, -206}, 0, {496, 496}, {242, 10, 130, 255} }},
	{{ {31, -270, -194}, 0, {624, 496}, {70, 248, 150, 255} }},
	{{ {79, -227, -116}, 0, {752, 459}, {126, 248, 239, 255} }},
	{{ {59, -258, -58}, 0, {624, 459}, {96, 205, 65, 255} }},
	{{ {58, -197, -28}, 0, {624, 416}, {97, 235, 79, 255} }},
	{{ {-1, -270, -29}, 0, {496, 459}, {11, 188, 107, 255} }},
	{{ {-8, -329, -82}, 0, {496, 496}, {6, 153, 73, 255} }},
	{{ {-61, -318, -94}, 0, {368, 496}, {178, 171, 53, 255} }},
	{{ {-66, -256, -44}, 0, {368, 459}, {175, 206, 84, 255} }},
	{{ {-86, -292, -136}, 0, {240, 496}, {138, 211, 243, 255} }},
	{{ {-98, -224, -96}, 0, {240, 459}, {129, 251, 10, 255} }},
	{{ {-77, -193, -154}, 0, {368, 459}, {159, 38, 184, 255} }},
	{{ {-69, -136, -117}, 0, {368, 416}, {163, 68, 203, 255} }},
	{{ {-88, -164, -63}, 0, {240, 416}, {135, 26, 27, 255} }},
	{{ {-26, -50, 0}, 0, {240, 242}, {142, 55, 0, 255} }},
	{{ {-22, -42, -31}, 0, {368, 240}, {181, 100, 233, 255} }},
	{{ {-26, -50, 0}, 0, {240, 242}, {142, 55, 0, 255} }},
	{{ {-25, -49, 0}, 0, {243, 240}, {169, 92, 0, 255} }},
	{{ {-22, -42, -31}, 0, {368, 240}, {181, 100, 233, 255} }},
	{{ {-69, -136, 117}, 0, {368, 416}, {163, 68, 53, 255} }},
	{{ {-88, -164, 63}, 0, {240, 416}, {135, 26, 229, 255} }},
	{{ {-98, -224, 96}, 0, {240, 459}, {129, 251, 246, 255} }},
	{{ {-59, -194, 15}, 0, {368, 416}, {179, 237, 157, 255} }},
	{{ {-66, -256, 44}, 0, {368, 459}, {175, 206, 172, 255} }},
	{{ {-86, -292, 136}, 0, {240, 496}, {138, 211, 13, 255} }},
	{{ {-61, -318, 94}, 0, {368, 496}, {178, 171, 203, 255} }},
	{{ {-1, -270, 29}, 0, {496, 459}, {11, 188, 149, 255} }},
	{{ {-8, -329, 82}, 0, {496, 496}, {6, 153, 183, 255} }},
	{{ {59, -258, 58}, 0, {624, 459}, {96, 205, 191, 255} }},
	{{ {40, -320, 106}, 0, {624, 496}, {84, 167, 221, 255} }},
	{{ {79, -227, 116}, 0, {752, 459}, {126, 248, 17, 255} }},
	{{ {57, -296, 152}, 0, {752, 496}, {110, 207, 39, 255} }},
	{{ {31, -270, 194}, 0, {624, 496}, {70, 248, 106, 255} }},
	{{ {48, -196, 168}, 0, {624, 459}, {81, 37, 91, 255} }},
	{{ {-21, -259, 206}, 0, {496, 496}, {242, 10, 126, 255} }},
	{{ {-17, -182, 183}, 0, {496, 459}, {245, 56, 113, 255} }},
	{{ {47, -139, 130}, 0, {624, 416}, {81, 66, 72, 255} }},
	{{ {-13, -126, 144}, 0, {496, 416}, {247, 85, 94, 255} }},
	{{ {-77, -193, 154}, 0, {368, 459}, {159, 38, 72, 255} }},
	{{ {4, -34, 35}, 0, {496, 240}, {0, 121, 37, 255} }},
	{{ {-22, -42, 31}, 0, {368, 240}, {181, 100, 23, 255} }},
	{{ {7, -37, 0}, 0, {496, 128}, {8, 127, 0, 255} }},
	{{ {3, -38, 0}, 0, {477, 131}, {218, 121, 0, 255} }},
	{{ {4, -34, -35}, 0, {496, 240}, {0, 121, 219, 255} }},
	{{ {-69, -136, -117}, 0, {368, 416}, {163, 68, 203, 255} }},
	{{ {-13, -126, -144}, 0, {496, 416}, {247, 85, 162, 255} }},
	{{ {-77, -193, -154}, 0, {368, 459}, {159, 38, 184, 255} }},
	{{ {-17, -182, -183}, 0, {496, 459}, {245, 56, 143, 255} }},
	{{ {-17, -182, -183}, 0, {496, 459}, {245, 56, 143, 255} }},
	{{ {-13, -126, -144}, 0, {496, 416}, {247, 85, 162, 255} }},
	{{ {47, -139, -130}, 0, {624, 416}, {81, 66, 184, 255} }},
	{{ {-69, -268, -182}, 0, {368, 496}, {164, 251, 169, 255} }},
	{{ {-77, -193, -154}, 0, {368, 459}, {159, 38, 184, 255} }},
	{{ {-86, -292, -136}, 0, {240, 496}, {138, 211, 243, 255} }},
	{{ {-21, -259, -206}, 0, {496, 496}, {242, 10, 130, 255} }},
	{{ {-21, -367, -185}, 0, {496, 624}, {246, 146, 194, 255} }},
	{{ {31, -270, -194}, 0, {624, 496}, {70, 248, 150, 255} }},
	{{ {57, -296, -152}, 0, {624, 624}, {110, 207, 217, 255} }},
	{{ {40, -320, -106}, 0, {624, 496}, {84, 167, 35, 255} }},
	{{ {-8, -329, -82}, 0, {496, 496}, {6, 153, 73, 255} }},
	{{ {59, -258, -58}, 0, {624, 459}, {96, 205, 65, 255} }},
	{{ {79, -227, -116}, 0, {752, 459}, {126, 248, 239, 255} }},
	{{ {57, -296, -152}, 0, {752, 496}, {110, 207, 217, 255} }},
	{{ {-61, -318, -94}, 0, {368, 496}, {178, 171, 53, 255} }},
	{{ {-86, -292, -136}, 0, {368, 624}, {138, 211, 243, 255} }},
	{{ {-69, -136, 117}, 0, {368, 416}, {163, 68, 53, 255} }},
	{{ {-22, -42, 31}, 0, {368, 240}, {181, 100, 23, 255} }},
	{{ {-25, -49, 0}, 0, {243, 240}, {169, 92, 0, 255} }},
	{{ {3, -38, 0}, 0, {477, 131}, {218, 121, 0, 255} }},
	{{ {-25, -49, 0}, 0, {368, 115}, {169, 92, 0, 255} }},
	{{ {-22, -42, -31}, 0, {368, 240}, {181, 100, 233, 255} }},
	{{ {-98, -224, 96}, 0, {240, 459}, {129, 251, 246, 255} }},
	{{ {-77, -193, 154}, 0, {368, 459}, {159, 38, 72, 255} }},
	{{ {-86, -292, 136}, 0, {240, 496}, {138, 211, 13, 255} }},
	{{ {-69, -268, 182}, 0, {368, 496}, {164, 251, 87, 255} }},
	{{ {-17, -182, 183}, 0, {496, 459}, {245, 56, 113, 255} }},
	{{ {-21, -259, 206}, 0, {496, 496}, {242, 10, 126, 255} }},
	{{ {-21, -367, 185}, 0, {496, 624}, {246, 146, 62, 255} }},
	{{ {-86, -292, 136}, 0, {368, 624}, {138, 211, 13, 255} }},
	{{ {-61, -318, 94}, 0, {368, 496}, {178, 171, 203, 255} }},
	{{ {-21, -367, 185}, 0, {496, 624}, {246, 146, 62, 255} }},
	{{ {-61, -318, 94}, 0, {368, 496}, {178, 171, 203, 255} }},
	{{ {-8, -329, 82}, 0, {496, 496}, {6, 153, 183, 255} }},
	{{ {40, -320, 106}, 0, {624, 496}, {84, 167, 221, 255} }},
	{{ {57, -296, 152}, 0, {624, 624}, {110, 207, 39, 255} }},
	{{ {31, -270, 194}, 0, {624, 496}, {70, 248, 106, 255} }},
	{{ {-21, -259, 206}, 0, {496, 496}, {242, 10, 126, 255} }},
};

Gfx landie_alt_collar_Butt_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_3 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
	gsSP2Triangles(1, 4, 3, 0, 1, 5, 4, 0),
	gsSP2Triangles(6, 5, 1, 0, 1, 7, 6, 0),
	gsSP2Triangles(8, 7, 1, 0, 9, 7, 8, 0),
	gsSP2Triangles(10, 9, 8, 0, 10, 8, 11, 0),
	gsSP2Triangles(12, 10, 11, 0, 12, 11, 13, 0),
	gsSP2Triangles(13, 11, 14, 0, 11, 15, 14, 0),
	gsSP2Triangles(13, 14, 16, 0, 17, 16, 14, 0),
	gsSP2Triangles(17, 14, 18, 0, 18, 14, 19, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 19, 21, 0),
	gsSP2Triangles(21, 19, 2, 0, 21, 2, 22, 0),
	gsSP2Triangles(22, 2, 3, 0, 22, 3, 23, 0),
	gsSP2Triangles(24, 23, 3, 0, 24, 3, 25, 0),
	gsSP2Triangles(25, 3, 4, 0, 25, 4, 26, 0),
	gsSP2Triangles(27, 25, 26, 0, 27, 26, 28, 0),
	gsSP2Triangles(26, 29, 28, 0, 26, 30, 29, 0),
	gsSP1Triangle(26, 31, 30, 0),
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_3 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
	gsSP2Triangles(3, 4, 2, 0, 5, 2, 4, 0),
	gsSP2Triangles(5, 6, 2, 0, 5, 7, 6, 0),
	gsSP2Triangles(5, 8, 7, 0, 9, 8, 5, 0),
	gsSP2Triangles(9, 5, 10, 0, 10, 5, 11, 0),
	gsSP2Triangles(10, 11, 12, 0, 12, 11, 13, 0),
	gsSP2Triangles(14, 10, 12, 0, 15, 10, 14, 0),
	gsSP2Triangles(16, 15, 14, 0, 16, 14, 17, 0),
	gsSP2Triangles(17, 14, 18, 0, 14, 12, 18, 0),
	gsSP2Triangles(19, 18, 12, 0, 19, 12, 20, 0),
	gsSP2Triangles(21, 19, 20, 0, 22, 19, 21, 0),
	gsSP2Triangles(23, 22, 21, 0, 23, 21, 24, 0),
	gsSP2Triangles(25, 23, 24, 0, 25, 24, 26, 0),
	gsSP2Triangles(25, 26, 27, 0, 26, 28, 27, 0),
	gsSP2Triangles(26, 29, 28, 0, 28, 29, 30, 0),
	gsSP1Triangle(30, 31, 28, 0),
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_3 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(0, 4, 3, 0, 5, 3, 4, 0),
	gsSP2Triangles(5, 4, 6, 0, 5, 6, 7, 0),
	gsSP2Triangles(8, 5, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(9, 7, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSP2Triangles(13, 12, 14, 0, 13, 14, 15, 0),
	gsSP2Triangles(16, 15, 14, 0, 16, 14, 17, 0),
	gsSP2Triangles(18, 16, 17, 0, 18, 17, 19, 0),
	gsSP2Triangles(19, 17, 20, 0, 19, 20, 21, 0),
	gsSP2Triangles(22, 19, 21, 0, 22, 21, 3, 0),
	gsSP2Triangles(3, 21, 23, 0, 3, 23, 24, 0),
	gsSP2Triangles(24, 23, 25, 0, 24, 25, 26, 0),
	gsSP2Triangles(2, 26, 25, 0, 2, 25, 27, 0),
	gsSP2Triangles(28, 2, 27, 0, 28, 27, 29, 0),
	gsSP2Triangles(30, 28, 29, 0, 30, 29, 31, 0),
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_3 + 96, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 0, 0),
	gsSP2Triangles(5, 4, 3, 0, 3, 0, 6, 0),
	gsSP2Triangles(7, 3, 6, 0, 7, 6, 8, 0),
	gsSP2Triangles(7, 8, 9, 0, 7, 9, 10, 0),
	gsSP2Triangles(7, 10, 11, 0, 11, 10, 12, 0),
	gsSP2Triangles(10, 13, 12, 0, 10, 14, 13, 0),
	gsSP2Triangles(8, 13, 14, 0, 7, 11, 15, 0),
	gsSP2Triangles(7, 15, 16, 0, 7, 16, 3, 0),
	gsSP2Triangles(17, 18, 19, 0, 18, 20, 21, 0),
	gsSP2Triangles(22, 21, 20, 0, 23, 24, 17, 0),
	gsSP2Triangles(25, 24, 23, 0, 25, 26, 24, 0),
	gsSP2Triangles(26, 27, 24, 0, 26, 28, 27, 0),
	gsSP2Triangles(29, 28, 26, 0, 29, 26, 30, 0),
	gsSP1Triangle(29, 30, 31, 0),
	gsSPVertex(landie_alt_collar_Butt_mesh_layer_1_vtx_3 + 128, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(0, 3, 4, 0, 0, 4, 5, 0),
	gsSP1Triangle(0, 5, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_skinned_mesh_layer_1_vtx_0[7] = {
	{{ {59, -2, 92}, 0, {496, 368}, {34, 7, 122, 255} }},
	{{ {55, 72, 0}, 0, {496, 112}, {15, 126, 0, 255} }},
	{{ {29, -58, 83}, 0, {496, 496}, {20, 164, 86, 255} }},
	{{ {-1, 55, 83}, 0, {496, 240}, {10, 96, 83, 255} }},
	{{ {29, -58, -83}, 0, {496, 496}, {20, 164, 170, 255} }},
	{{ {59, -2, -92}, 0, {496, 368}, {34, 7, 134, 255} }},
	{{ {-1, 55, -83}, 0, {496, 240}, {10, 96, 173, 255} }},
};

Gfx landie_alt_collar_Torso_skinned_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Torso_skinned_mesh_layer_1_vtx_0 + 0, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_skinned_mesh_layer_1_vtx_1[3] = {
	{{ {29, -58, 83}, 0, {496, 496}, {20, 164, 86, 255} }},
	{{ {35, -79, 0}, 0, {496, 624}, {19, 130, 0, 255} }},
	{{ {29, -58, -83}, 0, {496, 496}, {20, 164, 170, 255} }},
};

Gfx landie_alt_collar_Torso_skinned_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Torso_skinned_mesh_layer_1_vtx_1 + 0, 3, 7),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_1_vtx_0[10] = {
	{{ {13, -52, 66}, 0, {496, 496}, {34, 164, 81, 255} }},
	{{ {-1, -73, 0}, 0, {496, 624}, {24, 131, 0, 255} }},
	{{ {45, -2, 78}, 0, {496, 368}, {37, 3, 121, 255} }},
	{{ {-12, 53, 66}, 0, {496, 240}, {27, 97, 78, 255} }},
	{{ {45, 45, 56}, 0, {496, 240}, {30, 94, 80, 255} }},
	{{ {45, 62, 0}, 0, {496, 112}, {29, 124, 0, 255} }},
	{{ {45, 45, -56}, 0, {496, 240}, {25, 119, 220, 255} }},
	{{ {-12, 53, -66}, 0, {496, 240}, {27, 97, 178, 255} }},
	{{ {45, -2, -78}, 0, {496, 368}, {37, 3, 135, 255} }},
	{{ {13, -52, -66}, 0, {496, 496}, {34, 164, 175, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_0 + 0, 10, 10),
	gsSP2Triangles(0, 2, 10, 0, 10, 2, 11, 0),
	gsSP2Triangles(12, 0, 10, 0, 12, 13, 0, 0),
	gsSP2Triangles(0, 13, 3, 0, 1, 3, 13, 0),
	gsSP2Triangles(14, 1, 13, 0, 14, 15, 1, 0),
	gsSP2Triangles(16, 1, 15, 0, 16, 17, 1, 0),
	gsSP2Triangles(1, 17, 6, 0, 5, 6, 17, 0),
	gsSP2Triangles(18, 5, 17, 0, 18, 19, 5, 0),
	gsSP2Triangles(5, 19, 4, 0, 19, 11, 4, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_1_vtx_1[1] = {
	{{ {-1, -73, 0}, 0, {496, 624}, {24, 131, 0, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_1 + 0, 1, 10),
	gsSP2Triangles(7, 8, 10, 0, 9, 10, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_1_vtx_2[28] = {
	{{ {45, -2, 78}, 0, {496, 368}, {37, 3, 121, 255} }},
	{{ {13, -52, 66}, 0, {496, 496}, {34, 164, 81, 255} }},
	{{ {49, -47, 56}, 0, {496, 496}, {38, 211, 112, 255} }},
	{{ {96, -2, 56}, 0, {624, 368}, {83, 0, 96, 255} }},
	{{ {98, -39, 46}, 0, {624, 496}, {92, 217, 78, 255} }},
	{{ {93, 36, 46}, 0, {624, 240}, {76, 77, 67, 255} }},
	{{ {45, 45, 56}, 0, {496, 240}, {30, 94, 80, 255} }},
	{{ {45, 62, 0}, 0, {496, 112}, {29, 124, 0, 255} }},
	{{ {93, 44, 0}, 0, {624, 112}, {77, 101, 0, 255} }},
	{{ {93, 36, -46}, 0, {624, 240}, {35, 118, 227, 255} }},
	{{ {45, 45, -56}, 0, {496, 240}, {25, 119, 220, 255} }},
	{{ {-12, 53, 66}, 0, {496, 240}, {27, 97, 78, 255} }},
	{{ {45, -2, -78}, 0, {496, 368}, {37, 3, 135, 255} }},
	{{ {49, -47, -56}, 0, {496, 496}, {38, 211, 144, 255} }},
	{{ {13, -52, -66}, 0, {496, 496}, {34, 164, 175, 255} }},
	{{ {96, -2, -56}, 0, {624, 368}, {83, 0, 160, 255} }},
	{{ {93, 36, -46}, 0, {624, 240}, {88, 47, 178, 255} }},
	{{ {45, 45, -56}, 0, {496, 240}, {30, 52, 144, 255} }},
	{{ {-12, 53, -66}, 0, {496, 240}, {27, 97, 178, 255} }},
	{{ {98, -39, -46}, 0, {624, 496}, {92, 217, 178, 255} }},
	{{ {56, -61, 0}, 0, {496, 624}, {31, 133, 0, 255} }},
	{{ {98, -39, 46}, 0, {624, 496}, {31, 136, 28, 255} }},
	{{ {49, -47, 56}, 0, {496, 496}, {26, 136, 33, 255} }},
	{{ {98, -47, 0}, 0, {624, 624}, {39, 135, 0, 255} }},
	{{ {98, -39, -46}, 0, {624, 496}, {31, 136, 228, 255} }},
	{{ {49, -47, -56}, 0, {496, 496}, {26, 136, 223, 255} }},
	{{ {34, -66, 0}, 0, {496, 624}, {27, 132, 0, 255} }},
	{{ {-1, -73, 0}, 0, {496, 624}, {24, 131, 0, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_2 + 0, 28, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(2, 4, 3, 0, 0, 3, 5, 0),
	gsSP2Triangles(0, 5, 6, 0, 5, 7, 6, 0),
	gsSP2Triangles(5, 8, 7, 0, 9, 7, 8, 0),
	gsSP2Triangles(9, 10, 7, 0, 0, 6, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 13, 12, 15, 0),
	gsSP2Triangles(12, 16, 15, 0, 12, 17, 16, 0),
	gsSP2Triangles(12, 18, 17, 0, 13, 15, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 23, 21, 0),
	gsSP2Triangles(20, 24, 23, 0, 20, 25, 24, 0),
	gsSP2Triangles(25, 20, 26, 0, 22, 26, 20, 0),
	gsSP2Triangles(22, 1, 26, 0, 1, 27, 26, 0),
	gsSP2Triangles(14, 26, 27, 0, 25, 26, 14, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_1_vtx_3[9] = {
	{{ {122, -2, 0}, 0, {752, 368}, {127, 5, 0, 255} }},
	{{ {93, 36, 46}, 0, {624, 240}, {76, 77, 67, 255} }},
	{{ {96, -2, 56}, 0, {624, 368}, {83, 0, 96, 255} }},
	{{ {93, 44, 0}, 0, {752, 240}, {77, 101, 0, 255} }},
	{{ {93, 36, -46}, 0, {624, 240}, {88, 47, 178, 255} }},
	{{ {96, -2, -56}, 0, {624, 368}, {83, 0, 160, 255} }},
	{{ {98, -39, -46}, 0, {624, 496}, {92, 217, 178, 255} }},
	{{ {98, -47, 0}, 0, {752, 496}, {113, 197, 0, 255} }},
	{{ {98, -39, 46}, 0, {624, 496}, {92, 217, 78, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_3 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 0, 5, 4, 0),
	gsSP2Triangles(6, 5, 0, 0, 6, 0, 7, 0),
	gsSP2Triangles(8, 7, 0, 0, 8, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_1_vtx_4[19] = {
	{{ {88, 56, 50}, 0, {624, 112}, {250, 125, 24, 255} }},
	{{ {58, 55, 50}, 0, {496, 112}, {250, 125, 22, 255} }},
	{{ {76, 53, 57}, 0, {624, 112}, {251, 116, 51, 255} }},
	{{ {94, 58, 10}, 0, {624, 138}, {251, 119, 43, 255} }},
	{{ {61, 57, 10}, 0, {496, 138}, {249, 120, 42, 255} }},
	{{ {64, 42, 52}, 0, {496, 240}, {0, 95, 84, 255} }},
	{{ {96, 44, 50}, 0, {624, 240}, {1, 93, 86, 255} }},
	{{ {69, 0, 72}, 0, {496, 368}, {12, 3, 126, 255} }},
	{{ {101, 3, 69}, 0, {624, 368}, {12, 0, 126, 255} }},
	{{ {75, -43, 52}, 0, {496, 496}, {17, 164, 85, 255} }},
	{{ {106, -38, 50}, 0, {624, 496}, {17, 163, 85, 255} }},
	{{ {77, -60, 0}, 0, {496, 624}, {17, 130, 0, 255} }},
	{{ {108, -56, 0}, 0, {624, 624}, {17, 130, 0, 255} }},
	{{ {106, -38, -50}, 0, {624, 496}, {17, 163, 171, 255} }},
	{{ {75, -43, -52}, 0, {496, 496}, {17, 164, 171, 255} }},
	{{ {101, 3, -69}, 0, {624, 368}, {12, 0, 130, 255} }},
	{{ {69, 0, -72}, 0, {496, 368}, {12, 3, 130, 255} }},
	{{ {96, 44, -50}, 0, {624, 240}, {1, 94, 170, 255} }},
	{{ {64, 42, -52}, 0, {496, 240}, {0, 95, 172, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_1_tri_4[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_4 + 0, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 5, 6, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 8, 7, 0),
	gsSP2Triangles(9, 10, 8, 0, 11, 10, 9, 0),
	gsSP2Triangles(11, 12, 10, 0, 11, 13, 12, 0),
	gsSP2Triangles(11, 14, 13, 0, 14, 15, 13, 0),
	gsSP2Triangles(14, 16, 15, 0, 16, 17, 15, 0),
	gsSP1Triangle(16, 18, 17, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_1_vtx_5[37] = {
	{{ {44, 93, -13}, 0, {577, 495}, {200, 101, 203, 255} }},
	{{ {31, 70, -20}, 0, {577, 239}, {154, 26, 185, 255} }},
	{{ {22, 88, -1}, 0, {508, 461}, {147, 66, 252, 255} }},
	{{ {37, 90, 16}, 0, {577, -273}, {182, 90, 50, 255} }},
	{{ {44, 93, -13}, 0, {577, -529}, {200, 101, 203, 255} }},
	{{ {22, 88, -1}, 0, {508, -286}, {147, 66, 252, 255} }},
	{{ {24, 67, 5}, 0, {577, 18}, {131, 248, 18, 255} }},
	{{ {22, 88, -1}, 0, {508, 239}, {147, 66, 252, 255} }},
	{{ {22, 88, -1}, 0, {508, 5}, {147, 66, 252, 255} }},
	{{ {94, 58, -10}, 0, {1020, -375}, {251, 119, 212, 255} }},
	{{ {60, 61, 0}, 0, {764, -401}, {250, 119, 212, 255} }},
	{{ {93, 62, 0}, 0, {1020, -401}, {250, 119, 212, 255} }},
	{{ {61, 57, -10}, 0, {764, -375}, {251, 119, 212, 255} }},
	{{ {61, 82, -16}, 0, {1020, 495}, {93, 38, 178, 255} }},
	{{ {31, 70, -20}, 0, {577, 239}, {217, 210, 145, 255} }},
	{{ {44, 93, -13}, 0, {577, 495}, {42, 99, 188, 255} }},
	{{ {44, 56, -17}, 0, {1020, 239}, {1, 155, 179, 255} }},
	{{ {62, 60, 1}, 0, {1020, 239}, {99, 178, 15, 255} }},
	{{ {24, 67, 5}, 0, {577, 18}, {176, 171, 51, 255} }},
	{{ {42, 60, 14}, 0, {1020, -17}, {247, 170, 93, 255} }},
	{{ {62, 60, 1}, 0, {1020, -17}, {99, 178, 15, 255} }},
	{{ {37, 90, 16}, 0, {577, -273}, {6, 58, 113, 255} }},
	{{ {59, 86, 13}, 0, {1020, -273}, {87, 55, 75, 255} }},
	{{ {62, 60, 1}, 0, {1020, -273}, {99, 178, 15, 255} }},
	{{ {44, 93, -13}, 0, {577, -529}, {42, 99, 188, 255} }},
	{{ {61, 82, -16}, 0, {1020, -529}, {93, 38, 178, 255} }},
	{{ {62, 60, 1}, 0, {1020, -529}, {99, 178, 15, 255} }},
	{{ {94, 58, 10}, 0, {1020, -375}, {93, 193, 60, 255} }},
	{{ {60, 61, 0}, 0, {764, -401}, {185, 21, 153, 255} }},
	{{ {93, 62, 0}, 0, {1020, -401}, {68, 29, 153, 255} }},
	{{ {61, 57, 10}, 0, {764, -375}, {206, 160, 67, 255} }},
	{{ {92, 61, 10}, 0, {1020, -401}, {44, 87, 81, 255} }},
	{{ {93, 62, 0}, 0, {1020, -401}, {68, 29, 153, 255} }},
	{{ {59, 59, 10}, 0, {764, -401}, {163, 52, 70, 255} }},
	{{ {92, 61, 10}, 0, {1020, -401}, {44, 87, 81, 255} }},
	{{ {60, 61, 0}, 0, {764, -401}, {185, 21, 153, 255} }},
	{{ {61, 57, 10}, 0, {764, -375}, {206, 160, 67, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_1_tri_5[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_5 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(1, 6, 7, 0, 6, 3, 8, 0),
	gsSP2Triangles(9, 10, 11, 0, 9, 12, 10, 0),
	gsSP2Triangles(13, 14, 15, 0, 13, 16, 14, 0),
	gsSP2Triangles(16, 13, 17, 0, 16, 18, 14, 0),
	gsSP2Triangles(16, 19, 18, 0, 19, 16, 20, 0),
	gsSP2Triangles(19, 21, 18, 0, 19, 22, 21, 0),
	gsSP2Triangles(22, 19, 23, 0, 22, 24, 21, 0),
	gsSP2Triangles(22, 25, 24, 0, 25, 22, 26, 0),
	gsSP2Triangles(27, 28, 29, 0, 27, 30, 28, 0),
	gsSP2Triangles(30, 27, 31, 0, 27, 29, 31, 0),
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_5 + 32, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 1, 3, 0, 4, 2, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_1_vtx_6[8] = {
	{{ {92, 61, 10}, 0, {-16, -16}, {250, 126, 14, 255} }},
	{{ {59, 59, 10}, 0, {-16, 496}, {250, 126, 14, 255} }},
	{{ {58, 55, 50}, 0, {496, 496}, {250, 125, 22, 255} }},
	{{ {88, 56, 50}, 0, {496, -16}, {250, 125, 24, 255} }},
	{{ {96, 44, -50}, 0, {496, -16}, {1, 94, 170, 255} }},
	{{ {64, 42, -52}, 0, {496, 496}, {0, 95, 172, 255} }},
	{{ {61, 57, -10}, 0, {-16, 496}, {251, 119, 212, 255} }},
	{{ {94, 58, -10}, 0, {-16, -16}, {251, 119, 212, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_1_tri_6[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_1_vtx_6 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_skinned_mesh_layer_5_vtx_0[1] = {
	{{ {55, 72, 0}, 0, {496, 910}, {23, 125, 0, 255} }},
};

Gfx landie_alt_collar_Torso_skinned_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Torso_skinned_mesh_layer_5_vtx_0 + 0, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_5_vtx_0[5] = {
	{{ {45, 45, 56}, 0, {927, 453}, {22, 120, 36, 255} }},
	{{ {-12, 53, 66}, 0, {1008, 881}, {23, 120, 35, 255} }},
	{{ {45, 62, 0}, 0, {496, 482}, {26, 124, 247, 255} }},
	{{ {45, 45, -56}, 0, {64, 453}, {25, 119, 220, 255} }},
	{{ {-12, 53, -66}, 0, {-16, 881}, {23, 120, 221, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_5_vtx_0 + 0, 5, 1),
	gsSP2Triangles(1, 0, 2, 0, 1, 3, 0, 0),
	gsSP2Triangles(4, 0, 3, 0, 4, 5, 0, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_5_vtx_1[10] = {
	{{ {56, -61, 0}, 0, {0, 423}, {31, 133, 0, 255} }},
	{{ {98, -39, 46}, 0, {480, -16}, {32, 136, 28, 255} }},
	{{ {49, -47, 56}, 0, {480, 565}, {26, 136, 33, 255} }},
	{{ {98, -47, 0}, 0, {0, -16}, {39, 135, 0, 255} }},
	{{ {98, -39, -46}, 0, {480, -16}, {32, 136, 228, 255} }},
	{{ {49, -47, -56}, 0, {480, 565}, {26, 136, 223, 255} }},
	{{ {34, -66, 0}, 0, {0, 646}, {27, 132, 0, 255} }},
	{{ {13, -52, 66}, 0, {480, 1008}, {24, 136, 34, 255} }},
	{{ {-1, -73, 0}, 0, {0, 1008}, {25, 131, 0, 255} }},
	{{ {13, -52, -66}, 0, {480, 1008}, {24, 136, 222, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_5_tri_1[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_5_vtx_1 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 0, 5, 4, 0),
	gsSP2Triangles(5, 0, 6, 0, 2, 6, 0, 0),
	gsSP2Triangles(2, 7, 6, 0, 7, 8, 6, 0),
	gsSP2Triangles(9, 6, 8, 0, 5, 6, 9, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_5_vtx_2[4] = {
	{{ {93, 36, -46}, 0, {144, 82}, {36, 118, 227, 255} }},
	{{ {45, 62, 0}, 0, {496, 482}, {26, 124, 247, 255} }},
	{{ {93, 44, 0}, 0, {496, 102}, {44, 118, 236, 255} }},
	{{ {45, 45, -56}, 0, {64, 453}, {25, 119, 220, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_5_tri_2[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_5_vtx_2 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Torso_mesh_layer_5_vtx_3[5] = {
	{{ {37, 90, 16}, 0, {25, 482}, {182, 90, 50, 255} }},
	{{ {44, 93, -13}, 0, {434, 496}, {200, 101, 203, 255} }},
	{{ {22, 88, -1}, 0, {249, 226}, {147, 66, 252, 255} }},
	{{ {31, 70, -20}, 0, {476, -16}, {154, 26, 184, 255} }},
	{{ {24, 67, 5}, 0, {76, -16}, {131, 248, 19, 255} }},
};

Gfx landie_alt_collar_Torso_mesh_layer_5_tri_3[] = {
	gsSPVertex(landie_alt_collar_Torso_mesh_layer_5_vtx_3 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(3, 4, 2, 0, 4, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_DL_mesh_layer_1_vtx_0[28] = {
	{{ {170, 52, 90}, 0, {381, 266}, {9, 96, 83, 255} }},
	{{ {212, 86, 0}, 0, {432, 112}, {11, 117, 49, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {11, 117, 49, 255} }},
	{{ {204, 48, 92}, 0, {432, 266}, {9, 96, 83, 255} }},
	{{ {156, -11, 130}, 0, {381, 368}, {244, 8, 126, 255} }},
	{{ {189, -20, 132}, 0, {432, 368}, {244, 6, 126, 255} }},
	{{ {136, -94, 84}, 0, {381, 522}, {214, 168, 81, 255} }},
	{{ {168, -108, 86}, 0, {432, 522}, {213, 165, 78, 255} }},
	{{ {130, -117, 0}, 0, {381, 624}, {202, 141, 0, 255} }},
	{{ {162, -132, 0}, 0, {432, 624}, {202, 141, 0, 255} }},
	{{ {168, -108, -86}, 0, {432, 522}, {213, 165, 178, 255} }},
	{{ {136, -94, -84}, 0, {381, 522}, {214, 168, 175, 255} }},
	{{ {189, -20, -132}, 0, {432, 368}, {244, 6, 130, 255} }},
	{{ {156, -11, -130}, 0, {381, 368}, {244, 8, 130, 255} }},
	{{ {204, 48, -92}, 0, {432, 266}, {9, 96, 173, 255} }},
	{{ {170, 52, -90}, 0, {381, 266}, {9, 96, 173, 255} }},
	{{ {212, 86, 0}, 0, {432, 112}, {11, 117, 207, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {11, 117, 207, 255} }},
	{{ {170, 52, 90}, 0, {381, 266}, {96, 54, 64, 255} }},
	{{ {292, -57, 0}, 0, {-16, 1008}, {122, 222, 0, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {95, 75, 38, 255} }},
	{{ {156, -11, 130}, 0, {381, 368}, {84, 241, 94, 255} }},
	{{ {136, -94, 84}, 0, {381, 522}, {57, 163, 65, 255} }},
	{{ {130, -117, 0}, 0, {381, 624}, {44, 137, 0, 255} }},
	{{ {136, -94, -84}, 0, {381, 522}, {57, 163, 191, 255} }},
	{{ {156, -11, -130}, 0, {381, 368}, {84, 241, 162, 255} }},
	{{ {170, 52, -90}, 0, {381, 266}, {96, 54, 192, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {95, 75, 218, 255} }},
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_0 + 0, 28, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 7, 5, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 8, 11, 10, 0),
	gsSP2Triangles(11, 12, 10, 0, 11, 13, 12, 0),
	gsSP2Triangles(13, 14, 12, 0, 13, 15, 14, 0),
	gsSP2Triangles(15, 16, 14, 0, 15, 17, 16, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 19, 18, 0),
	gsSP2Triangles(22, 19, 21, 0, 23, 19, 22, 0),
	gsSP2Triangles(23, 24, 19, 0, 24, 25, 19, 0),
	gsSP2Triangles(25, 26, 19, 0, 26, 27, 19, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_DL_mesh_layer_1_vtx_1[53] = {
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {11, 52, 64}, 0, {368, 240}, {156, 49, 61, 255} }},
	{{ {7, 33, 106}, 0, {496, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {368, 240}, {227, 47, 114, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 104, 70, 255} }},
	{{ {56, 62, 116}, 0, {496, 240}, {227, 47, 114, 255} }},
	{{ {68, 106, 44}, 0, {496, 192}, {16, 99, 78, 255} }},
	{{ {25, 98, 38}, 0, {337, 208}, {189, 85, 67, 255} }},
	{{ {1, 76, 0}, 0, {240, 240}, {135, 40, 0, 255} }},
	{{ {20, 111, 0}, 0, {240, 240}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {337, 208}, {189, 85, 189, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {68, 106, -44}, 0, {496, 192}, {16, 99, 178, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 104, 186, 255} }},
	{{ {56, 62, -116}, 0, {496, 240}, {227, 47, 142, 255} }},
	{{ {-7, -12, 0}, 0, {240, 368}, {130, 237, 0, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {151, 1, 185, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 240}, {176, 46, 168, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {108, -76, -158}, 0, {368, 496}, {46, 179, 166, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {7, 33, 106}, 0, {368, 240}, {176, 46, 88, 255} }},
	{{ {7, 33, 106}, 0, {368, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {496, 368}, {227, 47, 114, 255} }},
	{{ {100, 98, 0}, 0, {496, 112}, {62, 111, 0, 255} }},
	{{ {72, 127, 0}, 0, {496, 112}, {32, 123, 0, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {7, 33, -106}, 0, {496, 368}, {176, 46, 168, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {56, 62, -116}, 0, {368, 240}, {227, 47, 142, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 368}, {176, 46, 168, 255} }},
	{{ {56, 62, -116}, 0, {496, 368}, {227, 47, 142, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 104, 186, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {107, -76, 158}, 0, {368, 496}, {46, 179, 90, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {153, -68, 70}, 0, {624, 496}, {98, 189, 46, 255} }},
	{{ {107, -76, 158}, 0, {496, 496}, {46, 179, 90, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {108, -76, -158}, 0, {496, 496}, {46, 179, 166, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 189, 210, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_1 + 0, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(4, 1, 5, 0, 1, 4, 6, 0),
	gsSP2Triangles(1, 6, 7, 0, 8, 1, 7, 0),
	gsSP2Triangles(8, 7, 9, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 10, 11, 0, 11, 10, 12, 0),
	gsSP2Triangles(11, 12, 13, 0, 13, 14, 11, 0),
	gsSP2Triangles(15, 8, 11, 0, 15, 1, 8, 0),
	gsSP2Triangles(15, 16, 1, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 18, 15, 0),
	gsSP2Triangles(19, 15, 20, 0, 15, 11, 20, 0),
	gsSP2Triangles(11, 21, 20, 0, 19, 20, 22, 0),
	gsSP2Triangles(19, 22, 23, 0, 23, 22, 24, 0),
	gsSP2Triangles(19, 23, 25, 0, 1, 16, 26, 0),
	gsSP2Triangles(16, 0, 27, 0, 0, 4, 28, 0),
	gsSP2Triangles(29, 30, 6, 0, 29, 12, 30, 0),
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_1 + 31, 22, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(4, 5, 0, 0, 0, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(8, 12, 11, 0, 11, 13, 9, 0),
	gsSP2Triangles(12, 14, 15, 0, 16, 15, 14, 0),
	gsSP2Triangles(16, 13, 15, 0, 17, 18, 19, 0),
	gsSP2Triangles(20, 19, 18, 0, 20, 18, 21, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_DL_mesh_layer_1_vtx_2[110] = {
	{{ {153, -68, 70}, 0, {624, 496}, {98, 189, 46, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {124, -104, 105}, 0, {624, 496}, {9, 195, 111, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {232, 9, 124, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 104, 70, 255} }},
	{{ {87, 36, 125}, 0, {624, 240}, {189, 4, 108, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {87, 36, 125}, 0, {496, 240}, {189, 4, 108, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 189, 210, 255} }},
	{{ {124, -104, -105}, 0, {624, 496}, {9, 195, 145, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {232, 9, 132, 255} }},
	{{ {87, 36, -125}, 0, {624, 240}, {189, 4, 148, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 104, 186, 255} }},
	{{ {87, 36, -125}, 0, {496, 240}, {189, 4, 148, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {152, 20, 132}, 0, {624, 240}, {35, 9, 122, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {101, 47, 62, 255} }},
	{{ {108, 41, 111}, 0, {496, 368}, {232, 9, 124, 255} }},
	{{ {87, 36, 125}, 0, {496, 368}, {189, 4, 108, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {152, 20, 132}, 0, {624, 368}, {35, 9, 122, 255} }},
	{{ {220, -5, 0}, 0, {752, 368}, {127, 252, 0, 255} }},
	{{ {184, -86, 0}, 0, {752, 496}, {95, 171, 0, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {101, 47, 194, 255} }},
	{{ {152, 20, -132}, 0, {624, 368}, {35, 9, 134, 255} }},
	{{ {182, 77, 0}, 0, {752, 240}, {91, 89, 0, 255} }},
	{{ {132, -114, 0}, 0, {496, 624}, {55, 141, 0, 255} }},
	{{ {124, -104, 105}, 0, {496, 624}, {9, 195, 111, 255} }},
	{{ {184, -86, 0}, 0, {624, 624}, {95, 171, 0, 255} }},
	{{ {124, -104, -105}, 0, {496, 624}, {9, 195, 145, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {132, -114, 0}, 0, {496, 624}, {55, 141, 0, 255} }},
	{{ {124, -104, 105}, 0, {501, 496}, {9, 195, 111, 255} }},
	{{ {84, -107, 125}, 0, {496, 624}, {6, 204, 116, 255} }},
	{{ {51, -135, 0}, 0, {496, 624}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {496, 624}, {6, 204, 140, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {124, -104, -105}, 0, {501, 496}, {9, 195, 145, 255} }},
	{{ {95, -83, 116}, 0, {368, 496}, {51, 87, 77, 255} }},
	{{ {84, -107, 125}, 0, {501, 496}, {6, 204, 116, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {84, -107, 125}, 0, {368, 496}, {6, 204, 116, 255} }},
	{{ {-14, -96, 48}, 0, {496, 624}, {135, 248, 38, 255} }},
	{{ {43, -118, 0}, 0, {496, 624}, {173, 160, 0, 255} }},
	{{ {51, -135, 0}, 0, {368, 496}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {368, 496}, {6, 204, 140, 255} }},
	{{ {-14, -96, -48}, 0, {496, 624}, {135, 248, 218, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {151, 1, 185, 255} }},
	{{ {95, -83, -116}, 0, {368, 496}, {51, 87, 179, 255} }},
	{{ {84, -107, -125}, 0, {501, 496}, {6, 204, 140, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {152, 20, 132}, 0, {496, 368}, {35, 9, 122, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {51, 98, 62, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {50, 98, 63, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {50, 98, 63, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {51, 98, 62, 255} }},
	{{ {119, 100, 0}, 0, {542, 194}, {36, 122, 0, 255} }},
	{{ {77, 100, 49}, 0, {542, 194}, {66, 92, 57, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {10, 117, 48, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {10, 117, 48, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {232, 9, 124, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {101, 47, 62, 255} }},
	{{ {182, 77, 0}, 0, {624, 112}, {91, 89, 0, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, -136}, 0, {496, 240}, {242, 25, 132, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {101, 47, 194, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {232, 9, 132, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {10, 117, 208, 255} }},
	{{ {119, 100, 0}, 0, {542, 194}, {36, 122, 0, 255} }},
	{{ {77, 100, -49}, 0, {542, 194}, {66, 92, 199, 255} }},
	{{ {152, 20, -132}, 0, {624, 240}, {35, 9, 134, 255} }},
	{{ {108, 41, -111}, 0, {496, 368}, {232, 9, 132, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {87, 36, -125}, 0, {496, 368}, {189, 4, 148, 255} }},
	{{ {152, 20, -132}, 0, {496, 368}, {35, 9, 134, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {51, 98, 194, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {50, 98, 193, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {50, 98, 193, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {51, 98, 194, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {-3, -83, 0}, 0, {368, 496}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {151, 1, 185, 255} }},
	{{ {-14, -96, -48}, 0, {368, 496}, {135, 248, 218, 255} }},
	{{ {43, -118, 0}, 0, {368, 496}, {173, 160, 0, 255} }},
	{{ {-14, -96, 48}, 0, {368, 496}, {135, 248, 38, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {39, 240, 120, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {114, 14, 55, 255} }},
	{{ {21, 71, 75}, 0, {355, 573}, {225, 120, 230, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {114, 14, 55, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {39, 240, 120, 255} }},
	{{ {22, 64, 85}, 0, {355, 573}, {211, 215, 111, 255} }},
	{{ {21, 71, 75}, 0, {355, 573}, {225, 120, 230, 255} }},
	{{ {0, 62, 69}, 0, {355, 573}, {138, 240, 213, 255} }},
	{{ {24, 61, 71}, 0, {604, 240}, {12, 180, 155, 255} }},
	{{ {21, 71, 75}, 0, {399, 515}, {225, 120, 230, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {39, 240, 136, 255} }},
	{{ {21, 71, -75}, 0, {355, 573}, {225, 120, 26, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {114, 14, 201, 255} }},
	{{ {22, 64, -85}, 0, {355, 573}, {211, 215, 145, 255} }},
	{{ {24, 61, -71}, 0, {604, 240}, {12, 180, 101, 255} }},
	{{ {21, 71, -75}, 0, {399, 515}, {225, 120, 26, 255} }},
	{{ {0, 62, -69}, 0, {355, 573}, {138, 240, 43, 255} }},
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_2 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(4, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(11, 12, 13, 0, 13, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 6, 0),
	gsSP2Triangles(6, 18, 19, 0, 20, 17, 21, 0),
	gsSP2Triangles(22, 17, 20, 0, 0, 22, 20, 0),
	gsSP2Triangles(0, 23, 22, 0, 8, 22, 23, 0),
	gsSP2Triangles(8, 24, 22, 0, 22, 24, 25, 0),
	gsSP2Triangles(24, 26, 25, 0, 22, 25, 27, 0),
	gsSP2Triangles(22, 27, 17, 0, 28, 0, 29, 0),
	gsSP2Triangles(28, 30, 0, 0, 28, 8, 30, 0),
	gsSP1Triangle(28, 31, 8, 0),
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_2 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(1, 3, 4, 0, 1, 4, 5, 0),
	gsSP2Triangles(1, 5, 6, 0, 6, 7, 1, 0),
	gsSP2Triangles(0, 8, 9, 0, 0, 10, 8, 0),
	gsSP2Triangles(11, 8, 10, 0, 11, 10, 12, 0),
	gsSP2Triangles(12, 13, 11, 0, 11, 13, 14, 0),
	gsSP2Triangles(15, 14, 13, 0, 16, 15, 13, 0),
	gsSP2Triangles(15, 16, 17, 0, 15, 17, 18, 0),
	gsSP2Triangles(6, 18, 17, 0, 6, 19, 18, 0),
	gsSP2Triangles(20, 21, 22, 0, 23, 24, 25, 0),
	gsSP2Triangles(23, 25, 26, 0, 27, 28, 29, 0),
	gsSP2Triangles(30, 27, 29, 0, 29, 31, 30, 0),
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_2 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 0, 3, 0, 0, 4, 5, 0),
	gsSP2Triangles(6, 5, 4, 0, 4, 7, 6, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(9, 5, 6, 0, 5, 9, 10, 0),
	gsSP2Triangles(10, 9, 11, 0, 12, 13, 7, 0),
	gsSP2Triangles(12, 14, 13, 0, 14, 15, 13, 0),
	gsSP2Triangles(14, 16, 17, 0, 18, 19, 20, 0),
	gsSP2Triangles(18, 21, 19, 0, 22, 23, 24, 0),
	gsSP2Triangles(25, 24, 23, 0, 25, 26, 24, 0),
	gsSP2Triangles(24, 26, 27, 0, 24, 27, 28, 0),
	gsSP2Triangles(22, 24, 28, 0, 29, 30, 31, 0),
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_2 + 96, 14, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(2, 3, 4, 0, 5, 2, 4, 0),
	gsSP2Triangles(6, 5, 4, 0, 0, 5, 6, 0),
	gsSP2Triangles(0, 2, 5, 0, 7, 8, 9, 0),
	gsSP2Triangles(7, 10, 8, 0, 9, 10, 7, 0),
	gsSP2Triangles(9, 11, 10, 0, 9, 12, 11, 0),
	gsSP2Triangles(12, 13, 11, 0, 11, 13, 10, 0),
	gsSP1Triangle(10, 13, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_DL_mesh_layer_1_vtx_3[10] = {
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_3 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 8, 6, 0, 9, 6, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_DL_mesh_layer_1_vtx_4[6] = {
	{{ {100, 98, 0}, 0, {238, 474}, {62, 111, 0, 255} }},
	{{ {68, 106, 44}, 0, {238, 496}, {16, 99, 78, 255} }},
	{{ {95, 78, 63}, 0, {496, 496}, {19, 104, 70, 255} }},
	{{ {182, 77, 0}, 0, {238, -16}, {31, 123, 0, 255} }},
	{{ {95, 78, -63}, 0, {-16, 496}, {19, 104, 186, 255} }},
	{{ {68, 106, -44}, 0, {238, 496}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_tri_4[] = {
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_4 + 0, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 4, 0, 0, 0, 4, 5, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_DL_mesh_layer_1_vtx_5[8] = {
	{{ {25, 98, 38}, 0, {742, 989}, {189, 85, 67, 255} }},
	{{ {68, 106, 44}, 0, {893, 169}, {16, 99, 78, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {742, 989}, {189, 85, 189, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {68, 106, -44}, 0, {893, 169}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_tri_5[] = {
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_1_vtx_5 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_DL_mesh_layer_5_vtx_0[12] = {
	{{ {37, -85, 81}, 0, {113, -16}, {228, 138, 39, 255} }},
	{{ {107, -76, 158}, 0, {532, 678}, {12, 137, 42, 255} }},
	{{ {17, -33, 190}, 0, {-16, 810}, {219, 144, 47, 255} }},
	{{ {107, -90, 94}, 0, {680, 139}, {28, 135, 25, 255} }},
	{{ {153, -68, 70}, 0, {1008, 158}, {93, 180, 41, 255} }},
	{{ {174, -19, 86}, 0, {1008, 710}, {102, 196, 47, 255} }},
	{{ {37, -85, -81}, 0, {112, -16}, {228, 138, 218, 255} }},
	{{ {17, -33, -190}, 0, {-16, 810}, {219, 144, 209, 255} }},
	{{ {108, -76, -158}, 0, {532, 678}, {12, 137, 214, 255} }},
	{{ {107, -90, -94}, 0, {679, 138}, {28, 135, 231, 255} }},
	{{ {153, -68, -70}, 0, {1008, 157}, {93, 180, 215, 255} }},
	{{ {174, -19, -86}, 0, {1008, 708}, {102, 197, 209, 255} }},
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Head_DL_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 4, 1, 0, 5, 1, 4, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(9, 8, 10, 0, 11, 10, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_0[28] = {
	{{ {170, 52, 90}, 0, {381, 266}, {9, 96, 83, 255} }},
	{{ {212, 86, 0}, 0, {432, 112}, {11, 117, 49, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {11, 117, 49, 255} }},
	{{ {204, 48, 92}, 0, {432, 266}, {9, 96, 83, 255} }},
	{{ {156, -11, 130}, 0, {381, 368}, {244, 8, 126, 255} }},
	{{ {189, -20, 132}, 0, {432, 368}, {244, 6, 126, 255} }},
	{{ {136, -94, 84}, 0, {381, 522}, {214, 168, 81, 255} }},
	{{ {168, -108, 86}, 0, {432, 522}, {213, 165, 78, 255} }},
	{{ {130, -117, 0}, 0, {381, 624}, {202, 141, 0, 255} }},
	{{ {162, -132, 0}, 0, {432, 624}, {202, 141, 0, 255} }},
	{{ {168, -108, -86}, 0, {432, 522}, {213, 165, 178, 255} }},
	{{ {136, -94, -84}, 0, {381, 522}, {214, 168, 175, 255} }},
	{{ {189, -20, -132}, 0, {432, 368}, {244, 6, 130, 255} }},
	{{ {156, -11, -130}, 0, {381, 368}, {244, 8, 130, 255} }},
	{{ {204, 48, -92}, 0, {432, 266}, {9, 96, 173, 255} }},
	{{ {170, 52, -90}, 0, {381, 266}, {9, 96, 173, 255} }},
	{{ {212, 86, 0}, 0, {432, 112}, {11, 117, 207, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {11, 117, 207, 255} }},
	{{ {170, 52, 90}, 0, {381, 266}, {96, 54, 64, 255} }},
	{{ {292, -57, 0}, 0, {-16, 1008}, {122, 222, 0, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {95, 75, 38, 255} }},
	{{ {156, -11, 130}, 0, {381, 368}, {84, 241, 94, 255} }},
	{{ {136, -94, 84}, 0, {381, 522}, {57, 163, 65, 255} }},
	{{ {130, -117, 0}, 0, {381, 624}, {44, 137, 0, 255} }},
	{{ {136, -94, -84}, 0, {381, 522}, {57, 163, 191, 255} }},
	{{ {156, -11, -130}, 0, {381, 368}, {84, 241, 162, 255} }},
	{{ {170, 52, -90}, 0, {381, 266}, {96, 54, 192, 255} }},
	{{ {177, 89, 0}, 0, {381, 112}, {95, 75, 218, 255} }},
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_0 + 0, 28, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 7, 5, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 8, 11, 10, 0),
	gsSP2Triangles(11, 12, 10, 0, 11, 13, 12, 0),
	gsSP2Triangles(13, 14, 12, 0, 13, 15, 14, 0),
	gsSP2Triangles(15, 16, 14, 0, 15, 17, 16, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 19, 18, 0),
	gsSP2Triangles(22, 19, 21, 0, 23, 19, 22, 0),
	gsSP2Triangles(23, 24, 19, 0, 24, 25, 19, 0),
	gsSP2Triangles(25, 26, 19, 0, 26, 27, 19, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_1[53] = {
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {11, 52, 64}, 0, {368, 240}, {156, 49, 61, 255} }},
	{{ {7, 33, 106}, 0, {496, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {368, 240}, {227, 47, 114, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 104, 70, 255} }},
	{{ {56, 62, 116}, 0, {496, 240}, {227, 47, 114, 255} }},
	{{ {68, 106, 44}, 0, {496, 192}, {16, 99, 78, 255} }},
	{{ {25, 98, 38}, 0, {337, 208}, {189, 85, 67, 255} }},
	{{ {1, 76, 0}, 0, {240, 240}, {135, 40, 0, 255} }},
	{{ {20, 111, 0}, 0, {240, 240}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {337, 208}, {189, 85, 189, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {68, 106, -44}, 0, {496, 192}, {16, 99, 178, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 104, 186, 255} }},
	{{ {56, 62, -116}, 0, {496, 240}, {227, 47, 142, 255} }},
	{{ {-7, -12, 0}, 0, {240, 368}, {130, 237, 0, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {151, 1, 185, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 240}, {176, 46, 168, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {108, -76, -158}, 0, {368, 496}, {46, 179, 166, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {7, 33, 106}, 0, {368, 240}, {176, 46, 88, 255} }},
	{{ {7, 33, 106}, 0, {368, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {496, 368}, {227, 47, 114, 255} }},
	{{ {100, 98, 0}, 0, {496, 112}, {62, 111, 0, 255} }},
	{{ {72, 127, 0}, 0, {496, 112}, {32, 123, 0, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {7, 33, -106}, 0, {496, 368}, {176, 46, 168, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {56, 62, -116}, 0, {368, 240}, {227, 47, 142, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 368}, {176, 46, 168, 255} }},
	{{ {56, 62, -116}, 0, {496, 368}, {227, 47, 142, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 104, 186, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {107, -76, 158}, 0, {368, 496}, {46, 179, 90, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {153, -68, 70}, 0, {624, 496}, {98, 189, 46, 255} }},
	{{ {107, -76, 158}, 0, {496, 496}, {46, 179, 90, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {108, -76, -158}, 0, {496, 496}, {46, 179, 166, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 189, 210, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_1 + 0, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(4, 1, 5, 0, 1, 4, 6, 0),
	gsSP2Triangles(1, 6, 7, 0, 8, 1, 7, 0),
	gsSP2Triangles(8, 7, 9, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 10, 11, 0, 11, 10, 12, 0),
	gsSP2Triangles(11, 12, 13, 0, 13, 14, 11, 0),
	gsSP2Triangles(15, 8, 11, 0, 15, 1, 8, 0),
	gsSP2Triangles(15, 16, 1, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 18, 15, 0),
	gsSP2Triangles(19, 15, 20, 0, 15, 11, 20, 0),
	gsSP2Triangles(11, 21, 20, 0, 19, 20, 22, 0),
	gsSP2Triangles(19, 22, 23, 0, 23, 22, 24, 0),
	gsSP2Triangles(19, 23, 25, 0, 1, 16, 26, 0),
	gsSP2Triangles(16, 0, 27, 0, 0, 4, 28, 0),
	gsSP2Triangles(29, 30, 6, 0, 29, 12, 30, 0),
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_1 + 31, 22, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(4, 5, 0, 0, 0, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(8, 12, 11, 0, 11, 13, 9, 0),
	gsSP2Triangles(12, 14, 15, 0, 16, 15, 14, 0),
	gsSP2Triangles(16, 13, 15, 0, 17, 18, 19, 0),
	gsSP2Triangles(20, 19, 18, 0, 20, 18, 21, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_2[110] = {
	{{ {153, -68, 70}, 0, {624, 496}, {98, 189, 46, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {124, -104, 105}, 0, {624, 496}, {9, 195, 111, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {232, 9, 124, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 104, 70, 255} }},
	{{ {87, 36, 125}, 0, {624, 240}, {189, 4, 108, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {87, 36, 125}, 0, {496, 240}, {189, 4, 108, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 189, 210, 255} }},
	{{ {124, -104, -105}, 0, {624, 496}, {9, 194, 145, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {232, 9, 132, 255} }},
	{{ {87, 36, -125}, 0, {624, 240}, {189, 4, 148, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 104, 186, 255} }},
	{{ {87, 36, -125}, 0, {496, 240}, {189, 4, 148, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {152, 20, 132}, 0, {624, 240}, {35, 9, 122, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {101, 47, 62, 255} }},
	{{ {108, 41, 111}, 0, {496, 368}, {232, 9, 124, 255} }},
	{{ {87, 36, 125}, 0, {496, 368}, {189, 4, 108, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {152, 20, 132}, 0, {624, 368}, {35, 9, 122, 255} }},
	{{ {220, -5, 0}, 0, {752, 368}, {127, 252, 0, 255} }},
	{{ {184, -86, 0}, 0, {752, 496}, {95, 171, 0, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {101, 47, 194, 255} }},
	{{ {152, 20, -132}, 0, {624, 368}, {35, 9, 134, 255} }},
	{{ {182, 77, 0}, 0, {752, 240}, {91, 89, 0, 255} }},
	{{ {132, -114, 0}, 0, {496, 624}, {55, 141, 0, 255} }},
	{{ {124, -104, 105}, 0, {496, 624}, {9, 195, 111, 255} }},
	{{ {184, -86, 0}, 0, {624, 624}, {95, 171, 0, 255} }},
	{{ {124, -104, -105}, 0, {496, 624}, {9, 194, 145, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {132, -114, 0}, 0, {496, 624}, {55, 141, 0, 255} }},
	{{ {124, -104, 105}, 0, {501, 496}, {9, 195, 111, 255} }},
	{{ {84, -107, 125}, 0, {496, 624}, {6, 204, 116, 255} }},
	{{ {51, -135, 0}, 0, {496, 624}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {496, 624}, {6, 204, 140, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {124, -104, -105}, 0, {501, 496}, {9, 194, 145, 255} }},
	{{ {95, -83, 116}, 0, {368, 496}, {51, 87, 77, 255} }},
	{{ {84, -107, 125}, 0, {501, 496}, {6, 204, 116, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {84, -107, 125}, 0, {368, 496}, {6, 204, 116, 255} }},
	{{ {-14, -96, 48}, 0, {496, 624}, {135, 248, 38, 255} }},
	{{ {43, -118, 0}, 0, {496, 624}, {173, 160, 0, 255} }},
	{{ {51, -135, 0}, 0, {368, 496}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {368, 496}, {6, 204, 140, 255} }},
	{{ {-14, -96, -48}, 0, {496, 624}, {135, 248, 218, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {151, 1, 185, 255} }},
	{{ {95, -83, -116}, 0, {368, 496}, {51, 87, 179, 255} }},
	{{ {84, -107, -125}, 0, {501, 496}, {6, 204, 140, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {152, 20, 132}, 0, {496, 368}, {35, 9, 122, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {51, 98, 62, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {50, 98, 63, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {50, 98, 63, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {51, 98, 62, 255} }},
	{{ {119, 100, 0}, 0, {542, 194}, {36, 122, 0, 255} }},
	{{ {77, 100, 49}, 0, {542, 194}, {66, 92, 57, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {10, 117, 48, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {10, 117, 48, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {232, 9, 124, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {101, 47, 62, 255} }},
	{{ {182, 77, 0}, 0, {624, 112}, {91, 89, 0, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, -136}, 0, {496, 240}, {242, 25, 132, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {101, 47, 194, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {232, 9, 132, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {10, 117, 208, 255} }},
	{{ {119, 100, 0}, 0, {542, 194}, {36, 122, 0, 255} }},
	{{ {77, 100, -49}, 0, {542, 194}, {66, 92, 199, 255} }},
	{{ {152, 20, -132}, 0, {624, 240}, {35, 9, 134, 255} }},
	{{ {108, 41, -111}, 0, {496, 368}, {232, 9, 132, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {87, 36, -125}, 0, {496, 368}, {189, 4, 148, 255} }},
	{{ {152, 20, -132}, 0, {496, 368}, {35, 9, 134, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {51, 98, 194, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {50, 98, 193, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {50, 98, 193, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {51, 98, 194, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {151, 1, 71, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {-3, -83, 0}, 0, {368, 496}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {151, 1, 185, 255} }},
	{{ {-14, -96, -48}, 0, {368, 496}, {135, 248, 218, 255} }},
	{{ {43, -118, 0}, 0, {368, 496}, {173, 160, 0, 255} }},
	{{ {-14, -96, 48}, 0, {368, 496}, {135, 248, 38, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {40, 240, 120, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {114, 14, 55, 255} }},
	{{ {21, 71, 75}, 0, {355, 573}, {225, 120, 230, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {114, 14, 55, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {40, 240, 120, 255} }},
	{{ {22, 64, 85}, 0, {355, 573}, {211, 215, 111, 255} }},
	{{ {21, 71, 75}, 0, {355, 573}, {225, 120, 230, 255} }},
	{{ {0, 62, 69}, 0, {355, 573}, {138, 240, 213, 255} }},
	{{ {24, 61, 71}, 0, {604, 240}, {12, 180, 155, 255} }},
	{{ {21, 71, 75}, 0, {399, 515}, {225, 120, 230, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {40, 240, 136, 255} }},
	{{ {21, 71, -75}, 0, {355, 573}, {225, 120, 26, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {114, 14, 201, 255} }},
	{{ {22, 64, -85}, 0, {355, 573}, {211, 215, 145, 255} }},
	{{ {24, 61, -71}, 0, {604, 240}, {12, 180, 101, 255} }},
	{{ {21, 71, -75}, 0, {399, 515}, {225, 120, 26, 255} }},
	{{ {0, 62, -69}, 0, {355, 573}, {138, 240, 43, 255} }},
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_2 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(4, 6, 7, 0, 8, 9, 10, 0),
	gsSP2Triangles(11, 12, 13, 0, 13, 14, 15, 0),
	gsSP2Triangles(16, 17, 18, 0, 16, 18, 6, 0),
	gsSP2Triangles(6, 18, 19, 0, 20, 17, 21, 0),
	gsSP2Triangles(22, 17, 20, 0, 0, 22, 20, 0),
	gsSP2Triangles(0, 23, 22, 0, 8, 22, 23, 0),
	gsSP2Triangles(8, 24, 22, 0, 22, 24, 25, 0),
	gsSP2Triangles(24, 26, 25, 0, 22, 25, 27, 0),
	gsSP2Triangles(22, 27, 17, 0, 28, 0, 29, 0),
	gsSP2Triangles(28, 30, 0, 0, 28, 8, 30, 0),
	gsSP1Triangle(28, 31, 8, 0),
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_2 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(1, 3, 4, 0, 1, 4, 5, 0),
	gsSP2Triangles(1, 5, 6, 0, 6, 7, 1, 0),
	gsSP2Triangles(0, 8, 9, 0, 0, 10, 8, 0),
	gsSP2Triangles(11, 8, 10, 0, 11, 10, 12, 0),
	gsSP2Triangles(12, 13, 11, 0, 11, 13, 14, 0),
	gsSP2Triangles(15, 14, 13, 0, 16, 15, 13, 0),
	gsSP2Triangles(15, 16, 17, 0, 15, 17, 18, 0),
	gsSP2Triangles(6, 18, 17, 0, 6, 19, 18, 0),
	gsSP2Triangles(20, 21, 22, 0, 23, 24, 25, 0),
	gsSP2Triangles(23, 25, 26, 0, 27, 28, 29, 0),
	gsSP2Triangles(30, 27, 29, 0, 29, 31, 30, 0),
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_2 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 0, 3, 0, 0, 4, 5, 0),
	gsSP2Triangles(6, 5, 4, 0, 4, 7, 6, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(9, 5, 6, 0, 5, 9, 10, 0),
	gsSP2Triangles(10, 9, 11, 0, 12, 13, 7, 0),
	gsSP2Triangles(12, 14, 13, 0, 14, 15, 13, 0),
	gsSP2Triangles(14, 16, 17, 0, 18, 19, 20, 0),
	gsSP2Triangles(18, 21, 19, 0, 22, 23, 24, 0),
	gsSP2Triangles(25, 24, 23, 0, 25, 26, 24, 0),
	gsSP2Triangles(24, 26, 27, 0, 24, 27, 28, 0),
	gsSP2Triangles(22, 24, 28, 0, 29, 30, 31, 0),
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_2 + 96, 14, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(2, 3, 4, 0, 5, 2, 4, 0),
	gsSP2Triangles(6, 5, 4, 0, 0, 5, 6, 0),
	gsSP2Triangles(0, 2, 5, 0, 7, 8, 9, 0),
	gsSP2Triangles(7, 10, 8, 0, 9, 10, 7, 0),
	gsSP2Triangles(9, 11, 10, 0, 9, 12, 11, 0),
	gsSP2Triangles(12, 13, 11, 0, 11, 13, 10, 0),
	gsSP1Triangle(10, 13, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_3[10] = {
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {102, 227, 70, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {102, 228, 186, 255} }},
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_3 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 8, 6, 0, 9, 6, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_4[6] = {
	{{ {100, 98, 0}, 0, {238, 474}, {62, 111, 0, 255} }},
	{{ {68, 106, 44}, 0, {238, 496}, {16, 99, 78, 255} }},
	{{ {95, 78, 63}, 0, {496, 496}, {19, 104, 70, 255} }},
	{{ {182, 77, 0}, 0, {238, -16}, {31, 123, 0, 255} }},
	{{ {95, 78, -63}, 0, {-16, 496}, {19, 104, 186, 255} }},
	{{ {68, 106, -44}, 0, {238, 496}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4[] = {
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_4 + 0, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 4, 0, 0, 0, 4, 5, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_5[8] = {
	{{ {25, 98, 38}, 0, {742, 989}, {189, 85, 67, 255} }},
	{{ {68, 106, 44}, 0, {893, 169}, {16, 99, 78, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {742, 989}, {189, 85, 189, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {68, 106, -44}, 0, {893, 169}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5[] = {
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_vtx_5 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_vtx_0[12] = {
	{{ {37, -85, 81}, 0, {113, -16}, {228, 138, 39, 255} }},
	{{ {107, -76, 158}, 0, {532, 678}, {12, 137, 42, 255} }},
	{{ {17, -33, 190}, 0, {-16, 810}, {219, 144, 47, 255} }},
	{{ {107, -90, 94}, 0, {680, 139}, {28, 135, 25, 255} }},
	{{ {153, -68, 70}, 0, {1008, 158}, {93, 180, 41, 255} }},
	{{ {174, -19, 86}, 0, {1008, 710}, {102, 196, 47, 255} }},
	{{ {37, -85, -81}, 0, {112, -16}, {228, 138, 218, 255} }},
	{{ {17, -33, -190}, 0, {-16, 810}, {219, 144, 209, 255} }},
	{{ {108, -76, -158}, 0, {532, 678}, {12, 137, 214, 255} }},
	{{ {107, -90, -94}, 0, {679, 138}, {28, 135, 231, 255} }},
	{{ {153, -68, -70}, 0, {1008, 157}, {93, 180, 215, 255} }},
	{{ {174, -19, -86}, 0, {1008, 708}, {102, 197, 209, 255} }},
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 4, 1, 0, 5, 1, 4, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(9, 8, 10, 0, 11, 10, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_0[53] = {
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {11, 52, 64}, 0, {368, 240}, {156, 49, 61, 255} }},
	{{ {7, 33, 106}, 0, {496, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {368, 240}, {227, 47, 114, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {56, 62, 116}, 0, {496, 240}, {227, 47, 114, 255} }},
	{{ {68, 106, 44}, 0, {496, 192}, {16, 99, 78, 255} }},
	{{ {25, 98, 38}, 0, {337, 208}, {189, 85, 67, 255} }},
	{{ {1, 76, 0}, 0, {240, 240}, {135, 40, 0, 255} }},
	{{ {20, 111, 0}, 0, {240, 240}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {337, 208}, {189, 85, 189, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {68, 106, -44}, 0, {496, 192}, {16, 99, 178, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {56, 62, -116}, 0, {496, 240}, {227, 47, 142, 255} }},
	{{ {-7, -12, 0}, 0, {240, 368}, {130, 237, 0, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {156, 227, 183, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 240}, {176, 46, 168, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {108, -76, -158}, 0, {368, 496}, {46, 179, 166, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {7, 33, 106}, 0, {368, 240}, {176, 46, 88, 255} }},
	{{ {7, 33, 106}, 0, {368, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {496, 368}, {227, 47, 114, 255} }},
	{{ {100, 98, 0}, 0, {496, 112}, {62, 111, 0, 255} }},
	{{ {72, 127, 0}, 0, {496, 112}, {32, 123, 0, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {7, 33, -106}, 0, {496, 368}, {176, 46, 168, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {56, 62, -116}, 0, {368, 240}, {227, 47, 142, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 368}, {176, 46, 168, 255} }},
	{{ {56, 62, -116}, 0, {496, 368}, {227, 47, 142, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {107, -76, 158}, 0, {368, 496}, {46, 179, 90, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {153, -68, 70}, 0, {624, 496}, {98, 188, 43, 255} }},
	{{ {107, -76, 158}, 0, {496, 496}, {46, 179, 90, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {108, -76, -158}, 0, {496, 496}, {46, 179, 166, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 188, 213, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_0 + 0, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(4, 1, 5, 0, 1, 4, 6, 0),
	gsSP2Triangles(1, 6, 7, 0, 8, 1, 7, 0),
	gsSP2Triangles(8, 7, 9, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 10, 11, 0, 11, 10, 12, 0),
	gsSP2Triangles(11, 12, 13, 0, 13, 14, 11, 0),
	gsSP2Triangles(15, 8, 11, 0, 15, 1, 8, 0),
	gsSP2Triangles(15, 16, 1, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 18, 15, 0),
	gsSP2Triangles(19, 15, 20, 0, 15, 11, 20, 0),
	gsSP2Triangles(11, 21, 20, 0, 19, 20, 22, 0),
	gsSP2Triangles(19, 22, 23, 0, 23, 22, 24, 0),
	gsSP2Triangles(19, 23, 25, 0, 1, 16, 26, 0),
	gsSP2Triangles(16, 0, 27, 0, 0, 4, 28, 0),
	gsSP2Triangles(29, 30, 6, 0, 29, 12, 30, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_0 + 31, 22, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(4, 5, 0, 0, 0, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(8, 12, 11, 0, 11, 13, 9, 0),
	gsSP2Triangles(12, 14, 15, 0, 16, 15, 14, 0),
	gsSP2Triangles(16, 13, 15, 0, 17, 18, 19, 0),
	gsSP2Triangles(20, 19, 18, 0, 20, 18, 21, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_1[110] = {
	{{ {153, -68, 70}, 0, {624, 496}, {98, 188, 43, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {124, -104, 105}, 0, {624, 496}, {9, 195, 111, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {87, 36, 125}, 0, {496, 240}, {189, 4, 108, 255} }},
	{{ {207, -5, 0}, 0, {752, 368}, {124, 227, 253, 255} }},
	{{ {182, 77, 0}, 0, {752, 240}, {68, 108, 1, 255} }},
	{{ {216, 30, 42}, 0, {752, 368}, {120, 7, 42, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 188, 213, 255} }},
	{{ {124, -104, -105}, 0, {624, 496}, {9, 195, 145, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {87, 36, -125}, 0, {496, 240}, {189, 4, 148, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {152, 20, 132}, 0, {624, 240}, {35, 9, 122, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {99, 45, 65, 255} }},
	{{ {108, 41, 111}, 0, {496, 368}, {241, 22, 124, 255} }},
	{{ {87, 36, 125}, 0, {496, 368}, {189, 4, 108, 255} }},
	{{ {216, 30, 42}, 0, {624, 240}, {120, 7, 42, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {152, 20, 132}, 0, {624, 368}, {35, 9, 122, 255} }},
	{{ {184, -86, 0}, 0, {752, 496}, {100, 178, 0, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {100, 47, 193, 255} }},
	{{ {152, 20, -132}, 0, {624, 368}, {35, 9, 134, 255} }},
	{{ {182, 77, 0}, 0, {624, 112}, {68, 108, 1, 255} }},
	{{ {216, 30, 42}, 0, {624, 112}, {120, 7, 42, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, -136}, 0, {496, 240}, {242, 25, 132, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {241, 22, 132, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {241, 22, 132, 255} }},
	{{ {87, 36, -125}, 0, {624, 240}, {189, 4, 148, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, -136}, 0, {496, 240}, {242, 25, 132, 255} }},
	{{ {119, 100, 0}, 0, {542, 194}, {36, 122, 0, 255} }},
	{{ {77, 100, -49}, 0, {542, 194}, {66, 92, 199, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {77, 100, 49}, 0, {542, 194}, {66, 92, 57, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {241, 22, 124, 255} }},
	{{ {87, 36, 125}, 0, {624, 240}, {189, 4, 108, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {99, 45, 65, 255} }},
	{{ {132, -114, 0}, 0, {496, 624}, {55, 141, 0, 255} }},
	{{ {153, -68, 70}, 0, {624, 496}, {98, 188, 43, 255} }},
	{{ {124, -104, 105}, 0, {496, 624}, {9, 195, 111, 255} }},
	{{ {184, -86, 0}, 0, {624, 624}, {100, 178, 0, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 188, 213, 255} }},
	{{ {124, -104, -105}, 0, {496, 624}, {9, 195, 145, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {124, -104, 105}, 0, {501, 496}, {9, 195, 111, 255} }},
	{{ {84, -107, 125}, 0, {496, 624}, {6, 204, 116, 255} }},
	{{ {51, -135, 0}, 0, {496, 624}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {496, 624}, {6, 204, 140, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {124, -104, -105}, 0, {501, 496}, {9, 195, 145, 255} }},
	{{ {95, -83, 116}, 0, {368, 496}, {51, 87, 77, 255} }},
	{{ {84, -107, 125}, 0, {501, 496}, {6, 204, 116, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {84, -107, 125}, 0, {368, 496}, {6, 204, 116, 255} }},
	{{ {-14, -96, 48}, 0, {496, 624}, {135, 248, 38, 255} }},
	{{ {43, -118, 0}, 0, {496, 624}, {173, 160, 0, 255} }},
	{{ {84, -107, 125}, 0, {368, 496}, {6, 204, 116, 255} }},
	{{ {43, -118, 0}, 0, {496, 624}, {173, 160, 0, 255} }},
	{{ {51, -135, 0}, 0, {368, 496}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {368, 496}, {6, 204, 140, 255} }},
	{{ {-14, -96, -48}, 0, {496, 624}, {135, 248, 218, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {156, 227, 183, 255} }},
	{{ {95, -83, -116}, 0, {368, 496}, {51, 87, 179, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {84, -107, -125}, 0, {501, 496}, {6, 204, 140, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {152, 20, 132}, 0, {496, 368}, {35, 9, 122, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {241, 22, 124, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {54, 96, 63, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {54, 77, 85, 255} }},
	{{ {21, 71, 75}, 0, {355, 573}, {225, 120, 230, 255} }},
	{{ {22, 64, 85}, 0, {355, 573}, {211, 215, 111, 255} }},
	{{ {0, 62, 69}, 0, {355, 573}, {138, 240, 213, 255} }},
	{{ {24, 61, 71}, 0, {604, 240}, {12, 180, 155, 255} }},
	{{ {21, 71, 75}, 0, {399, 515}, {225, 120, 230, 255} }},
	{{ {152, 20, -132}, 0, {624, 240}, {35, 9, 134, 255} }},
	{{ {108, 41, -111}, 0, {496, 368}, {241, 22, 132, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {100, 47, 193, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {87, 36, -125}, 0, {496, 368}, {189, 4, 148, 255} }},
	{{ {152, 20, -132}, 0, {496, 368}, {35, 9, 134, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {241, 22, 132, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {54, 96, 193, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {54, 77, 171, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {54, 77, 171, 255} }},
	{{ {21, 71, -75}, 0, {355, 573}, {225, 120, 26, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {54, 96, 193, 255} }},
	{{ {22, 64, -85}, 0, {355, 573}, {211, 215, 145, 255} }},
	{{ {24, 61, -71}, 0, {604, 240}, {12, 180, 101, 255} }},
	{{ {21, 71, -75}, 0, {399, 515}, {225, 120, 26, 255} }},
	{{ {0, 62, -69}, 0, {355, 573}, {138, 240, 43, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {-3, -83, 0}, 0, {368, 496}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {156, 227, 183, 255} }},
	{{ {-14, -96, -48}, 0, {368, 496}, {135, 248, 218, 255} }},
	{{ {43, -118, 0}, 0, {368, 496}, {173, 160, 0, 255} }},
	{{ {-14, -96, 48}, 0, {368, 496}, {135, 248, 38, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(15, 17, 4, 0, 4, 17, 18, 0),
	gsSP2Triangles(16, 6, 19, 0, 6, 16, 20, 0),
	gsSP2Triangles(20, 16, 21, 0, 0, 6, 20, 0),
	gsSP2Triangles(0, 22, 6, 0, 9, 6, 22, 0),
	gsSP2Triangles(9, 23, 6, 0, 6, 23, 24, 0),
	gsSP2Triangles(23, 25, 24, 0, 26, 16, 27, 0),
	gsSP2Triangles(26, 28, 16, 0, 28, 26, 29, 0),
	gsSP2Triangles(30, 29, 26, 0, 26, 24, 30, 0),
	gsSP2Triangles(30, 24, 31, 0, 30, 31, 12, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_1 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
	gsSP2Triangles(3, 2, 5, 0, 5, 2, 6, 0),
	gsSP2Triangles(3, 5, 7, 0, 5, 8, 7, 0),
	gsSP2Triangles(7, 9, 3, 0, 9, 7, 10, 0),
	gsSP2Triangles(10, 7, 11, 0, 9, 10, 12, 0),
	gsSP2Triangles(13, 14, 15, 0, 13, 16, 14, 0),
	gsSP2Triangles(13, 17, 16, 0, 13, 18, 17, 0),
	gsSP2Triangles(19, 13, 20, 0, 13, 19, 21, 0),
	gsSP2Triangles(13, 21, 22, 0, 13, 22, 23, 0),
	gsSP2Triangles(13, 23, 24, 0, 24, 25, 13, 0),
	gsSP2Triangles(19, 26, 27, 0, 19, 28, 26, 0),
	gsSP2Triangles(29, 26, 28, 0, 29, 28, 30, 0),
	gsSP1Triangle(30, 31, 29, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_1 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
	gsSP2Triangles(4, 3, 1, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 5, 6, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(15, 14, 16, 0, 15, 16, 17, 0),
	gsSP2Triangles(17, 16, 18, 0, 19, 17, 18, 0),
	gsSP2Triangles(20, 19, 18, 0, 14, 19, 20, 0),
	gsSP2Triangles(14, 17, 19, 0, 14, 15, 17, 0),
	gsSP2Triangles(21, 22, 23, 0, 21, 24, 22, 0),
	gsSP2Triangles(24, 25, 22, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_1 + 96, 14, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(2, 3, 0, 0, 2, 4, 3, 0),
	gsSP2Triangles(2, 5, 4, 0, 5, 6, 4, 0),
	gsSP2Triangles(4, 6, 3, 0, 3, 6, 1, 0),
	gsSP2Triangles(7, 8, 9, 0, 10, 9, 8, 0),
	gsSP2Triangles(10, 11, 9, 0, 9, 11, 12, 0),
	gsSP2Triangles(9, 12, 13, 0, 7, 9, 13, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_2[10] = {
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_2 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 8, 6, 0, 9, 6, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_3[6] = {
	{{ {100, 98, 0}, 0, {238, 474}, {62, 111, 0, 255} }},
	{{ {68, 106, 44}, 0, {238, 496}, {16, 99, 78, 255} }},
	{{ {95, 78, 63}, 0, {496, 496}, {19, 110, 61, 255} }},
	{{ {182, 77, 0}, 0, {238, -16}, {68, 108, 1, 255} }},
	{{ {95, 78, -63}, 0, {-16, 496}, {19, 110, 195, 255} }},
	{{ {68, 106, -44}, 0, {238, 496}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_3 + 0, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 4, 0, 0, 0, 4, 5, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_4[8] = {
	{{ {25, 98, 38}, 0, {742, 989}, {189, 85, 67, 255} }},
	{{ {68, 106, 44}, 0, {893, 169}, {16, 99, 78, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {742, 989}, {189, 85, 189, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {68, 106, -44}, 0, {893, 169}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_vtx_4 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_vtx_0[12] = {
	{{ {37, -85, 81}, 0, {113, -16}, {156, 227, 73, 255} }},
	{{ {107, -76, 158}, 0, {532, 678}, {12, 137, 42, 255} }},
	{{ {17, -33, 190}, 0, {-16, 810}, {219, 144, 47, 255} }},
	{{ {107, -90, 94}, 0, {680, 139}, {28, 135, 25, 255} }},
	{{ {153, -68, 70}, 0, {1008, 158}, {98, 188, 43, 255} }},
	{{ {174, -19, 86}, 0, {1008, 710}, {107, 223, 61, 255} }},
	{{ {37, -85, -81}, 0, {112, -16}, {156, 227, 183, 255} }},
	{{ {17, -33, -190}, 0, {-16, 810}, {219, 144, 209, 255} }},
	{{ {108, -76, -158}, 0, {532, 678}, {12, 137, 214, 255} }},
	{{ {107, -90, -94}, 0, {679, 138}, {28, 135, 231, 255} }},
	{{ {153, -68, -70}, 0, {1008, 157}, {98, 188, 213, 255} }},
	{{ {174, -19, -86}, 0, {1008, 708}, {107, 223, 195, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 4, 1, 0, 5, 1, 4, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(9, 8, 10, 0, 11, 10, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_0[53] = {
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {11, 52, 64}, 0, {368, 240}, {156, 49, 61, 255} }},
	{{ {7, 33, 106}, 0, {496, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {368, 240}, {227, 47, 114, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {56, 62, 116}, 0, {496, 240}, {227, 47, 114, 255} }},
	{{ {68, 106, 44}, 0, {496, 192}, {16, 99, 78, 255} }},
	{{ {25, 98, 38}, 0, {337, 208}, {189, 85, 67, 255} }},
	{{ {1, 76, 0}, 0, {240, 240}, {135, 40, 0, 255} }},
	{{ {20, 111, 0}, 0, {240, 240}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {337, 208}, {189, 85, 189, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {68, 106, -44}, 0, {496, 192}, {16, 99, 178, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {56, 62, -116}, 0, {496, 240}, {227, 47, 142, 255} }},
	{{ {-7, -12, 0}, 0, {240, 368}, {130, 237, 0, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {156, 227, 183, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 240}, {176, 46, 168, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {108, -76, -158}, 0, {368, 496}, {46, 179, 166, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {7, 33, 106}, 0, {368, 240}, {176, 46, 88, 255} }},
	{{ {7, 33, 106}, 0, {368, 368}, {176, 46, 88, 255} }},
	{{ {56, 62, 116}, 0, {496, 368}, {227, 47, 114, 255} }},
	{{ {100, 98, 0}, 0, {496, 112}, {62, 111, 0, 255} }},
	{{ {72, 127, 0}, 0, {496, 112}, {32, 123, 0, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {7, 33, -106}, 0, {496, 368}, {176, 46, 168, 255} }},
	{{ {11, 52, -64}, 0, {368, 240}, {156, 49, 195, 255} }},
	{{ {56, 62, -116}, 0, {368, 240}, {227, 47, 142, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {7, 33, -106}, 0, {368, 368}, {176, 46, 168, 255} }},
	{{ {56, 62, -116}, 0, {496, 368}, {227, 47, 142, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {107, -76, 158}, 0, {368, 496}, {46, 179, 90, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {153, -68, 70}, 0, {624, 496}, {98, 188, 43, 255} }},
	{{ {107, -76, 158}, 0, {496, 496}, {46, 179, 90, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {108, -76, -158}, 0, {496, 496}, {46, 179, 166, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 188, 213, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_0 + 0, 31, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 0, 3, 0),
	gsSP2Triangles(4, 1, 5, 0, 1, 4, 6, 0),
	gsSP2Triangles(1, 6, 7, 0, 8, 1, 7, 0),
	gsSP2Triangles(8, 7, 9, 0, 8, 9, 10, 0),
	gsSP2Triangles(8, 10, 11, 0, 11, 10, 12, 0),
	gsSP2Triangles(11, 12, 13, 0, 13, 14, 11, 0),
	gsSP2Triangles(15, 8, 11, 0, 15, 1, 8, 0),
	gsSP2Triangles(15, 16, 1, 0, 17, 16, 15, 0),
	gsSP2Triangles(17, 15, 18, 0, 19, 18, 15, 0),
	gsSP2Triangles(19, 15, 20, 0, 15, 11, 20, 0),
	gsSP2Triangles(11, 21, 20, 0, 19, 20, 22, 0),
	gsSP2Triangles(19, 22, 23, 0, 23, 22, 24, 0),
	gsSP2Triangles(19, 23, 25, 0, 1, 16, 26, 0),
	gsSP2Triangles(16, 0, 27, 0, 0, 4, 28, 0),
	gsSP2Triangles(29, 30, 6, 0, 29, 12, 30, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_0 + 31, 22, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 0, 0),
	gsSP2Triangles(4, 5, 0, 0, 0, 6, 7, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 11, 9, 0),
	gsSP2Triangles(8, 12, 11, 0, 11, 13, 9, 0),
	gsSP2Triangles(12, 14, 15, 0, 16, 15, 14, 0),
	gsSP2Triangles(16, 13, 15, 0, 17, 18, 19, 0),
	gsSP2Triangles(20, 19, 18, 0, 20, 18, 21, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_1[110] = {
	{{ {153, -68, 70}, 0, {624, 496}, {98, 188, 43, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {124, -104, 105}, 0, {624, 496}, {9, 195, 111, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {87, 36, 125}, 0, {496, 240}, {189, 4, 108, 255} }},
	{{ {207, -5, 0}, 0, {752, 368}, {124, 227, 253, 255} }},
	{{ {182, 77, 0}, 0, {752, 240}, {68, 108, 1, 255} }},
	{{ {216, 30, 42}, 0, {752, 368}, {120, 7, 42, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 188, 213, 255} }},
	{{ {124, -104, -105}, 0, {624, 496}, {9, 194, 145, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {87, 36, -125}, 0, {496, 240}, {189, 4, 148, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {152, 20, 132}, 0, {624, 240}, {35, 9, 122, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {99, 45, 65, 255} }},
	{{ {108, 41, 111}, 0, {496, 368}, {241, 22, 124, 255} }},
	{{ {87, 36, 125}, 0, {496, 368}, {189, 4, 108, 255} }},
	{{ {216, 30, 42}, 0, {624, 240}, {120, 7, 42, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {152, 20, 132}, 0, {624, 368}, {35, 9, 122, 255} }},
	{{ {184, -86, 0}, 0, {752, 496}, {100, 178, 0, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {100, 47, 193, 255} }},
	{{ {152, 20, -132}, 0, {624, 368}, {35, 9, 134, 255} }},
	{{ {182, 77, 0}, 0, {624, 112}, {68, 108, 1, 255} }},
	{{ {216, 30, 42}, 0, {624, 112}, {120, 7, 42, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, -136}, 0, {496, 240}, {242, 25, 132, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {241, 22, 132, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {241, 22, 132, 255} }},
	{{ {87, 36, -125}, 0, {624, 240}, {189, 4, 148, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {148, 94, 0}, 0, {542, 194}, {38, 121, 0, 255} }},
	{{ {120, 58, -136}, 0, {496, 240}, {242, 25, 132, 255} }},
	{{ {119, 100, 0}, 0, {542, 194}, {36, 122, 0, 255} }},
	{{ {77, 100, -49}, 0, {542, 194}, {66, 92, 199, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {77, 100, 49}, 0, {542, 194}, {66, 92, 57, 255} }},
	{{ {120, 58, 136}, 0, {496, 240}, {242, 25, 124, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {241, 22, 124, 255} }},
	{{ {87, 36, 125}, 0, {624, 240}, {189, 4, 108, 255} }},
	{{ {169, 32, 95}, 0, {624, 240}, {99, 45, 65, 255} }},
	{{ {132, -114, 0}, 0, {496, 624}, {55, 141, 0, 255} }},
	{{ {153, -68, 70}, 0, {624, 496}, {98, 188, 43, 255} }},
	{{ {124, -104, 105}, 0, {496, 624}, {9, 195, 111, 255} }},
	{{ {184, -86, 0}, 0, {624, 624}, {100, 178, 0, 255} }},
	{{ {153, -68, -70}, 0, {624, 496}, {98, 188, 213, 255} }},
	{{ {124, -104, -105}, 0, {496, 624}, {9, 194, 145, 255} }},
	{{ {107, -90, 94}, 0, {501, 496}, {60, 165, 66, 255} }},
	{{ {124, -104, 105}, 0, {501, 496}, {9, 195, 111, 255} }},
	{{ {84, -107, 125}, 0, {496, 624}, {6, 204, 116, 255} }},
	{{ {51, -135, 0}, 0, {496, 624}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {496, 624}, {6, 204, 140, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {124, -104, -105}, 0, {501, 496}, {9, 194, 145, 255} }},
	{{ {95, -83, 116}, 0, {368, 496}, {51, 87, 77, 255} }},
	{{ {84, -107, 125}, 0, {501, 496}, {6, 204, 116, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {84, -107, 125}, 0, {368, 496}, {6, 204, 116, 255} }},
	{{ {-14, -96, 48}, 0, {496, 624}, {135, 248, 38, 255} }},
	{{ {43, -118, 0}, 0, {496, 624}, {173, 160, 0, 255} }},
	{{ {84, -107, 125}, 0, {368, 496}, {6, 204, 116, 255} }},
	{{ {43, -118, 0}, 0, {496, 624}, {173, 160, 0, 255} }},
	{{ {51, -135, 0}, 0, {368, 496}, {197, 144, 0, 255} }},
	{{ {84, -107, -125}, 0, {368, 496}, {6, 204, 140, 255} }},
	{{ {-14, -96, -48}, 0, {496, 624}, {135, 248, 218, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {156, 227, 183, 255} }},
	{{ {95, -83, -116}, 0, {368, 496}, {51, 87, 179, 255} }},
	{{ {107, -90, -94}, 0, {501, 496}, {60, 165, 190, 255} }},
	{{ {84, -107, -125}, 0, {501, 496}, {6, 204, 140, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {152, 20, 132}, 0, {496, 368}, {35, 9, 122, 255} }},
	{{ {108, 41, 111}, 0, {640, 240}, {241, 22, 124, 255} }},
	{{ {95, 78, 63}, 0, {487, 239}, {19, 110, 61, 255} }},
	{{ {84, 75, 77}, 0, {604, 240}, {54, 96, 63, 255} }},
	{{ {70, 68, 100}, 0, {355, 573}, {54, 77, 85, 255} }},
	{{ {21, 71, 75}, 0, {355, 573}, {225, 120, 230, 255} }},
	{{ {22, 64, 85}, 0, {355, 573}, {211, 215, 111, 255} }},
	{{ {0, 62, 69}, 0, {355, 573}, {138, 240, 213, 255} }},
	{{ {24, 61, 71}, 0, {604, 240}, {12, 180, 155, 255} }},
	{{ {21, 71, 75}, 0, {399, 515}, {225, 120, 230, 255} }},
	{{ {152, 20, -132}, 0, {624, 240}, {35, 9, 134, 255} }},
	{{ {108, 41, -111}, 0, {496, 368}, {241, 22, 132, 255} }},
	{{ {169, 32, -95}, 0, {624, 240}, {100, 47, 193, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {87, 36, -125}, 0, {496, 368}, {189, 4, 148, 255} }},
	{{ {152, 20, -132}, 0, {496, 368}, {35, 9, 134, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
	{{ {108, 41, -111}, 0, {640, 240}, {241, 22, 132, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {54, 96, 193, 255} }},
	{{ {95, 78, -63}, 0, {487, 239}, {19, 110, 195, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {54, 77, 171, 255} }},
	{{ {70, 68, -100}, 0, {355, 573}, {54, 77, 171, 255} }},
	{{ {21, 71, -75}, 0, {355, 573}, {225, 120, 26, 255} }},
	{{ {84, 75, -77}, 0, {604, 240}, {54, 96, 193, 255} }},
	{{ {22, 64, -85}, 0, {355, 573}, {211, 215, 145, 255} }},
	{{ {24, 61, -71}, 0, {604, 240}, {12, 180, 101, 255} }},
	{{ {21, 71, -75}, 0, {399, 515}, {225, 120, 26, 255} }},
	{{ {0, 62, -69}, 0, {355, 573}, {138, 240, 43, 255} }},
	{{ {37, -85, 81}, 0, {368, 496}, {156, 227, 73, 255} }},
	{{ {20, -71, 0}, 0, {240, 484}, {134, 36, 0, 255} }},
	{{ {-3, -83, 0}, 0, {368, 496}, {134, 36, 0, 255} }},
	{{ {37, -85, -81}, 0, {368, 496}, {156, 227, 183, 255} }},
	{{ {-14, -96, -48}, 0, {368, 496}, {135, 248, 218, 255} }},
	{{ {43, -118, 0}, 0, {368, 496}, {173, 160, 0, 255} }},
	{{ {-14, -96, 48}, 0, {368, 496}, {135, 248, 38, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 7, 8, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 15, 16, 17, 0),
	gsSP2Triangles(15, 17, 4, 0, 4, 17, 18, 0),
	gsSP2Triangles(16, 6, 19, 0, 6, 16, 20, 0),
	gsSP2Triangles(20, 16, 21, 0, 0, 6, 20, 0),
	gsSP2Triangles(0, 22, 6, 0, 9, 6, 22, 0),
	gsSP2Triangles(9, 23, 6, 0, 6, 23, 24, 0),
	gsSP2Triangles(23, 25, 24, 0, 26, 16, 27, 0),
	gsSP2Triangles(26, 28, 16, 0, 28, 26, 29, 0),
	gsSP2Triangles(30, 29, 26, 0, 26, 24, 30, 0),
	gsSP2Triangles(30, 24, 31, 0, 30, 31, 12, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_1 + 32, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 3, 4, 0),
	gsSP2Triangles(3, 2, 5, 0, 5, 2, 6, 0),
	gsSP2Triangles(3, 5, 7, 0, 5, 8, 7, 0),
	gsSP2Triangles(7, 9, 3, 0, 9, 7, 10, 0),
	gsSP2Triangles(10, 7, 11, 0, 9, 10, 12, 0),
	gsSP2Triangles(13, 14, 15, 0, 13, 16, 14, 0),
	gsSP2Triangles(13, 17, 16, 0, 13, 18, 17, 0),
	gsSP2Triangles(19, 13, 20, 0, 13, 19, 21, 0),
	gsSP2Triangles(13, 21, 22, 0, 13, 22, 23, 0),
	gsSP2Triangles(13, 23, 24, 0, 24, 25, 13, 0),
	gsSP2Triangles(19, 26, 27, 0, 19, 28, 26, 0),
	gsSP2Triangles(29, 26, 28, 0, 29, 28, 30, 0),
	gsSP1Triangle(30, 31, 29, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_1 + 64, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
	gsSP2Triangles(4, 3, 1, 0, 3, 4, 5, 0),
	gsSP2Triangles(3, 5, 6, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 10, 11, 0),
	gsSP2Triangles(12, 13, 14, 0, 12, 14, 15, 0),
	gsSP2Triangles(15, 14, 16, 0, 15, 16, 17, 0),
	gsSP2Triangles(17, 16, 18, 0, 19, 17, 18, 0),
	gsSP2Triangles(20, 19, 18, 0, 14, 19, 20, 0),
	gsSP2Triangles(14, 17, 19, 0, 14, 15, 17, 0),
	gsSP2Triangles(21, 22, 23, 0, 21, 24, 22, 0),
	gsSP2Triangles(24, 25, 22, 0, 24, 26, 27, 0),
	gsSP2Triangles(28, 29, 30, 0, 28, 31, 29, 0),
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_1 + 96, 14, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(2, 3, 0, 0, 2, 4, 3, 0),
	gsSP2Triangles(2, 5, 4, 0, 5, 6, 4, 0),
	gsSP2Triangles(4, 6, 3, 0, 3, 6, 1, 0),
	gsSP2Triangles(7, 8, 9, 0, 10, 9, 8, 0),
	gsSP2Triangles(10, 11, 9, 0, 9, 11, 12, 0),
	gsSP2Triangles(9, 12, 13, 0, 7, 9, 13, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_2[10] = {
	{{ {23, -16, 93}, 0, {368, 368}, {143, 7, 58, 255} }},
	{{ {17, -33, 190}, 0, {368, 368}, {181, 18, 101, 255} }},
	{{ {109, -17, 148}, 0, {496, 368}, {45, 83, 85, 255} }},
	{{ {104, 0, 96}, 0, {496, 368}, {233, 47, 116, 255} }},
	{{ {174, -19, 86}, 0, {608, 418}, {107, 223, 61, 255} }},
	{{ {23, -16, -93}, 0, {368, 368}, {143, 7, 198, 255} }},
	{{ {109, -17, -148}, 0, {496, 368}, {45, 83, 171, 255} }},
	{{ {17, -33, -190}, 0, {368, 368}, {181, 18, 155, 255} }},
	{{ {104, 0, -96}, 0, {496, 368}, {233, 47, 140, 255} }},
	{{ {174, -19, -86}, 0, {608, 418}, {107, 223, 195, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_2 + 0, 10, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 3, 2, 0, 5, 6, 7, 0),
	gsSP2Triangles(5, 8, 6, 0, 9, 6, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_3[6] = {
	{{ {100, 98, 0}, 0, {238, 474}, {62, 111, 0, 255} }},
	{{ {68, 106, 44}, 0, {238, 496}, {16, 99, 78, 255} }},
	{{ {95, 78, 63}, 0, {496, 496}, {19, 110, 61, 255} }},
	{{ {182, 77, 0}, 0, {238, -16}, {68, 108, 1, 255} }},
	{{ {95, 78, -63}, 0, {-16, 496}, {19, 110, 195, 255} }},
	{{ {68, 106, -44}, 0, {238, 496}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_3 + 0, 6, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 4, 0, 0, 0, 4, 5, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_4[8] = {
	{{ {25, 98, 38}, 0, {742, 989}, {189, 85, 67, 255} }},
	{{ {68, 106, 44}, 0, {893, 169}, {16, 99, 78, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {25, 98, -38}, 0, {742, 989}, {189, 85, 189, 255} }},
	{{ {20, 111, 0}, 0, {-16, 1008}, {178, 100, 0, 255} }},
	{{ {72, 127, 0}, 0, {-16, -16}, {32, 123, 0, 255} }},
	{{ {68, 106, -44}, 0, {893, 169}, {16, 99, 178, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_vtx_4 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_vtx_0[12] = {
	{{ {37, -85, 81}, 0, {113, -16}, {156, 227, 73, 255} }},
	{{ {107, -76, 158}, 0, {532, 678}, {12, 137, 42, 255} }},
	{{ {17, -33, 190}, 0, {-16, 810}, {219, 144, 47, 255} }},
	{{ {107, -90, 94}, 0, {680, 139}, {28, 135, 25, 255} }},
	{{ {153, -68, 70}, 0, {1008, 158}, {98, 188, 43, 255} }},
	{{ {174, -19, 86}, 0, {1008, 710}, {107, 223, 61, 255} }},
	{{ {37, -85, -81}, 0, {112, -16}, {156, 227, 183, 255} }},
	{{ {17, -33, -190}, 0, {-16, 810}, {219, 144, 209, 255} }},
	{{ {108, -76, -158}, 0, {532, 678}, {12, 137, 214, 255} }},
	{{ {107, -90, -94}, 0, {679, 138}, {28, 135, 231, 255} }},
	{{ {153, -68, -70}, 0, {1008, 157}, {98, 188, 213, 255} }},
	{{ {174, -19, -86}, 0, {1008, 708}, {107, 223, 195, 255} }},
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 4, 1, 0, 5, 1, 4, 0),
	gsSP2Triangles(6, 7, 8, 0, 6, 8, 9, 0),
	gsSP2Triangles(9, 8, 10, 0, 11, 10, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Wing_DL_mesh_layer_4_vtx_0[4] = {
	{{ {-14, 21, 16}, 0, {-16, 1978}, {233, 0, 125, 255} }},
	{{ {90, 21, 35}, 0, {974, 1978}, {233, 0, 125, 255} }},
	{{ {89, 233, 35}, 0, {974, -34}, {233, 0, 125, 255} }},
	{{ {-14, 233, 16}, 0, {-16, -34}, {233, 0, 125, 255} }},
};

Gfx landie_alt_collar_Left_Wing_DL_mesh_layer_4_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Wing_DL_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Wing_DL_mesh_layer_4_vtx_1[4] = {
	{{ {-117, 233, -3}, 0, {-16, -34}, {233, 0, 125, 255} }},
	{{ {-14, 21, 16}, 0, {974, 1978}, {233, 0, 125, 255} }},
	{{ {-14, 233, 16}, 0, {974, -34}, {233, 0, 125, 255} }},
	{{ {-118, 21, -3}, 0, {-16, 1978}, {233, 0, 125, 255} }},
};

Gfx landie_alt_collar_Left_Wing_DL_mesh_layer_4_tri_1[] = {
	gsSPVertex(landie_alt_collar_Left_Wing_DL_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Wing_DL_mesh_layer_4_vtx_0[4] = {
	{{ {-14, 21, -16}, 0, {-16, 1978}, {23, 0, 125, 255} }},
	{{ {90, 21, -35}, 0, {974, 1978}, {23, 0, 125, 255} }},
	{{ {89, 233, -35}, 0, {974, -34}, {23, 0, 125, 255} }},
	{{ {-14, 233, -16}, 0, {-16, -34}, {23, 0, 125, 255} }},
};

Gfx landie_alt_collar_Right_Wing_DL_mesh_layer_4_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Wing_DL_mesh_layer_4_vtx_0 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Wing_DL_mesh_layer_4_vtx_1[4] = {
	{{ {-117, 233, 3}, 0, {-16, -34}, {23, 0, 125, 255} }},
	{{ {-14, 21, -16}, 0, {974, 1978}, {23, 0, 125, 255} }},
	{{ {-14, 233, -16}, 0, {974, -34}, {23, 0, 125, 255} }},
	{{ {-118, 21, 3}, 0, {-16, 1978}, {23, 0, 125, 255} }},
};

Gfx landie_alt_collar_Right_Wing_DL_mesh_layer_4_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Wing_DL_mesh_layer_4_vtx_1 + 0, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Arm_Color_mesh_layer_1_vtx_0[44] = {
	{{ {12, -34, -31}, 0, {368, 112}, {232, 168, 168, 255} }},
	{{ {-8, -31, -5}, 0, {496, -16}, {162, 171, 0, 255} }},
	{{ {-8, -24, -21}, 0, {368, -16}, {161, 196, 196, 255} }},
	{{ {12, -44, -5}, 0, {496, 112}, {231, 131, 0, 255} }},
	{{ {62, -28, -25}, 0, {368, 240}, {22, 168, 168, 255} }},
	{{ {62, -36, -5}, 0, {496, 240}, {21, 131, 0, 255} }},
	{{ {12, -34, 21}, 0, {624, 112}, {232, 168, 88, 255} }},
	{{ {62, -28, 15}, 0, {624, 240}, {22, 168, 88, 255} }},
	{{ {-8, -24, 11}, 0, {624, -16}, {161, 196, 60, 255} }},
	{{ {-8, -8, -27}, 0, {112, 368}, {162, 0, 171, 255} }},
	{{ {12, -34, -31}, 0, {240, 240}, {232, 168, 168, 255} }},
	{{ {-8, -24, -21}, 0, {112, 240}, {161, 196, 196, 255} }},
	{{ {12, -8, -41}, 0, {240, 368}, {231, 0, 131, 255} }},
	{{ {-8, 7, -21}, 0, {112, 496}, {161, 60, 196, 255} }},
	{{ {12, 17, -31}, 0, {240, 496}, {232, 88, 168, 255} }},
	{{ {62, -8, -33}, 0, {368, 368}, {21, 0, 131, 255} }},
	{{ {62, 11, -25}, 0, {368, 496}, {22, 88, 168, 255} }},
	{{ {12, 17, 21}, 0, {752, 496}, {232, 88, 88, 255} }},
	{{ {-8, 7, 11}, 0, {880, 496}, {161, 60, 60, 255} }},
	{{ {-8, -8, 17}, 0, {880, 368}, {162, 0, 85, 255} }},
	{{ {12, -8, 31}, 0, {752, 368}, {231, 0, 125, 255} }},
	{{ {-8, -24, 11}, 0, {880, 240}, {161, 196, 60, 255} }},
	{{ {12, -34, 21}, 0, {752, 240}, {232, 168, 88, 255} }},
	{{ {62, -8, 23}, 0, {624, 368}, {21, 0, 125, 255} }},
	{{ {62, 11, 15}, 0, {624, 496}, {22, 88, 88, 255} }},
	{{ {12, 17, -31}, 0, {368, 624}, {232, 88, 168, 255} }},
	{{ {62, 19, -5}, 0, {496, 496}, {21, 125, 0, 255} }},
	{{ {12, 27, -5}, 0, {496, 624}, {231, 125, 0, 255} }},
	{{ {-8, 7, -21}, 0, {368, 752}, {161, 60, 196, 255} }},
	{{ {-8, 14, -5}, 0, {496, 752}, {162, 85, 0, 255} }},
	{{ {-17, -8, -5}, 0, {496, 880}, {129, 0, 0, 255} }},
	{{ {-8, -8, -27}, 0, {368, 880}, {162, 0, 171, 255} }},
	{{ {-8, -24, -21}, 0, {368, 1008}, {161, 196, 196, 255} }},
	{{ {-17, -8, -5}, 0, {496, 880}, {129, 0, 0, 255} }},
	{{ {-8, -8, -27}, 0, {368, 880}, {162, 0, 171, 255} }},
	{{ {-8, -31, -5}, 0, {496, 1008}, {162, 171, 0, 255} }},
	{{ {-8, -24, 11}, 0, {624, 1008}, {161, 196, 60, 255} }},
	{{ {-8, -8, 17}, 0, {624, 880}, {162, 0, 85, 255} }},
	{{ {-8, 7, 11}, 0, {624, 752}, {161, 60, 60, 255} }},
	{{ {-8, 14, -5}, 0, {496, 752}, {162, 85, 0, 255} }},
	{{ {12, 17, 21}, 0, {624, 624}, {232, 88, 88, 255} }},
	{{ {12, 27, -5}, 0, {496, 624}, {231, 125, 0, 255} }},
	{{ {62, 11, 15}, 0, {624, 496}, {22, 88, 88, 255} }},
	{{ {62, 19, -5}, 0, {496, 496}, {21, 125, 0, 255} }},
};

Gfx landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Arm_Color_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(5, 6, 3, 0, 5, 7, 6, 0),
	gsSP2Triangles(3, 6, 8, 0, 3, 8, 1, 0),
	gsSP2Triangles(9, 10, 11, 0, 9, 12, 10, 0),
	gsSP2Triangles(13, 12, 9, 0, 13, 14, 12, 0),
	gsSP2Triangles(14, 15, 12, 0, 14, 16, 15, 0),
	gsSP2Triangles(12, 15, 4, 0, 12, 4, 10, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 19, 20, 0),
	gsSP2Triangles(20, 19, 21, 0, 20, 21, 22, 0),
	gsSP2Triangles(23, 20, 22, 0, 23, 22, 7, 0),
	gsSP2Triangles(24, 20, 23, 0, 24, 17, 20, 0),
	gsSP2Triangles(25, 26, 16, 0, 25, 27, 26, 0),
	gsSP2Triangles(28, 27, 25, 0, 28, 29, 27, 0),
	gsSP2Triangles(30, 29, 28, 0, 30, 28, 31, 0),
	gsSPVertex(landie_alt_collar_Left_Arm_Color_mesh_layer_1_vtx_0 + 32, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 1, 3, 0, 4, 5, 1, 0),
	gsSP2Triangles(1, 5, 6, 0, 1, 6, 7, 0),
	gsSP2Triangles(7, 6, 8, 0, 7, 8, 9, 0),
	gsSP2Triangles(9, 8, 10, 0, 9, 10, 11, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Arm_Color_mesh_layer_1_vtx_1[9] = {
	{{ {67, -8, -5}, 0, {496, 368}, {127, 0, 0, 255} }},
	{{ {62, -28, -25}, 0, {368, 240}, {124, 238, 238, 255} }},
	{{ {62, -8, -33}, 0, {368, 368}, {124, 0, 230, 255} }},
	{{ {62, -36, -5}, 0, {496, 240}, {124, 230, 0, 255} }},
	{{ {62, -28, 15}, 0, {624, 240}, {124, 238, 18, 255} }},
	{{ {62, -8, 23}, 0, {624, 368}, {124, 0, 26, 255} }},
	{{ {62, 11, 15}, 0, {624, 496}, {124, 18, 18, 255} }},
	{{ {62, 19, -5}, 0, {496, 496}, {124, 26, 0, 255} }},
	{{ {62, 11, -25}, 0, {368, 496}, {124, 18, 238, 255} }},
};

Gfx landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Left_Arm_Color_mesh_layer_1_vtx_1 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 0, 5, 4, 0),
	gsSP2Triangles(6, 5, 0, 0, 6, 0, 7, 0),
	gsSP2Triangles(8, 7, 0, 0, 8, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Arm_Color_mesh_layer_1_vtx_2[16] = {
	{{ {62, -28, -25}, 0, {368, 240}, {53, 174, 174, 255} }},
	{{ {49, -32, -29}, 0, {368, 240}, {53, 174, 174, 255} }},
	{{ {49, -8, -39}, 0, {368, 368}, {53, 0, 140, 255} }},
	{{ {49, -42, -5}, 0, {496, 240}, {53, 140, 0, 255} }},
	{{ {62, -36, -5}, 0, {496, 240}, {53, 140, 0, 255} }},
	{{ {62, -28, 15}, 0, {624, 240}, {53, 174, 82, 255} }},
	{{ {49, -32, 19}, 0, {624, 240}, {53, 174, 82, 255} }},
	{{ {49, -8, 29}, 0, {624, 368}, {53, 0, 116, 255} }},
	{{ {62, -8, 23}, 0, {624, 368}, {53, 0, 116, 255} }},
	{{ {49, 15, 19}, 0, {624, 496}, {53, 82, 82, 255} }},
	{{ {62, 11, 15}, 0, {624, 496}, {53, 82, 82, 255} }},
	{{ {49, 25, -5}, 0, {496, 496}, {53, 116, 0, 255} }},
	{{ {62, 19, -5}, 0, {496, 496}, {53, 116, 0, 255} }},
	{{ {49, 15, -29}, 0, {368, 496}, {53, 82, 174, 255} }},
	{{ {62, 11, -25}, 0, {368, 496}, {53, 82, 174, 255} }},
	{{ {62, -8, -33}, 0, {368, 368}, {53, 0, 140, 255} }},
};

Gfx landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Left_Arm_Color_mesh_layer_1_vtx_2 + 0, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 5, 3, 4, 0),
	gsSP2Triangles(5, 6, 3, 0, 5, 7, 6, 0),
	gsSP2Triangles(5, 8, 7, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 10, 11, 9, 0),
	gsSP2Triangles(10, 12, 11, 0, 12, 13, 11, 0),
	gsSP2Triangles(12, 14, 13, 0, 15, 13, 14, 0),
	gsSP2Triangles(15, 2, 13, 0, 0, 2, 15, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Forearm_mesh_layer_1_vtx_0[46] = {
	{{ {11, -27, -23}, 0, {368, 112}, {244, 167, 167, 255} }},
	{{ {5, -33, -5}, 0, {496, -16}, {195, 145, 0, 255} }},
	{{ {5, -26, -22}, 0, {368, -16}, {195, 177, 177, 255} }},
	{{ {11, -34, -5}, 0, {496, 112}, {244, 130, 0, 255} }},
	{{ {57, -24, -21}, 0, {368, 240}, {66, 179, 179, 255} }},
	{{ {57, -31, -5}, 0, {496, 240}, {65, 147, 0, 255} }},
	{{ {68, -8, -5}, 0, {496, 368}, {127, 0, 0, 255} }},
	{{ {57, -8, -27}, 0, {368, 368}, {65, 0, 147, 255} }},
	{{ {11, -8, -30}, 0, {240, 368}, {244, 0, 130, 255} }},
	{{ {11, -27, -23}, 0, {240, 240}, {244, 167, 167, 255} }},
	{{ {5, -8, -29}, 0, {112, 368}, {195, 0, 145, 255} }},
	{{ {5, -26, -22}, 0, {112, 240}, {195, 177, 177, 255} }},
	{{ {5, 9, -22}, 0, {112, 496}, {195, 79, 177, 255} }},
	{{ {11, 10, -23}, 0, {240, 496}, {244, 89, 167, 255} }},
	{{ {57, 7, -21}, 0, {368, 496}, {66, 77, 179, 255} }},
	{{ {57, 14, -5}, 0, {496, 496}, {65, 109, 1, 255} }},
	{{ {11, 10, -23}, 0, {368, 624}, {244, 89, 167, 255} }},
	{{ {11, 17, -5}, 0, {496, 624}, {244, 126, 0, 255} }},
	{{ {5, 9, -22}, 0, {368, 752}, {195, 79, 177, 255} }},
	{{ {5, 16, -5}, 0, {496, 752}, {195, 111, 0, 255} }},
	{{ {-19, -8, -5}, 0, {496, 880}, {129, 0, 0, 255} }},
	{{ {5, -8, -29}, 0, {368, 880}, {195, 0, 145, 255} }},
	{{ {5, -26, -22}, 0, {368, 1008}, {195, 177, 177, 255} }},
	{{ {5, -33, -5}, 0, {496, 1008}, {195, 145, 0, 255} }},
	{{ {5, -26, 12}, 0, {624, 1008}, {195, 177, 79, 255} }},
	{{ {5, -8, 19}, 0, {624, 880}, {195, 0, 111, 255} }},
	{{ {5, 9, 12}, 0, {624, 752}, {195, 79, 79, 255} }},
	{{ {11, 10, 13}, 0, {624, 624}, {245, 89, 89, 255} }},
	{{ {57, 7, 11}, 0, {624, 496}, {65, 77, 77, 255} }},
	{{ {57, -8, 17}, 0, {624, 368}, {65, 1, 109, 255} }},
	{{ {11, -8, 20}, 0, {752, 368}, {244, 0, 126, 255} }},
	{{ {11, 10, 13}, 0, {752, 496}, {245, 89, 89, 255} }},
	{{ {11, 10, 13}, 0, {752, 496}, {245, 89, 89, 255} }},
	{{ {5, -8, 19}, 0, {880, 368}, {195, 0, 111, 255} }},
	{{ {11, -8, 20}, 0, {752, 368}, {244, 0, 126, 255} }},
	{{ {5, 9, 12}, 0, {880, 496}, {195, 79, 79, 255} }},
	{{ {5, -26, 12}, 0, {880, 240}, {195, 177, 79, 255} }},
	{{ {11, -27, 13}, 0, {752, 240}, {244, 167, 89, 255} }},
	{{ {57, -8, 17}, 0, {624, 368}, {65, 1, 109, 255} }},
	{{ {57, -24, 11}, 0, {624, 240}, {66, 179, 77, 255} }},
	{{ {68, -8, -5}, 0, {496, 368}, {127, 0, 0, 255} }},
	{{ {57, -31, -5}, 0, {496, 240}, {65, 147, 0, 255} }},
	{{ {11, -27, 13}, 0, {624, 112}, {244, 167, 89, 255} }},
	{{ {11, -34, -5}, 0, {496, 112}, {244, 130, 0, 255} }},
	{{ {5, -26, 12}, 0, {624, -16}, {195, 177, 79, 255} }},
	{{ {5, -33, -5}, 0, {496, -16}, {195, 145, 0, 255} }},
};

Gfx landie_alt_collar_Left_Forearm_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Forearm_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 4, 7, 0),
	gsSP2Triangles(8, 7, 4, 0, 8, 4, 9, 0),
	gsSP2Triangles(10, 8, 9, 0, 10, 9, 11, 0),
	gsSP2Triangles(12, 8, 10, 0, 12, 13, 8, 0),
	gsSP2Triangles(13, 7, 8, 0, 13, 14, 7, 0),
	gsSP2Triangles(14, 6, 7, 0, 14, 15, 6, 0),
	gsSP2Triangles(16, 15, 14, 0, 16, 17, 15, 0),
	gsSP2Triangles(18, 17, 16, 0, 18, 19, 17, 0),
	gsSP2Triangles(20, 19, 18, 0, 20, 18, 21, 0),
	gsSP2Triangles(22, 20, 21, 0, 22, 23, 20, 0),
	gsSP2Triangles(24, 20, 23, 0, 24, 25, 20, 0),
	gsSP2Triangles(20, 25, 26, 0, 20, 26, 19, 0),
	gsSP2Triangles(19, 26, 27, 0, 19, 27, 17, 0),
	gsSP2Triangles(17, 27, 28, 0, 17, 28, 15, 0),
	gsSP2Triangles(28, 6, 15, 0, 28, 29, 6, 0),
	gsSP2Triangles(28, 30, 29, 0, 28, 31, 30, 0),
	gsSPVertex(landie_alt_collar_Left_Forearm_mesh_layer_1_vtx_0 + 32, 14, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(2, 1, 4, 0, 2, 4, 5, 0),
	gsSP2Triangles(6, 2, 5, 0, 6, 5, 7, 0),
	gsSP2Triangles(8, 6, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(9, 7, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Forearm_mesh_layer_5_vtx_0[5] = {
	{{ {57, 7, 11}, 0, {610, 808}, {10, 64, 109, 255} }},
	{{ {11, -8, 20}, 0, {128, -16}, {9, 43, 119, 255} }},
	{{ {57, -8, 17}, 0, {128, 807}, {8, 46, 118, 255} }},
	{{ {11, 10, 14}, 0, {610, -16}, {11, 89, 90, 255} }},
	{{ {11, 17, -5}, 0, {1008, -16}, {10, 119, 44, 255} }},
};

Gfx landie_alt_collar_Left_Forearm_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Forearm_mesh_layer_5_vtx_0 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP1Triangle(4, 3, 0, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_DL_mesh_layer_1_vtx_0[9] = {
	{{ {25, -25, -32}, 0, {368, 1008}, {206, 158, 193, 255} }},
	{{ {-20, -19, -7}, 0, {496, 880}, {142, 200, 0, 255} }},
	{{ {14, -3, -43}, 0, {368, 880}, {178, 215, 165, 255} }},
	{{ {30, -34, -7}, 0, {496, 1008}, {218, 135, 0, 255} }},
	{{ {25, -25, 18}, 0, {624, 1008}, {206, 158, 63, 255} }},
	{{ {14, -3, 28}, 0, {624, 880}, {178, 215, 91, 255} }},
	{{ {3, 19, 18}, 0, {624, 752}, {149, 19, 66, 255} }},
	{{ {-2, 28, -7}, 0, {496, 752}, {137, 45, 0, 255} }},
	{{ {3, 19, -32}, 0, {368, 752}, {149, 19, 190, 255} }},
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_DL_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 1, 3, 0, 4, 5, 1, 0),
	gsSP2Triangles(1, 5, 6, 0, 1, 6, 7, 0),
	gsSP2Triangles(1, 7, 8, 0, 1, 8, 2, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_DL_mesh_layer_1_vtx_1[37] = {
	{{ {55, -18, -37}, 0, {368, 112}, {33, 185, 156, 255} }},
	{{ {30, -34, -7}, 0, {496, -16}, {20, 131, 2, 255} }},
	{{ {25, -25, -32}, 0, {368, -16}, {12, 173, 161, 255} }},
	{{ {63, -29, -7}, 0, {496, 112}, {48, 139, 7, 255} }},
	{{ {25, -25, 18}, 0, {624, -16}, {19, 175, 96, 255} }},
	{{ {55, -18, 18}, 0, {624, 112}, {37, 179, 94, 255} }},
	{{ {81, -3, 14}, 0, {624, 240}, {86, 214, 84, 255} }},
	{{ {89, -6, -7}, 0, {496, 240}, {117, 208, 9, 255} }},
	{{ {82, -12, -26}, 0, {368, 240}, {89, 199, 185, 255} }},
	{{ {55, -18, -37}, 0, {240, 240}, {33, 185, 156, 255} }},
	{{ {44, 10, -42}, 0, {240, 368}, {29, 17, 134, 255} }},
	{{ {77, 22, -32}, 0, {368, 368}, {75, 30, 158, 255} }},
	{{ {62, 43, -28}, 0, {368, 496}, {35, 91, 174, 255} }},
	{{ {32, 38, -32}, 0, {240, 496}, {231, 85, 165, 255} }},
	{{ {90, 26, -7}, 0, {496, 368}, {118, 46, 0, 255} }},
	{{ {66, 50, -7}, 0, {496, 496}, {47, 118, 0, 255} }},
	{{ {32, 38, -32}, 0, {368, 624}, {231, 85, 165, 255} }},
	{{ {28, 49, -7}, 0, {496, 624}, {214, 120, 0, 255} }},
	{{ {3, 19, -32}, 0, {368, 752}, {210, 72, 162, 255} }},
	{{ {-2, 28, -7}, 0, {496, 752}, {184, 105, 0, 255} }},
	{{ {32, 38, 18}, 0, {624, 624}, {232, 85, 91, 255} }},
	{{ {3, 19, 18}, 0, {624, 752}, {210, 73, 94, 255} }},
	{{ {62, 43, 14}, 0, {624, 496}, {34, 91, 82, 255} }},
	{{ {77, 22, 18}, 0, {624, 368}, {74, 30, 99, 255} }},
	{{ {44, 10, 28}, 0, {752, 368}, {12, 6, 126, 255} }},
	{{ {32, 38, 18}, 0, {752, 496}, {232, 85, 91, 255} }},
	{{ {14, -3, 28}, 0, {880, 368}, {253, 1, 127, 255} }},
	{{ {3, 19, 18}, 0, {880, 496}, {210, 73, 94, 255} }},
	{{ {25, -25, 18}, 0, {880, 240}, {19, 175, 96, 255} }},
	{{ {55, -18, 18}, 0, {752, 240}, {37, 179, 94, 255} }},
	{{ {14, -3, -43}, 0, {112, 368}, {248, 3, 129, 255} }},
	{{ {25, -25, -32}, 0, {112, 240}, {12, 173, 161, 255} }},
	{{ {14, -3, -43}, 0, {112, 368}, {248, 3, 129, 255} }},
	{{ {44, 10, -42}, 0, {240, 368}, {248, 2, 129, 255} }},
	{{ {55, -18, -37}, 0, {240, 240}, {33, 185, 156, 255} }},
	{{ {3, 19, -32}, 0, {112, 496}, {210, 72, 162, 255} }},
	{{ {32, 38, -32}, 0, {240, 496}, {231, 85, 165, 255} }},
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_DL_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 4, 1, 0, 3, 5, 4, 0),
	gsSP2Triangles(6, 5, 3, 0, 6, 3, 7, 0),
	gsSP2Triangles(3, 8, 7, 0, 3, 9, 8, 0),
	gsSP2Triangles(10, 8, 9, 0, 10, 11, 8, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 10, 13, 0),
	gsSP2Triangles(12, 14, 11, 0, 12, 15, 14, 0),
	gsSP2Triangles(16, 15, 12, 0, 16, 17, 15, 0),
	gsSP2Triangles(18, 17, 16, 0, 18, 19, 17, 0),
	gsSP2Triangles(19, 20, 17, 0, 19, 21, 20, 0),
	gsSP2Triangles(17, 20, 22, 0, 17, 22, 15, 0),
	gsSP2Triangles(22, 14, 15, 0, 22, 23, 14, 0),
	gsSP2Triangles(22, 24, 23, 0, 22, 25, 24, 0),
	gsSP2Triangles(25, 26, 24, 0, 25, 27, 26, 0),
	gsSP2Triangles(24, 26, 28, 0, 24, 28, 29, 0),
	gsSP2Triangles(23, 24, 29, 0, 23, 29, 6, 0),
	gsSP2Triangles(14, 23, 6, 0, 14, 6, 7, 0),
	gsSP2Triangles(14, 7, 8, 0, 14, 8, 11, 0),
	gsSP1Triangle(30, 9, 31, 0),
	gsSPVertex(landie_alt_collar_Left_Hand_DL_mesh_layer_1_vtx_1 + 32, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP1Triangle(3, 4, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_DL_mesh_layer_1_vtx_2[24] = {
	{{ {30, -34, -7}, 0, {496, -16}, {248, 129, 2, 255} }},
	{{ {25, -25, -32}, 0, {368, -16}, {244, 164, 169, 255} }},
	{{ {38, -24, -35}, 0, {368, -16}, {244, 158, 176, 255} }},
	{{ {44, -35, -8}, 0, {496, -16}, {248, 129, 255, 255} }},
	{{ {14, -3, -43}, 0, {368, 880}, {220, 237, 136, 255} }},
	{{ {38, -24, -35}, 0, {368, 1008}, {244, 158, 176, 255} }},
	{{ {25, -25, -32}, 0, {368, 1008}, {244, 164, 169, 255} }},
	{{ {25, 3, -46}, 0, {368, 880}, {220, 239, 136, 255} }},
	{{ {3, 19, -32}, 0, {368, 752}, {175, 44, 169, 255} }},
	{{ {11, 30, -35}, 0, {368, 752}, {169, 49, 177, 255} }},
	{{ {6, 41, -8}, 0, {496, 752}, {149, 69, 255, 255} }},
	{{ {-2, 28, -7}, 0, {496, 752}, {149, 69, 2, 255} }},
	{{ {3, 19, 18}, 0, {624, 752}, {182, 49, 91, 255} }},
	{{ {11, 30, 19}, 0, {624, 752}, {174, 55, 80, 255} }},
	{{ {14, -3, 28}, 0, {880, 368}, {232, 243, 124, 255} }},
	{{ {25, -25, 18}, 0, {880, 240}, {253, 168, 91, 255} }},
	{{ {38, -24, 19}, 0, {880, 240}, {252, 158, 81, 255} }},
	{{ {25, 3, 31}, 0, {880, 368}, {231, 245, 124, 255} }},
	{{ {3, 19, 18}, 0, {880, 496}, {182, 49, 91, 255} }},
	{{ {11, 30, 19}, 0, {880, 496}, {174, 55, 80, 255} }},
	{{ {30, -34, -7}, 0, {496, 1008}, {248, 129, 2, 255} }},
	{{ {38, -24, 19}, 0, {624, 1008}, {252, 158, 81, 255} }},
	{{ {25, -25, 18}, 0, {624, 1008}, {253, 168, 91, 255} }},
	{{ {44, -35, -8}, 0, {496, 1008}, {248, 129, 255, 255} }},
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_DL_mesh_layer_1_vtx_2 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(8, 7, 4, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 8, 11, 10, 0),
	gsSP2Triangles(12, 10, 11, 0, 12, 13, 10, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 16, 17, 0),
	gsSP2Triangles(18, 14, 17, 0, 18, 17, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 23, 21, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_DL_mesh_layer_5_vtx_0[7] = {
	{{ {62, 43, -28}, 0, {416, 115}, {38, 55, 148, 255} }},
	{{ {44, 10, -42}, 0, {-16, 748}, {28, 17, 133, 255} }},
	{{ {32, 38, -32}, 0, {623, 748}, {9, 44, 137, 255} }},
	{{ {77, 22, -33}, 0, {-16, 122}, {75, 30, 158, 255} }},
	{{ {90, 26, -7}, 0, {-16, -244}, {106, 38, 198, 255} }},
	{{ {82, -12, -27}, 0, {416, 115}, {68, 250, 149, 255} }},
	{{ {55, -18, -37}, 0, {623, 748}, {46, 253, 138, 255} }},
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_DL_mesh_layer_5_vtx_0 + 0, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 4, 5, 3, 0),
	gsSP2Triangles(1, 3, 5, 0, 1, 5, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_vtx_0[9] = {
	{{ {25, -13, -32}, 0, {368, 1008}, {241, 163, 171, 255} }},
	{{ {30, -22, -7}, 0, {496, 1008}, {249, 129, 1, 255} }},
	{{ {-20, -7, -7}, 0, {496, 880}, {142, 200, 0, 255} }},
	{{ {25, -13, 18}, 0, {624, 1008}, {247, 165, 88, 255} }},
	{{ {14, 8, 28}, 0, {624, 880}, {222, 239, 121, 255} }},
	{{ {3, 30, 18}, 0, {624, 752}, {180, 49, 89, 255} }},
	{{ {-2, 39, -7}, 0, {496, 752}, {153, 75, 1, 255} }},
	{{ {3, 30, -32}, 0, {368, 752}, {176, 46, 169, 255} }},
	{{ {14, 8, -43}, 0, {368, 880}, {216, 237, 137, 255} }},
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 1, 0),
	gsSP2Triangles(3, 4, 2, 0, 2, 4, 5, 0),
	gsSP2Triangles(2, 5, 6, 0, 2, 6, 7, 0),
	gsSP2Triangles(2, 7, 8, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_vtx_1[39] = {
	{{ {14, 8, -43}, 0, {112, 368}, {216, 237, 137, 255} }},
	{{ {57, -7, -37}, 0, {240, 240}, {33, 199, 147, 255} }},
	{{ {25, -13, -32}, 0, {112, 240}, {241, 163, 171, 255} }},
	{{ {46, 21, -42}, 0, {240, 368}, {13, 7, 130, 255} }},
	{{ {3, 30, -32}, 0, {112, 496}, {176, 46, 169, 255} }},
	{{ {33, 51, -33}, 0, {240, 496}, {229, 68, 152, 255} }},
	{{ {63, 63, -29}, 0, {368, 496}, {18, 85, 163, 255} }},
	{{ {87, 36, -33}, 0, {368, 368}, {66, 23, 150, 255} }},
	{{ {107, 43, -8}, 0, {496, 368}, {117, 43, 231, 255} }},
	{{ {66, 74, -10}, 0, {496, 496}, {24, 125, 253, 255} }},
	{{ {33, 51, -33}, 0, {368, 624}, {229, 68, 152, 255} }},
	{{ {28, 64, -8}, 0, {496, 624}, {200, 114, 0, 255} }},
	{{ {3, 30, -32}, 0, {368, 752}, {176, 46, 169, 255} }},
	{{ {-2, 39, -7}, 0, {496, 752}, {153, 75, 1, 255} }},
	{{ {33, 51, 17}, 0, {624, 624}, {226, 79, 95, 255} }},
	{{ {3, 30, 18}, 0, {624, 752}, {180, 49, 89, 255} }},
	{{ {63, 63, 11}, 0, {624, 496}, {19, 90, 88, 255} }},
	{{ {87, 36, 17}, 0, {624, 368}, {63, 29, 106, 255} }},
	{{ {46, 21, 27}, 0, {752, 368}, {10, 6, 126, 255} }},
	{{ {33, 51, 17}, 0, {752, 496}, {226, 79, 95, 255} }},
	{{ {14, 8, 28}, 0, {880, 368}, {222, 239, 121, 255} }},
	{{ {3, 30, 18}, 0, {880, 496}, {180, 49, 89, 255} }},
	{{ {25, -13, 18}, 0, {880, 240}, {247, 165, 88, 255} }},
	{{ {57, -7, 18}, 0, {752, 240}, {33, 178, 95, 255} }},
	{{ {89, 9, 14}, 0, {624, 240}, {75, 205, 89, 255} }},
	{{ {99, 6, -7}, 0, {496, 240}, {110, 193, 6, 255} }},
	{{ {65, -18, -7}, 0, {496, 112}, {43, 136, 6, 255} }},
	{{ {57, -7, 18}, 0, {624, 112}, {33, 178, 95, 255} }},
	{{ {25, -13, 18}, 0, {624, -16}, {247, 165, 88, 255} }},
	{{ {30, -22, -7}, 0, {496, -16}, {249, 129, 1, 255} }},
	{{ {57, -7, -37}, 0, {368, 112}, {33, 199, 147, 255} }},
	{{ {25, -13, -32}, 0, {368, -16}, {241, 163, 171, 255} }},
	{{ {65, -18, -7}, 0, {496, 112}, {43, 136, 6, 255} }},
	{{ {88, 0, -26}, 0, {368, 240}, {77, 189, 181, 255} }},
	{{ {99, 6, -7}, 0, {496, 240}, {110, 193, 6, 255} }},
	{{ {57, -7, -37}, 0, {240, 240}, {33, 199, 147, 255} }},
	{{ {46, 21, -42}, 0, {240, 368}, {13, 7, 130, 255} }},
	{{ {87, 36, -33}, 0, {368, 368}, {66, 23, 150, 255} }},
	{{ {107, 43, -8}, 0, {496, 368}, {117, 43, 231, 255} }},
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(6, 3, 5, 0, 6, 7, 3, 0),
	gsSP2Triangles(6, 8, 7, 0, 6, 9, 8, 0),
	gsSP2Triangles(10, 9, 6, 0, 10, 11, 9, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 13, 11, 0),
	gsSP2Triangles(13, 14, 11, 0, 13, 15, 14, 0),
	gsSP2Triangles(11, 14, 16, 0, 11, 16, 9, 0),
	gsSP2Triangles(16, 8, 9, 0, 16, 17, 8, 0),
	gsSP2Triangles(16, 18, 17, 0, 16, 19, 18, 0),
	gsSP2Triangles(19, 20, 18, 0, 19, 21, 20, 0),
	gsSP2Triangles(18, 20, 22, 0, 18, 22, 23, 0),
	gsSP2Triangles(17, 18, 23, 0, 17, 23, 24, 0),
	gsSP2Triangles(8, 17, 24, 0, 8, 24, 25, 0),
	gsSP2Triangles(24, 26, 25, 0, 24, 27, 26, 0),
	gsSP2Triangles(26, 27, 28, 0, 26, 28, 29, 0),
	gsSP2Triangles(30, 26, 29, 0, 30, 29, 31, 0),
	gsSPVertex(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_vtx_1 + 32, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 1, 3, 0, 4, 5, 1, 0),
	gsSP2Triangles(6, 1, 5, 0, 6, 2, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_vtx_2[24] = {
	{{ {30, -22, -7}, 0, {496, -16}, {249, 129, 1, 255} }},
	{{ {25, -13, -32}, 0, {368, -16}, {241, 163, 171, 255} }},
	{{ {38, -13, -35}, 0, {368, -16}, {244, 158, 176, 255} }},
	{{ {44, -24, -8}, 0, {496, -16}, {248, 129, 255, 255} }},
	{{ {14, 8, -43}, 0, {368, 880}, {216, 237, 137, 255} }},
	{{ {38, -13, -35}, 0, {368, 1008}, {244, 158, 176, 255} }},
	{{ {25, -13, -32}, 0, {368, 1008}, {241, 163, 171, 255} }},
	{{ {25, 14, -46}, 0, {368, 880}, {220, 239, 136, 255} }},
	{{ {3, 30, -32}, 0, {368, 752}, {176, 46, 169, 255} }},
	{{ {11, 41, -35}, 0, {368, 752}, {169, 48, 177, 255} }},
	{{ {6, 52, -8}, 0, {496, 752}, {149, 69, 255, 255} }},
	{{ {-2, 39, -7}, 0, {496, 752}, {153, 75, 1, 255} }},
	{{ {3, 30, 18}, 0, {624, 752}, {180, 49, 89, 255} }},
	{{ {11, 41, 19}, 0, {624, 752}, {174, 55, 80, 255} }},
	{{ {14, 8, 28}, 0, {880, 368}, {222, 239, 121, 255} }},
	{{ {25, -13, 18}, 0, {880, 240}, {247, 165, 88, 255} }},
	{{ {38, -13, 19}, 0, {880, 240}, {252, 158, 81, 255} }},
	{{ {25, 14, 31}, 0, {880, 368}, {231, 245, 124, 255} }},
	{{ {3, 30, 18}, 0, {880, 496}, {180, 49, 89, 255} }},
	{{ {11, 41, 19}, 0, {880, 496}, {174, 55, 80, 255} }},
	{{ {30, -22, -7}, 0, {496, 1008}, {249, 129, 1, 255} }},
	{{ {38, -13, 19}, 0, {624, 1008}, {252, 158, 81, 255} }},
	{{ {25, -13, 18}, 0, {624, 1008}, {247, 165, 88, 255} }},
	{{ {44, -24, -8}, 0, {496, 1008}, {248, 129, 255, 255} }},
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_vtx_2 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(8, 7, 4, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 8, 11, 10, 0),
	gsSP2Triangles(12, 10, 11, 0, 12, 13, 10, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 16, 17, 0),
	gsSP2Triangles(18, 14, 17, 0, 18, 17, 19, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 23, 21, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_5_vtx_0[7] = {
	{{ {63, 62, -30}, 0, {416, 115}, {26, 45, 140, 255} }},
	{{ {46, 21, -42}, 0, {-16, 748}, {13, 7, 130, 255} }},
	{{ {33, 51, -33}, 0, {623, 748}, {229, 68, 152, 255} }},
	{{ {87, 36, -33}, 0, {-16, 122}, {66, 23, 150, 255} }},
	{{ {107, 43, -8}, 0, {-16, -244}, {117, 43, 231, 255} }},
	{{ {88, 0, -27}, 0, {416, 115}, {57, 241, 144, 255} }},
	{{ {57, -7, -37}, 0, {623, 748}, {33, 199, 147, 255} }},
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_5_vtx_0 + 0, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 4, 5, 3, 0),
	gsSP2Triangles(1, 3, 5, 0, 1, 5, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Arm_Color_mesh_layer_1_vtx_0[43] = {
	{{ {12, -34, 32}, 0, {368, 112}, {232, 168, 88, 255} }},
	{{ {-8, -24, 22}, 0, {368, -16}, {161, 196, 60, 255} }},
	{{ {-8, -31, 6}, 0, {496, -16}, {162, 171, 0, 255} }},
	{{ {12, -44, 6}, 0, {496, 112}, {231, 131, 0, 255} }},
	{{ {-8, -24, -10}, 0, {624, -16}, {161, 196, 196, 255} }},
	{{ {12, -34, -20}, 0, {624, 112}, {232, 168, 168, 255} }},
	{{ {62, -36, 6}, 0, {496, 240}, {21, 131, 0, 255} }},
	{{ {62, -28, -14}, 0, {624, 240}, {22, 168, 168, 255} }},
	{{ {62, -28, 26}, 0, {368, 240}, {22, 168, 88, 255} }},
	{{ {-8, -8, 28}, 0, {112, 368}, {162, 0, 85, 255} }},
	{{ {-8, -24, 22}, 0, {112, 240}, {161, 196, 60, 255} }},
	{{ {12, -34, 32}, 0, {240, 240}, {232, 168, 88, 255} }},
	{{ {12, -8, 42}, 0, {240, 368}, {231, 0, 125, 255} }},
	{{ {62, -8, 34}, 0, {368, 368}, {21, 0, 125, 255} }},
	{{ {12, 17, 32}, 0, {240, 496}, {232, 88, 88, 255} }},
	{{ {62, 11, 26}, 0, {368, 496}, {22, 88, 88, 255} }},
	{{ {-8, 7, 22}, 0, {112, 496}, {161, 60, 60, 255} }},
	{{ {12, 17, -20}, 0, {752, 496}, {232, 88, 168, 255} }},
	{{ {-8, -8, -16}, 0, {880, 368}, {162, 0, 171, 255} }},
	{{ {-8, 7, -10}, 0, {880, 496}, {161, 60, 196, 255} }},
	{{ {12, -8, -30}, 0, {752, 368}, {231, 0, 131, 255} }},
	{{ {62, 11, -14}, 0, {624, 496}, {22, 88, 168, 255} }},
	{{ {62, -8, -22}, 0, {624, 368}, {21, 0, 131, 255} }},
	{{ {12, -34, -20}, 0, {752, 240}, {232, 168, 168, 255} }},
	{{ {-8, -24, -10}, 0, {880, 240}, {161, 196, 196, 255} }},
	{{ {12, 17, 32}, 0, {368, 624}, {232, 88, 88, 255} }},
	{{ {62, 19, 6}, 0, {496, 496}, {21, 125, 0, 255} }},
	{{ {12, 27, 6}, 0, {496, 624}, {231, 125, 0, 255} }},
	{{ {12, 17, -20}, 0, {624, 624}, {232, 88, 168, 255} }},
	{{ {-8, 14, 6}, 0, {496, 752}, {162, 85, 0, 255} }},
	{{ {-8, 7, -10}, 0, {624, 752}, {161, 60, 196, 255} }},
	{{ {-17, -8, 6}, 0, {496, 880}, {129, 0, 0, 255} }},
	{{ {-17, -8, 6}, 0, {496, 880}, {129, 0, 0, 255} }},
	{{ {-8, 7, -10}, 0, {624, 752}, {161, 60, 196, 255} }},
	{{ {-8, -8, -16}, 0, {624, 880}, {162, 0, 171, 255} }},
	{{ {-8, -24, -10}, 0, {624, 1008}, {161, 196, 196, 255} }},
	{{ {-8, -31, 6}, 0, {496, 1008}, {162, 171, 0, 255} }},
	{{ {-8, -24, 22}, 0, {368, 1008}, {161, 196, 60, 255} }},
	{{ {-8, -8, 28}, 0, {368, 880}, {162, 0, 85, 255} }},
	{{ {-8, 7, 22}, 0, {368, 752}, {161, 60, 60, 255} }},
	{{ {-8, 14, 6}, 0, {496, 752}, {162, 85, 0, 255} }},
	{{ {12, 27, 6}, 0, {496, 624}, {231, 125, 0, 255} }},
	{{ {12, 17, 32}, 0, {368, 624}, {232, 88, 88, 255} }},
};

Gfx landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Arm_Color_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 3, 5, 0, 6, 5, 7, 0),
	gsSP2Triangles(8, 3, 6, 0, 8, 0, 3, 0),
	gsSP2Triangles(9, 10, 11, 0, 9, 11, 12, 0),
	gsSP2Triangles(12, 11, 8, 0, 12, 8, 13, 0),
	gsSP2Triangles(14, 12, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 12, 14, 0, 16, 9, 12, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 20, 18, 0),
	gsSP2Triangles(21, 20, 17, 0, 21, 22, 20, 0),
	gsSP2Triangles(22, 23, 20, 0, 22, 7, 23, 0),
	gsSP2Triangles(20, 23, 24, 0, 20, 24, 18, 0),
	gsSP2Triangles(25, 15, 26, 0, 25, 26, 27, 0),
	gsSP2Triangles(27, 26, 21, 0, 27, 21, 28, 0),
	gsSP2Triangles(29, 27, 28, 0, 29, 28, 30, 0),
	gsSP1Triangle(31, 29, 30, 0),
	gsSPVertex(landie_alt_collar_Right_Arm_Color_mesh_layer_1_vtx_0 + 32, 11, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(3, 4, 0, 0, 5, 0, 4, 0),
	gsSP2Triangles(5, 6, 0, 0, 0, 6, 7, 0),
	gsSP2Triangles(0, 7, 8, 0, 7, 9, 8, 0),
	gsSP1Triangle(7, 10, 9, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Arm_Color_mesh_layer_1_vtx_1[9] = {
	{{ {67, -8, 6}, 0, {496, 368}, {127, 0, 0, 255} }},
	{{ {62, -8, 34}, 0, {368, 368}, {124, 0, 26, 255} }},
	{{ {62, -28, 26}, 0, {368, 240}, {124, 238, 18, 255} }},
	{{ {62, 11, 26}, 0, {368, 496}, {124, 18, 18, 255} }},
	{{ {62, 19, 6}, 0, {496, 496}, {124, 26, 0, 255} }},
	{{ {62, 11, -14}, 0, {624, 496}, {124, 18, 238, 255} }},
	{{ {62, -8, -22}, 0, {624, 368}, {124, 0, 230, 255} }},
	{{ {62, -28, -14}, 0, {624, 240}, {124, 238, 238, 255} }},
	{{ {62, -36, 6}, 0, {496, 240}, {124, 230, 0, 255} }},
};

Gfx landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Arm_Color_mesh_layer_1_vtx_1 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(3, 0, 4, 0, 5, 4, 0, 0),
	gsSP2Triangles(5, 0, 6, 0, 0, 7, 6, 0),
	gsSP2Triangles(0, 8, 7, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Arm_Color_mesh_layer_1_vtx_2[16] = {
	{{ {62, -28, 26}, 0, {368, 240}, {53, 174, 82, 255} }},
	{{ {62, -8, 34}, 0, {368, 368}, {53, 0, 116, 255} }},
	{{ {49, -8, 40}, 0, {368, 368}, {53, 0, 116, 255} }},
	{{ {49, 15, 30}, 0, {368, 496}, {53, 82, 82, 255} }},
	{{ {62, 11, 26}, 0, {368, 496}, {53, 82, 82, 255} }},
	{{ {62, 19, 6}, 0, {496, 496}, {53, 116, 0, 255} }},
	{{ {49, 25, 6}, 0, {496, 496}, {53, 116, 0, 255} }},
	{{ {62, 11, -14}, 0, {624, 496}, {53, 82, 174, 255} }},
	{{ {49, 15, -18}, 0, {624, 496}, {53, 82, 174, 255} }},
	{{ {62, -8, -22}, 0, {624, 368}, {53, 0, 140, 255} }},
	{{ {49, -8, -28}, 0, {624, 368}, {53, 0, 140, 255} }},
	{{ {62, -28, -14}, 0, {624, 240}, {53, 174, 174, 255} }},
	{{ {49, -32, -18}, 0, {624, 240}, {53, 174, 174, 255} }},
	{{ {49, -42, 6}, 0, {496, 240}, {53, 140, 0, 255} }},
	{{ {62, -36, 6}, 0, {496, 240}, {53, 140, 0, 255} }},
	{{ {49, -32, 30}, 0, {368, 240}, {53, 174, 82, 255} }},
};

Gfx landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Right_Arm_Color_mesh_layer_1_vtx_2 + 0, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(1, 4, 3, 0, 5, 3, 4, 0),
	gsSP2Triangles(5, 6, 3, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 8, 6, 0, 9, 8, 7, 0),
	gsSP2Triangles(9, 10, 8, 0, 11, 10, 9, 0),
	gsSP2Triangles(11, 12, 10, 0, 11, 13, 12, 0),
	gsSP2Triangles(11, 14, 13, 0, 0, 13, 14, 0),
	gsSP2Triangles(0, 15, 13, 0, 0, 2, 15, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Forearm_mesh_layer_1_vtx_0[45] = {
	{{ {11, -27, 24}, 0, {368, 112}, {244, 167, 89, 255} }},
	{{ {5, -26, 23}, 0, {368, -16}, {195, 177, 79, 255} }},
	{{ {5, -33, 6}, 0, {496, -16}, {195, 145, 0, 255} }},
	{{ {11, -34, 6}, 0, {496, 112}, {244, 130, 0, 255} }},
	{{ {5, -26, -11}, 0, {624, -16}, {195, 177, 177, 255} }},
	{{ {11, -27, -12}, 0, {624, 112}, {244, 167, 167, 255} }},
	{{ {57, -31, 6}, 0, {496, 240}, {65, 147, 0, 255} }},
	{{ {57, -24, -10}, 0, {624, 240}, {66, 179, 179, 255} }},
	{{ {68, -8, 6}, 0, {496, 368}, {127, 0, 0, 255} }},
	{{ {57, -8, -16}, 0, {624, 368}, {65, 1, 147, 255} }},
	{{ {11, -27, -12}, 0, {752, 240}, {244, 167, 167, 255} }},
	{{ {11, -8, -19}, 0, {752, 368}, {244, 0, 130, 255} }},
	{{ {5, -26, -11}, 0, {880, 240}, {195, 177, 177, 255} }},
	{{ {5, -8, -18}, 0, {880, 368}, {195, 0, 145, 255} }},
	{{ {11, 10, -12}, 0, {752, 496}, {245, 89, 167, 255} }},
	{{ {5, 9, -11}, 0, {880, 496}, {195, 79, 177, 255} }},
	{{ {57, 7, -10}, 0, {624, 496}, {65, 77, 179, 255} }},
	{{ {57, 14, 6}, 0, {496, 496}, {65, 109, 255, 255} }},
	{{ {11, 17, 6}, 0, {496, 624}, {244, 126, 0, 255} }},
	{{ {11, 10, -12}, 0, {624, 624}, {245, 89, 167, 255} }},
	{{ {5, 16, 6}, 0, {496, 752}, {195, 111, 0, 255} }},
	{{ {5, 9, -11}, 0, {624, 752}, {195, 79, 177, 255} }},
	{{ {-19, -8, 6}, 0, {496, 880}, {129, 0, 0, 255} }},
	{{ {5, -8, -18}, 0, {624, 880}, {195, 0, 145, 255} }},
	{{ {5, -26, -11}, 0, {624, 1008}, {195, 177, 177, 255} }},
	{{ {5, -33, 6}, 0, {496, 1008}, {195, 145, 0, 255} }},
	{{ {5, -26, 23}, 0, {368, 1008}, {195, 177, 79, 255} }},
	{{ {5, -8, 30}, 0, {368, 880}, {195, 0, 111, 255} }},
	{{ {5, 9, 23}, 0, {368, 752}, {195, 79, 79, 255} }},
	{{ {11, 10, 24}, 0, {368, 624}, {244, 89, 89, 255} }},
	{{ {57, 7, 22}, 0, {368, 496}, {66, 77, 77, 255} }},
	{{ {57, -8, 28}, 0, {368, 368}, {65, 0, 109, 255} }},
	{{ {11, 10, 24}, 0, {240, 496}, {244, 89, 89, 255} }},
	{{ {57, -8, 28}, 0, {368, 368}, {65, 0, 109, 255} }},
	{{ {57, 7, 22}, 0, {368, 496}, {66, 77, 77, 255} }},
	{{ {11, -8, 31}, 0, {240, 368}, {244, 0, 126, 255} }},
	{{ {5, 9, 23}, 0, {112, 496}, {195, 79, 79, 255} }},
	{{ {5, -8, 30}, 0, {112, 368}, {195, 0, 111, 255} }},
	{{ {11, -27, 24}, 0, {240, 240}, {244, 167, 89, 255} }},
	{{ {5, -26, 23}, 0, {112, 240}, {195, 177, 79, 255} }},
	{{ {57, -24, 22}, 0, {368, 240}, {66, 179, 77, 255} }},
	{{ {68, -8, 6}, 0, {496, 368}, {127, 0, 0, 255} }},
	{{ {57, -31, 6}, 0, {496, 240}, {65, 147, 0, 255} }},
	{{ {11, -34, 6}, 0, {496, 112}, {244, 130, 0, 255} }},
	{{ {11, -27, 24}, 0, {368, 112}, {244, 167, 89, 255} }},
};

Gfx landie_alt_collar_Right_Forearm_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Forearm_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 3, 5, 0, 6, 5, 7, 0),
	gsSP2Triangles(8, 6, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(9, 7, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSP2Triangles(14, 11, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 11, 14, 0, 16, 9, 11, 0),
	gsSP2Triangles(16, 8, 9, 0, 16, 17, 8, 0),
	gsSP2Triangles(18, 17, 16, 0, 18, 16, 19, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 19, 21, 0),
	gsSP2Triangles(22, 20, 21, 0, 22, 21, 23, 0),
	gsSP2Triangles(24, 22, 23, 0, 24, 25, 22, 0),
	gsSP2Triangles(26, 22, 25, 0, 26, 27, 22, 0),
	gsSP2Triangles(22, 27, 28, 0, 22, 28, 20, 0),
	gsSP2Triangles(28, 18, 20, 0, 28, 29, 18, 0),
	gsSP2Triangles(29, 17, 18, 0, 29, 30, 17, 0),
	gsSP2Triangles(30, 8, 17, 0, 30, 31, 8, 0),
	gsSPVertex(landie_alt_collar_Right_Forearm_mesh_layer_1_vtx_0 + 32, 13, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(5, 6, 3, 0, 5, 7, 6, 0),
	gsSP2Triangles(3, 6, 8, 0, 3, 8, 1, 0),
	gsSP2Triangles(9, 1, 8, 0, 9, 8, 10, 0),
	gsSP2Triangles(8, 11, 10, 0, 8, 12, 11, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Forearm_mesh_layer_5_vtx_0[5] = {
	{{ {57, 7, -10}, 0, {610, 808}, {10, 64, 147, 255} }},
	{{ {57, -8, -16}, 0, {128, 807}, {8, 46, 138, 255} }},
	{{ {11, -8, -19}, 0, {128, -16}, {9, 43, 137, 255} }},
	{{ {11, 10, -13}, 0, {610, -16}, {11, 89, 166, 255} }},
	{{ {11, 17, 6}, 0, {1008, -16}, {10, 119, 212, 255} }},
};

Gfx landie_alt_collar_Right_Forearm_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Forearm_mesh_layer_5_vtx_0 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP1Triangle(4, 0, 3, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_DL_mesh_layer_1_vtx_0[9] = {
	{{ {25, -25, 33}, 0, {368, 1008}, {206, 158, 63, 255} }},
	{{ {14, -3, 44}, 0, {368, 880}, {178, 215, 91, 255} }},
	{{ {-20, -19, 8}, 0, {496, 880}, {142, 200, 0, 255} }},
	{{ {3, 19, 33}, 0, {368, 752}, {149, 19, 66, 255} }},
	{{ {-2, 28, 8}, 0, {496, 752}, {137, 45, 0, 255} }},
	{{ {3, 19, -17}, 0, {624, 752}, {149, 19, 190, 255} }},
	{{ {14, -3, -27}, 0, {624, 880}, {178, 215, 165, 255} }},
	{{ {25, -25, -17}, 0, {624, 1008}, {206, 158, 193, 255} }},
	{{ {30, -34, 8}, 0, {496, 1008}, {218, 135, 0, 255} }},
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_DL_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(2, 3, 4, 0, 2, 4, 5, 0),
	gsSP2Triangles(2, 5, 6, 0, 7, 2, 6, 0),
	gsSP2Triangles(7, 8, 2, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_DL_mesh_layer_1_vtx_1[37] = {
	{{ {55, -18, 38}, 0, {368, 112}, {33, 185, 100, 255} }},
	{{ {25, -25, 33}, 0, {368, -16}, {12, 173, 95, 255} }},
	{{ {30, -34, 8}, 0, {496, -16}, {20, 131, 254, 255} }},
	{{ {63, -29, 8}, 0, {496, 112}, {48, 139, 249, 255} }},
	{{ {25, -25, -17}, 0, {624, -16}, {19, 175, 160, 255} }},
	{{ {55, -18, -17}, 0, {624, 112}, {37, 179, 162, 255} }},
	{{ {81, -3, -13}, 0, {624, 240}, {86, 214, 172, 255} }},
	{{ {89, -6, 8}, 0, {496, 240}, {117, 208, 247, 255} }},
	{{ {90, 26, 8}, 0, {496, 368}, {118, 46, 0, 255} }},
	{{ {77, 22, -17}, 0, {624, 368}, {74, 30, 157, 255} }},
	{{ {55, -18, -17}, 0, {752, 240}, {37, 179, 162, 255} }},
	{{ {44, 10, -27}, 0, {752, 368}, {12, 6, 130, 255} }},
	{{ {25, -25, -17}, 0, {880, 240}, {19, 175, 160, 255} }},
	{{ {14, -3, -27}, 0, {880, 368}, {253, 1, 129, 255} }},
	{{ {32, 38, -17}, 0, {752, 496}, {232, 85, 165, 255} }},
	{{ {3, 19, -17}, 0, {880, 496}, {210, 73, 162, 255} }},
	{{ {62, 43, -13}, 0, {624, 496}, {34, 91, 174, 255} }},
	{{ {66, 50, 8}, 0, {496, 496}, {47, 118, 0, 255} }},
	{{ {28, 49, 8}, 0, {496, 624}, {214, 120, 0, 255} }},
	{{ {32, 38, -17}, 0, {624, 624}, {232, 85, 165, 255} }},
	{{ {-2, 28, 8}, 0, {496, 752}, {184, 105, 0, 255} }},
	{{ {3, 19, -17}, 0, {624, 752}, {210, 73, 162, 255} }},
	{{ {3, 19, 33}, 0, {368, 752}, {210, 72, 94, 255} }},
	{{ {32, 38, 33}, 0, {368, 624}, {231, 85, 91, 255} }},
	{{ {62, 43, 29}, 0, {368, 496}, {35, 91, 82, 255} }},
	{{ {77, 22, 33}, 0, {368, 368}, {75, 30, 98, 255} }},
	{{ {44, 10, 43}, 0, {240, 368}, {29, 17, 122, 255} }},
	{{ {32, 38, 33}, 0, {240, 496}, {231, 85, 91, 255} }},
	{{ {82, -12, 27}, 0, {368, 240}, {89, 199, 71, 255} }},
	{{ {55, -18, 38}, 0, {240, 240}, {33, 185, 100, 255} }},
	{{ {14, -3, 44}, 0, {112, 368}, {248, 3, 127, 255} }},
	{{ {25, -25, 33}, 0, {112, 240}, {12, 173, 95, 255} }},
	{{ {14, -3, 44}, 0, {112, 368}, {248, 3, 127, 255} }},
	{{ {55, -18, 38}, 0, {240, 240}, {33, 185, 100, 255} }},
	{{ {44, 10, 43}, 0, {240, 368}, {248, 2, 127, 255} }},
	{{ {3, 19, 33}, 0, {112, 496}, {210, 72, 94, 255} }},
	{{ {32, 38, 33}, 0, {240, 496}, {231, 85, 91, 255} }},
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_DL_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 3, 5, 0, 6, 7, 3, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 6, 9, 0),
	gsSP2Triangles(9, 6, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSP2Triangles(14, 11, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 11, 14, 0, 16, 9, 11, 0),
	gsSP2Triangles(16, 8, 9, 0, 16, 17, 8, 0),
	gsSP2Triangles(18, 17, 16, 0, 18, 16, 19, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 19, 21, 0),
	gsSP2Triangles(22, 18, 20, 0, 22, 23, 18, 0),
	gsSP2Triangles(23, 17, 18, 0, 23, 24, 17, 0),
	gsSP2Triangles(24, 8, 17, 0, 24, 25, 8, 0),
	gsSP2Triangles(24, 26, 25, 0, 24, 27, 26, 0),
	gsSP2Triangles(26, 28, 25, 0, 26, 29, 28, 0),
	gsSP2Triangles(3, 28, 29, 0, 3, 7, 28, 0),
	gsSP2Triangles(8, 28, 7, 0, 8, 25, 28, 0),
	gsSP1Triangle(30, 31, 29, 0),
	gsSPVertex(landie_alt_collar_Right_Hand_DL_mesh_layer_1_vtx_1 + 32, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP1Triangle(3, 2, 4, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_DL_mesh_layer_1_vtx_2[24] = {
	{{ {30, -34, 8}, 0, {496, -16}, {248, 129, 254, 255} }},
	{{ {38, -24, 36}, 0, {368, -16}, {244, 158, 80, 255} }},
	{{ {25, -25, 33}, 0, {368, -16}, {244, 164, 87, 255} }},
	{{ {44, -35, 9}, 0, {496, -16}, {248, 129, 1, 255} }},
	{{ {14, -3, 44}, 0, {368, 880}, {220, 237, 120, 255} }},
	{{ {25, -25, 33}, 0, {368, 1008}, {244, 164, 87, 255} }},
	{{ {38, -24, 36}, 0, {368, 1008}, {244, 158, 80, 255} }},
	{{ {25, 3, 47}, 0, {368, 880}, {220, 239, 120, 255} }},
	{{ {3, 19, 33}, 0, {368, 752}, {175, 44, 87, 255} }},
	{{ {11, 30, 36}, 0, {368, 752}, {169, 49, 79, 255} }},
	{{ {6, 41, 9}, 0, {496, 752}, {149, 69, 1, 255} }},
	{{ {-2, 28, 8}, 0, {496, 752}, {149, 69, 254, 255} }},
	{{ {3, 19, -17}, 0, {624, 752}, {182, 49, 165, 255} }},
	{{ {11, 30, -18}, 0, {624, 752}, {174, 55, 176, 255} }},
	{{ {14, -3, -27}, 0, {880, 368}, {232, 243, 132, 255} }},
	{{ {38, -24, -18}, 0, {880, 240}, {252, 158, 175, 255} }},
	{{ {25, -25, -17}, 0, {880, 240}, {253, 168, 165, 255} }},
	{{ {25, 3, -30}, 0, {880, 368}, {231, 245, 132, 255} }},
	{{ {3, 19, -17}, 0, {880, 496}, {182, 49, 165, 255} }},
	{{ {11, 30, -18}, 0, {880, 496}, {174, 55, 176, 255} }},
	{{ {30, -34, 8}, 0, {496, 1008}, {248, 129, 254, 255} }},
	{{ {25, -25, -17}, 0, {624, 1008}, {253, 168, 165, 255} }},
	{{ {38, -24, -18}, 0, {624, 1008}, {252, 158, 175, 255} }},
	{{ {44, -35, 9}, 0, {496, 1008}, {248, 129, 1, 255} }},
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_DL_mesh_layer_1_vtx_2 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 4, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 10, 13, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 17, 15, 0),
	gsSP2Triangles(18, 17, 14, 0, 18, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_DL_mesh_layer_5_vtx_0[7] = {
	{{ {62, 43, 29}, 0, {416, 115}, {38, 55, 108, 255} }},
	{{ {32, 38, 33}, 0, {623, 748}, {9, 44, 119, 255} }},
	{{ {44, 10, 43}, 0, {-16, 748}, {28, 17, 123, 255} }},
	{{ {77, 22, 34}, 0, {-16, 122}, {75, 30, 98, 255} }},
	{{ {82, -12, 28}, 0, {416, 115}, {68, 250, 107, 255} }},
	{{ {55, -18, 38}, 0, {623, 748}, {46, 253, 118, 255} }},
	{{ {90, 26, 8}, 0, {-16, -244}, {106, 38, 58, 255} }},
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_DL_mesh_layer_5_vtx_0 + 0, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(2, 4, 3, 0, 2, 5, 4, 0),
	gsSP2Triangles(6, 3, 4, 0, 0, 3, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_vtx_0[9] = {
	{{ {26, -11, 33}, 0, {368, 1008}, {241, 163, 85, 255} }},
	{{ {-19, -5, 8}, 0, {496, 880}, {142, 200, 0, 255} }},
	{{ {31, -20, 8}, 0, {496, 1008}, {249, 129, 255, 255} }},
	{{ {15, 10, 44}, 0, {368, 880}, {216, 237, 119, 255} }},
	{{ {4, 32, 33}, 0, {368, 752}, {176, 46, 87, 255} }},
	{{ {-1, 41, 8}, 0, {496, 752}, {153, 75, 255, 255} }},
	{{ {4, 32, -17}, 0, {624, 752}, {180, 49, 167, 255} }},
	{{ {15, 10, -27}, 0, {624, 880}, {222, 239, 135, 255} }},
	{{ {26, -11, -17}, 0, {624, 1008}, {247, 165, 168, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(1, 3, 4, 0, 1, 4, 5, 0),
	gsSP2Triangles(1, 5, 6, 0, 1, 6, 7, 0),
	gsSP2Triangles(8, 1, 7, 0, 8, 2, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_vtx_1[36] = {
	{{ {15, 10, 44}, 0, {112, 368}, {216, 237, 119, 255} }},
	{{ {26, -11, 33}, 0, {112, 240}, {241, 163, 85, 255} }},
	{{ {58, -5, 38}, 0, {240, 240}, {33, 199, 109, 255} }},
	{{ {47, 23, 43}, 0, {240, 368}, {13, 7, 126, 255} }},
	{{ {89, 2, 27}, 0, {368, 240}, {77, 189, 75, 255} }},
	{{ {66, -16, 8}, 0, {496, 112}, {43, 136, 250, 255} }},
	{{ {100, 8, 8}, 0, {496, 240}, {110, 193, 250, 255} }},
	{{ {90, 11, -13}, 0, {624, 240}, {75, 205, 167, 255} }},
	{{ {58, -5, -17}, 0, {624, 112}, {33, 178, 161, 255} }},
	{{ {26, -11, -17}, 0, {624, -16}, {247, 165, 168, 255} }},
	{{ {31, -20, 8}, 0, {496, -16}, {249, 129, 255, 255} }},
	{{ {58, -5, 38}, 0, {368, 112}, {33, 199, 109, 255} }},
	{{ {26, -11, 33}, 0, {368, -16}, {241, 163, 85, 255} }},
	{{ {108, 45, 9}, 0, {496, 368}, {117, 43, 25, 255} }},
	{{ {88, 38, 34}, 0, {368, 368}, {66, 23, 106, 255} }},
	{{ {64, 65, 30}, 0, {368, 496}, {18, 85, 93, 255} }},
	{{ {67, 76, 11}, 0, {496, 496}, {24, 125, 3, 255} }},
	{{ {64, 65, -10}, 0, {624, 496}, {19, 90, 168, 255} }},
	{{ {88, 38, -16}, 0, {624, 368}, {63, 29, 150, 255} }},
	{{ {58, -5, -17}, 0, {752, 240}, {33, 178, 161, 255} }},
	{{ {47, 23, -26}, 0, {752, 368}, {10, 6, 130, 255} }},
	{{ {26, -11, -17}, 0, {880, 240}, {247, 165, 168, 255} }},
	{{ {15, 10, -27}, 0, {880, 368}, {222, 239, 135, 255} }},
	{{ {34, 54, -16}, 0, {752, 496}, {226, 79, 161, 255} }},
	{{ {4, 32, -17}, 0, {880, 496}, {180, 49, 167, 255} }},
	{{ {4, 32, 33}, 0, {112, 496}, {176, 46, 87, 255} }},
	{{ {34, 54, 34}, 0, {240, 496}, {229, 68, 104, 255} }},
	{{ {34, 54, 34}, 0, {368, 624}, {229, 68, 104, 255} }},
	{{ {29, 66, 9}, 0, {496, 624}, {200, 114, 0, 255} }},
	{{ {34, 54, -16}, 0, {624, 624}, {226, 79, 161, 255} }},
	{{ {-1, 41, 8}, 0, {496, 752}, {153, 75, 255, 255} }},
	{{ {4, 32, -17}, 0, {624, 752}, {180, 49, 167, 255} }},
	{{ {4, 32, 33}, 0, {368, 752}, {176, 46, 87, 255} }},
	{{ {29, 66, 9}, 0, {496, 624}, {200, 114, 0, 255} }},
	{{ {-1, 41, 8}, 0, {496, 752}, {153, 75, 255, 255} }},
	{{ {34, 54, 34}, 0, {368, 624}, {229, 68, 104, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 5, 4, 2, 0),
	gsSP2Triangles(5, 6, 4, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 5, 8, 0, 5, 9, 8, 0),
	gsSP2Triangles(5, 10, 9, 0, 11, 10, 5, 0),
	gsSP2Triangles(11, 12, 10, 0, 13, 6, 7, 0),
	gsSP2Triangles(13, 4, 6, 0, 13, 14, 4, 0),
	gsSP2Triangles(15, 14, 13, 0, 15, 13, 16, 0),
	gsSP2Triangles(17, 16, 13, 0, 17, 13, 18, 0),
	gsSP2Triangles(13, 7, 18, 0, 18, 7, 19, 0),
	gsSP2Triangles(18, 19, 20, 0, 20, 19, 21, 0),
	gsSP2Triangles(20, 21, 22, 0, 23, 20, 22, 0),
	gsSP2Triangles(23, 22, 24, 0, 17, 20, 23, 0),
	gsSP2Triangles(17, 18, 20, 0, 25, 0, 3, 0),
	gsSP2Triangles(25, 3, 26, 0, 15, 26, 3, 0),
	gsSP2Triangles(15, 3, 14, 0, 3, 4, 14, 0),
	gsSP2Triangles(27, 15, 16, 0, 27, 16, 28, 0),
	gsSP2Triangles(28, 16, 17, 0, 28, 17, 29, 0),
	gsSP2Triangles(30, 28, 29, 0, 30, 29, 31, 0),
	gsSPVertex(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_vtx_1 + 32, 4, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_vtx_2[24] = {
	{{ {31, -20, 8}, 0, {496, -16}, {249, 129, 255, 255} }},
	{{ {39, -11, 36}, 0, {368, -16}, {244, 158, 80, 255} }},
	{{ {26, -11, 33}, 0, {368, -16}, {241, 163, 85, 255} }},
	{{ {45, -22, 9}, 0, {496, -16}, {248, 129, 1, 255} }},
	{{ {15, 10, 44}, 0, {368, 880}, {216, 237, 119, 255} }},
	{{ {26, -11, 33}, 0, {368, 1008}, {241, 163, 85, 255} }},
	{{ {39, -11, 36}, 0, {368, 1008}, {244, 158, 80, 255} }},
	{{ {26, 16, 47}, 0, {368, 880}, {220, 239, 120, 255} }},
	{{ {4, 32, 33}, 0, {368, 752}, {176, 46, 87, 255} }},
	{{ {12, 43, 36}, 0, {368, 752}, {169, 48, 79, 255} }},
	{{ {7, 55, 9}, 0, {496, 752}, {149, 69, 1, 255} }},
	{{ {-1, 41, 8}, 0, {496, 752}, {153, 75, 255, 255} }},
	{{ {4, 32, -17}, 0, {624, 752}, {180, 49, 167, 255} }},
	{{ {12, 43, -18}, 0, {624, 752}, {174, 55, 176, 255} }},
	{{ {15, 10, -27}, 0, {880, 368}, {222, 239, 135, 255} }},
	{{ {39, -11, -18}, 0, {880, 240}, {252, 158, 175, 255} }},
	{{ {26, -11, -17}, 0, {880, 240}, {247, 165, 168, 255} }},
	{{ {26, 16, -30}, 0, {880, 368}, {231, 245, 132, 255} }},
	{{ {4, 32, -17}, 0, {880, 496}, {180, 49, 167, 255} }},
	{{ {12, 43, -18}, 0, {880, 496}, {174, 55, 176, 255} }},
	{{ {31, -20, 8}, 0, {496, 1008}, {249, 129, 255, 255} }},
	{{ {26, -11, -17}, 0, {624, 1008}, {247, 165, 168, 255} }},
	{{ {39, -11, -18}, 0, {624, 1008}, {252, 158, 175, 255} }},
	{{ {45, -22, 9}, 0, {496, 1008}, {248, 129, 1, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_vtx_2 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 4, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 10, 13, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 17, 15, 0),
	gsSP2Triangles(18, 17, 14, 0, 18, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_5_vtx_0[7] = {
	{{ {64, 65, 31}, 0, {416, 115}, {26, 45, 116, 255} }},
	{{ {34, 54, 34}, 0, {623, 748}, {229, 68, 104, 255} }},
	{{ {47, 23, 43}, 0, {-16, 748}, {13, 7, 126, 255} }},
	{{ {88, 38, 34}, 0, {-16, 122}, {66, 23, 106, 255} }},
	{{ {89, 2, 28}, 0, {416, 115}, {57, 241, 112, 255} }},
	{{ {58, -5, 38}, 0, {623, 748}, {33, 199, 109, 255} }},
	{{ {108, 45, 9}, 0, {-16, -244}, {117, 43, 25, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_5_vtx_0 + 0, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(2, 4, 3, 0, 2, 5, 4, 0),
	gsSP2Triangles(6, 3, 4, 0, 0, 3, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_vtx_0[9] = {
	{{ {26, -13, 33}, 0, {368, 1008}, {241, 162, 84, 255} }},
	{{ {-19, -7, 8}, 0, {496, 880}, {142, 200, 0, 255} }},
	{{ {31, -22, 8}, 0, {496, 1008}, {249, 129, 254, 255} }},
	{{ {15, 8, 44}, 0, {368, 880}, {213, 235, 118, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {175, 46, 87, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {155, 77, 4, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {180, 52, 169, 255} }},
	{{ {15, 8, -27}, 0, {624, 880}, {222, 239, 135, 255} }},
	{{ {26, -13, -17}, 0, {624, 1008}, {247, 165, 168, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(1, 3, 4, 0, 1, 4, 5, 0),
	gsSP2Triangles(1, 5, 6, 0, 1, 6, 7, 0),
	gsSP2Triangles(8, 1, 7, 0, 8, 2, 1, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_vtx_1[51] = {
	{{ {15, 8, 44}, 0, {112, 368}, {213, 235, 118, 255} }},
	{{ {26, -13, 33}, 0, {112, 240}, {241, 162, 84, 255} }},
	{{ {65, -7, 36}, 0, {240, 240}, {45, 183, 94, 255} }},
	{{ {65, 21, 45}, 0, {291, 347}, {47, 228, 115, 255} }},
	{{ {85, 0, 27}, 0, {368, 240}, {71, 180, 73, 255} }},
	{{ {64, -18, 8}, 0, {496, 112}, {49, 140, 244, 255} }},
	{{ {91, 8, -2}, 0, {496, 240}, {76, 193, 176, 255} }},
	{{ {76, 8, -9}, 0, {624, 240}, {58, 214, 151, 255} }},
	{{ {56, -7, -17}, 0, {624, 112}, {47, 184, 163, 255} }},
	{{ {26, -13, -17}, 0, {624, -16}, {247, 165, 168, 255} }},
	{{ {31, -22, 8}, 0, {496, -16}, {249, 129, 254, 255} }},
	{{ {65, -7, 36}, 0, {368, 112}, {45, 183, 94, 255} }},
	{{ {26, -13, 33}, 0, {368, -16}, {241, 162, 84, 255} }},
	{{ {72, 33, -14}, 0, {624, 368}, {53, 15, 141, 255} }},
	{{ {85, 37, -4}, 0, {496, 368}, {74, 19, 155, 255} }},
	{{ {78, 69, -2}, 0, {496, 496}, {39, 104, 194, 255} }},
	{{ {59, 63, -9}, 0, {624, 496}, {252, 92, 169, 255} }},
	{{ {45, 21, -27}, 0, {752, 368}, {20, 6, 131, 255} }},
	{{ {56, -7, -17}, 0, {752, 240}, {47, 184, 163, 255} }},
	{{ {26, -13, -17}, 0, {880, 240}, {247, 165, 168, 255} }},
	{{ {15, 8, -27}, 0, {880, 368}, {222, 239, 135, 255} }},
	{{ {33, 49, -17}, 0, {752, 496}, {228, 83, 164, 255} }},
	{{ {4, 30, -17}, 0, {880, 496}, {180, 52, 169, 255} }},
	{{ {64, 44, 50}, 0, {240, 496}, {25, 44, 117, 255} }},
	{{ {4, 30, 33}, 0, {112, 496}, {175, 46, 87, 255} }},
	{{ {79, 33, 37}, 0, {368, 368}, {63, 253, 110, 255} }},
	{{ {102, 12, 24}, 0, {368, 240}, {97, 198, 58, 255} }},
	{{ {105, 18, 5}, 0, {496, 240}, {113, 224, 207, 255} }},
	{{ {103, 39, 7}, 0, {496, 368}, {84, 89, 220, 255} }},
	{{ {99, 34, 30}, 0, {368, 368}, {66, 42, 100, 255} }},
	{{ {100, 43, 7}, 0, {496, 368}, {114, 219, 214, 255} }},
	{{ {92, 62, 9}, 0, {496, 496}, {87, 86, 224, 255} }},
	{{ {78, 69, -2}, 0, {496, 496}, {39, 104, 194, 255} }},
	{{ {91, 60, 33}, 0, {368, 496}, {57, 77, 83, 255} }},
	{{ {92, 62, 9}, 0, {496, 496}, {87, 86, 224, 255} }},
	{{ {74, 62, 29}, 0, {368, 496}, {11, 96, 83, 255} }},
	{{ {43, 67, 23}, 0, {496, 624}, {216, 116, 33, 255} }},
	{{ {59, 63, -9}, 0, {624, 496}, {252, 92, 169, 255} }},
	{{ {33, 49, -17}, 0, {624, 624}, {228, 83, 164, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {155, 77, 4, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {180, 52, 169, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {175, 46, 87, 255} }},
	{{ {64, 44, 50}, 0, {368, 624}, {25, 44, 117, 255} }},
	{{ {79, 33, 37}, 0, {368, 368}, {63, 253, 110, 255} }},
	{{ {64, 44, 50}, 0, {240, 496}, {25, 44, 117, 255} }},
	{{ {98, 41, 31}, 0, {368, 368}, {87, 224, 87, 255} }},
	{{ {100, 43, 7}, 0, {496, 368}, {114, 219, 214, 255} }},
	{{ {102, 12, 24}, 0, {368, 240}, {97, 198, 58, 255} }},
	{{ {99, 34, 30}, 0, {368, 368}, {66, 42, 100, 255} }},
	{{ {103, 39, 7}, 0, {496, 368}, {84, 89, 220, 255} }},
	{{ {105, 18, 5}, 0, {496, 240}, {113, 224, 207, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 5, 4, 2, 0),
	gsSP2Triangles(5, 6, 4, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 5, 8, 0, 5, 9, 8, 0),
	gsSP2Triangles(5, 10, 9, 0, 11, 10, 5, 0),
	gsSP2Triangles(11, 12, 10, 0, 13, 6, 7, 0),
	gsSP2Triangles(13, 14, 6, 0, 13, 15, 14, 0),
	gsSP2Triangles(13, 16, 15, 0, 16, 13, 17, 0),
	gsSP2Triangles(13, 18, 17, 0, 13, 7, 18, 0),
	gsSP2Triangles(17, 18, 19, 0, 17, 19, 20, 0),
	gsSP2Triangles(21, 17, 20, 0, 21, 20, 22, 0),
	gsSP2Triangles(16, 17, 21, 0, 0, 23, 24, 0),
	gsSP2Triangles(0, 3, 23, 0, 25, 23, 3, 0),
	gsSP2Triangles(3, 4, 25, 0, 25, 4, 26, 0),
	gsSP2Triangles(4, 27, 26, 0, 4, 6, 27, 0),
	gsSP2Triangles(6, 28, 27, 0, 6, 14, 28, 0),
	gsSP2Triangles(14, 29, 28, 0, 14, 25, 29, 0),
	gsSP2Triangles(25, 14, 30, 0, 14, 31, 30, 0),
	gsSP1Triangle(14, 15, 31, 0),
	gsSPVertex(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_vtx_1 + 32, 19, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(3, 0, 4, 0, 4, 0, 5, 0),
	gsSP2Triangles(4, 5, 6, 0, 7, 4, 6, 0),
	gsSP2Triangles(7, 6, 8, 0, 9, 4, 7, 0),
	gsSP2Triangles(9, 10, 4, 0, 3, 4, 10, 0),
	gsSP2Triangles(11, 3, 12, 0, 11, 1, 3, 0),
	gsSP2Triangles(11, 13, 1, 0, 11, 14, 13, 0),
	gsSP2Triangles(14, 1, 13, 0, 14, 2, 1, 0),
	gsSP2Triangles(11, 15, 16, 0, 15, 17, 16, 0),
	gsSP1Triangle(15, 18, 17, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_vtx_2[24] = {
	{{ {31, -22, 8}, 0, {496, -16}, {249, 129, 254, 255} }},
	{{ {39, -13, 36}, 0, {368, -16}, {244, 158, 80, 255} }},
	{{ {26, -13, 33}, 0, {368, -16}, {241, 162, 84, 255} }},
	{{ {45, -24, 9}, 0, {496, -16}, {248, 129, 1, 255} }},
	{{ {15, 8, 44}, 0, {368, 880}, {213, 235, 118, 255} }},
	{{ {26, -13, 33}, 0, {368, 1008}, {241, 162, 84, 255} }},
	{{ {39, -13, 36}, 0, {368, 1008}, {244, 158, 80, 255} }},
	{{ {26, 14, 47}, 0, {368, 880}, {220, 239, 120, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {175, 46, 87, 255} }},
	{{ {12, 41, 36}, 0, {368, 752}, {169, 49, 79, 255} }},
	{{ {7, 52, 9}, 0, {496, 752}, {149, 69, 1, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {155, 77, 4, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {180, 52, 169, 255} }},
	{{ {12, 41, -18}, 0, {624, 752}, {174, 55, 176, 255} }},
	{{ {15, 8, -27}, 0, {880, 368}, {222, 239, 135, 255} }},
	{{ {39, -13, -18}, 0, {880, 240}, {252, 158, 175, 255} }},
	{{ {26, -13, -17}, 0, {880, 240}, {247, 165, 168, 255} }},
	{{ {26, 14, -30}, 0, {880, 368}, {231, 245, 132, 255} }},
	{{ {4, 30, -17}, 0, {880, 496}, {180, 52, 169, 255} }},
	{{ {12, 41, -18}, 0, {880, 496}, {174, 55, 176, 255} }},
	{{ {31, -22, 8}, 0, {496, 1008}, {249, 129, 254, 255} }},
	{{ {26, -13, -17}, 0, {624, 1008}, {247, 165, 168, 255} }},
	{{ {39, -13, -18}, 0, {624, 1008}, {252, 158, 175, 255} }},
	{{ {45, -24, 9}, 0, {496, 1008}, {248, 129, 1, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_vtx_2 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 4, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 10, 13, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 17, 15, 0),
	gsSP2Triangles(18, 17, 14, 0, 18, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_5_vtx_0[12] = {
	{{ {65, 21, 45}, 0, {-16, 490}, {47, 228, 115, 255} }},
	{{ {65, -7, 36}, 0, {401, 807}, {45, 183, 94, 255} }},
	{{ {85, 0, 27}, 0, {456, 529}, {68, 228, 104, 255} }},
	{{ {65, 21, 45}, 0, {-16, 490}, {47, 228, 115, 255} }},
	{{ {79, 33, 37}, 0, {97, 358}, {73, 234, 102, 255} }},
	{{ {79, 33, 37}, 0, {130, 411}, {26, 250, 124, 255} }},
	{{ {85, 0, 27}, 0, {438, 411}, {71, 180, 73, 255} }},
	{{ {102, 12, 25}, 0, {438, 37}, {38, 226, 117, 255} }},
	{{ {99, 34, 30}, 0, {130, 37}, {66, 42, 100, 255} }},
	{{ {91, 60, 33}, 0, {438, 37}, {253, 22, 125, 255} }},
	{{ {74, 62, 29}, 0, {438, 411}, {11, 96, 83, 255} }},
	{{ {98, 41, 31}, 0, {130, 37}, {87, 224, 87, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_5_vtx_0 + 0, 12, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 2, 4, 0),
	gsSP2Triangles(5, 6, 7, 0, 5, 7, 8, 0),
	gsSP2Triangles(5, 9, 10, 0, 5, 11, 9, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_0[9] = {
	{{ {26, -13, 33}, 0, {368, 1008}, {206, 158, 63, 255} }},
	{{ {15, 8, 44}, 0, {368, 880}, {178, 215, 91, 255} }},
	{{ {-19, -7, 8}, 0, {496, 880}, {142, 200, 0, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {149, 19, 66, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {137, 45, 0, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {149, 19, 190, 255} }},
	{{ {15, 8, -27}, 0, {624, 880}, {178, 215, 165, 255} }},
	{{ {26, -13, -17}, 0, {624, 1008}, {206, 158, 193, 255} }},
	{{ {31, -22, 8}, 0, {496, 1008}, {218, 135, 0, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(2, 3, 4, 0, 2, 4, 5, 0),
	gsSP2Triangles(2, 5, 6, 0, 7, 2, 6, 0),
	gsSP2Triangles(7, 8, 2, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_1[37] = {
	{{ {56, -7, 38}, 0, {368, 112}, {33, 185, 100, 255} }},
	{{ {26, -13, 33}, 0, {368, -16}, {12, 173, 95, 255} }},
	{{ {31, -22, 8}, 0, {496, -16}, {20, 131, 254, 255} }},
	{{ {64, -18, 8}, 0, {496, 112}, {48, 139, 249, 255} }},
	{{ {26, -13, -17}, 0, {624, -16}, {19, 175, 160, 255} }},
	{{ {56, -7, -17}, 0, {624, 112}, {37, 179, 162, 255} }},
	{{ {82, 8, -13}, 0, {624, 240}, {86, 214, 172, 255} }},
	{{ {90, 5, 8}, 0, {496, 240}, {117, 208, 247, 255} }},
	{{ {91, 37, 8}, 0, {496, 368}, {118, 46, 0, 255} }},
	{{ {78, 33, -17}, 0, {624, 368}, {74, 30, 157, 255} }},
	{{ {56, -7, -17}, 0, {752, 240}, {37, 179, 162, 255} }},
	{{ {45, 21, -27}, 0, {752, 368}, {12, 6, 130, 255} }},
	{{ {26, -13, -17}, 0, {880, 240}, {19, 175, 160, 255} }},
	{{ {15, 8, -27}, 0, {880, 368}, {253, 1, 129, 255} }},
	{{ {33, 49, -17}, 0, {752, 496}, {232, 85, 165, 255} }},
	{{ {4, 30, -17}, 0, {880, 496}, {210, 73, 162, 255} }},
	{{ {63, 54, -13}, 0, {624, 496}, {34, 91, 174, 255} }},
	{{ {67, 61, 8}, 0, {496, 496}, {47, 118, 0, 255} }},
	{{ {29, 60, 8}, 0, {496, 624}, {214, 120, 0, 255} }},
	{{ {33, 49, -17}, 0, {624, 624}, {232, 85, 165, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {184, 105, 0, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {210, 73, 162, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {210, 72, 94, 255} }},
	{{ {33, 49, 33}, 0, {368, 624}, {231, 85, 91, 255} }},
	{{ {63, 54, 29}, 0, {368, 496}, {35, 91, 82, 255} }},
	{{ {78, 33, 33}, 0, {368, 368}, {75, 30, 98, 255} }},
	{{ {45, 21, 43}, 0, {240, 368}, {29, 17, 122, 255} }},
	{{ {33, 49, 33}, 0, {240, 496}, {231, 85, 91, 255} }},
	{{ {83, 0, 27}, 0, {368, 240}, {89, 199, 71, 255} }},
	{{ {56, -7, 38}, 0, {240, 240}, {33, 185, 100, 255} }},
	{{ {15, 8, 44}, 0, {112, 368}, {248, 3, 127, 255} }},
	{{ {26, -13, 33}, 0, {112, 240}, {12, 173, 95, 255} }},
	{{ {15, 8, 44}, 0, {112, 368}, {248, 3, 127, 255} }},
	{{ {56, -7, 38}, 0, {240, 240}, {33, 185, 100, 255} }},
	{{ {45, 21, 43}, 0, {240, 368}, {248, 2, 127, 255} }},
	{{ {4, 30, 33}, 0, {112, 496}, {210, 72, 94, 255} }},
	{{ {33, 49, 33}, 0, {240, 496}, {231, 85, 91, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 3, 5, 0, 6, 7, 3, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 6, 9, 0),
	gsSP2Triangles(9, 6, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSP2Triangles(14, 11, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 11, 14, 0, 16, 9, 11, 0),
	gsSP2Triangles(16, 8, 9, 0, 16, 17, 8, 0),
	gsSP2Triangles(18, 17, 16, 0, 18, 16, 19, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 19, 21, 0),
	gsSP2Triangles(22, 18, 20, 0, 22, 23, 18, 0),
	gsSP2Triangles(23, 17, 18, 0, 23, 24, 17, 0),
	gsSP2Triangles(24, 8, 17, 0, 24, 25, 8, 0),
	gsSP2Triangles(24, 26, 25, 0, 24, 27, 26, 0),
	gsSP2Triangles(26, 28, 25, 0, 26, 29, 28, 0),
	gsSP2Triangles(3, 28, 29, 0, 3, 7, 28, 0),
	gsSP2Triangles(8, 28, 7, 0, 8, 25, 28, 0),
	gsSP1Triangle(30, 31, 29, 0),
	gsSPVertex(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_1 + 32, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP1Triangle(3, 2, 4, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_2[24] = {
	{{ {31, -22, 8}, 0, {496, -16}, {248, 129, 254, 255} }},
	{{ {39, -13, 36}, 0, {368, -16}, {244, 158, 80, 255} }},
	{{ {26, -13, 33}, 0, {368, -16}, {244, 164, 87, 255} }},
	{{ {45, -24, 9}, 0, {496, -16}, {248, 129, 1, 255} }},
	{{ {15, 8, 44}, 0, {368, 880}, {220, 237, 120, 255} }},
	{{ {26, -13, 33}, 0, {368, 1008}, {244, 164, 87, 255} }},
	{{ {39, -13, 36}, 0, {368, 1008}, {244, 158, 80, 255} }},
	{{ {26, 14, 47}, 0, {368, 880}, {220, 239, 120, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {175, 44, 87, 255} }},
	{{ {12, 41, 36}, 0, {368, 752}, {169, 49, 79, 255} }},
	{{ {7, 52, 9}, 0, {496, 752}, {149, 69, 1, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {149, 69, 254, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {182, 49, 165, 255} }},
	{{ {12, 41, -18}, 0, {624, 752}, {174, 55, 176, 255} }},
	{{ {15, 8, -27}, 0, {880, 368}, {232, 243, 132, 255} }},
	{{ {39, -13, -18}, 0, {880, 240}, {252, 158, 175, 255} }},
	{{ {26, -13, -17}, 0, {880, 240}, {253, 168, 165, 255} }},
	{{ {26, 14, -30}, 0, {880, 368}, {231, 245, 132, 255} }},
	{{ {4, 30, -17}, 0, {880, 496}, {182, 49, 165, 255} }},
	{{ {12, 41, -18}, 0, {880, 496}, {174, 55, 176, 255} }},
	{{ {31, -22, 8}, 0, {496, 1008}, {248, 129, 254, 255} }},
	{{ {26, -13, -17}, 0, {624, 1008}, {253, 168, 165, 255} }},
	{{ {39, -13, -18}, 0, {624, 1008}, {252, 158, 175, 255} }},
	{{ {45, -24, 9}, 0, {496, 1008}, {248, 129, 1, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_2 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 4, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 10, 13, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 17, 15, 0),
	gsSP2Triangles(18, 17, 14, 0, 18, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_3[28] = {
	{{ {92, 143, 210}, 0, {381, 266}, {251, 120, 42, 255} }},
	{{ {102, 148, 107}, 0, {432, 112}, {240, 126, 4, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {240, 126, 4, 255} }},
	{{ {125, 147, 203}, 0, {432, 266}, {251, 120, 42, 255} }},
	{{ {106, 98, 271}, 0, {381, 368}, {12, 53, 115, 255} }},
	{{ {140, 99, 265}, 0, {432, 368}, {12, 51, 116, 255} }},
	{{ {104, 2, 261}, 0, {381, 522}, {4, 199, 113, 255} }},
	{{ {139, -3, 258}, 0, {432, 522}, {3, 195, 111, 255} }},
	{{ {89, -52, 194}, 0, {381, 624}, {241, 141, 52, 255} }},
	{{ {123, -59, 190}, 0, {432, 624}, {241, 141, 52, 255} }},
	{{ {105, -69, 103}, 0, {432, 522}, {228, 135, 227, 255} }},
	{{ {71, -63, 109}, 0, {381, 522}, {228, 137, 223, 255} }},
	{{ {88, -3, 27}, 0, {432, 368}, {218, 210, 144, 255} }},
	{{ {54, -1, 37}, 0, {381, 368}, {218, 212, 143, 255} }},
	{{ {89, 77, 38}, 0, {432, 266}, {218, 56, 149, 255} }},
	{{ {56, 74, 49}, 0, {381, 266}, {218, 56, 148, 255} }},
	{{ {102, 148, 107}, 0, {432, 112}, {221, 89, 172, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {221, 89, 172, 255} }},
	{{ {92, 143, 210}, 0, {381, 266}, {85, 94, 12, 255} }},
	{{ {221, 36, 128}, 0, {-16, 1008}, {124, 252, 230, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {73, 102, 238, 255} }},
	{{ {106, 98, 271}, 0, {381, 368}, {102, 41, 64, 255} }},
	{{ {104, 2, 261}, 0, {381, 522}, {95, 210, 71, 255} }},
	{{ {89, -52, 194}, 0, {381, 624}, {78, 159, 24, 255} }},
	{{ {71, -63, 109}, 0, {381, 522}, {69, 160, 210, 255} }},
	{{ {54, -1, 37}, 0, {381, 368}, {64, 225, 151, 255} }},
	{{ {56, 74, 49}, 0, {381, 266}, {59, 45, 153, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {58, 73, 170, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_vtx_3 + 0, 28, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 7, 5, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 8, 11, 10, 0),
	gsSP2Triangles(11, 12, 10, 0, 11, 13, 12, 0),
	gsSP2Triangles(13, 14, 12, 0, 13, 15, 14, 0),
	gsSP2Triangles(15, 16, 14, 0, 15, 17, 16, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 19, 18, 0),
	gsSP2Triangles(22, 19, 21, 0, 23, 19, 22, 0),
	gsSP2Triangles(23, 24, 19, 0, 24, 25, 19, 0),
	gsSP2Triangles(25, 26, 19, 0, 26, 27, 19, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_5_vtx_0[7] = {
	{{ {63, 54, 29}, 0, {416, 115}, {38, 55, 108, 255} }},
	{{ {33, 49, 33}, 0, {623, 748}, {9, 44, 119, 255} }},
	{{ {45, 21, 43}, 0, {-16, 748}, {28, 17, 123, 255} }},
	{{ {78, 33, 34}, 0, {-16, 122}, {75, 30, 98, 255} }},
	{{ {83, 0, 28}, 0, {416, 115}, {68, 250, 107, 255} }},
	{{ {56, -7, 38}, 0, {623, 748}, {46, 253, 118, 255} }},
	{{ {91, 37, 8}, 0, {-16, -244}, {106, 38, 58, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_5_vtx_0 + 0, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(2, 4, 3, 0, 2, 5, 4, 0),
	gsSP2Triangles(6, 3, 4, 0, 0, 3, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_0[9] = {
	{{ {26, -13, 33}, 0, {368, 1008}, {206, 158, 63, 255} }},
	{{ {15, 8, 44}, 0, {368, 880}, {178, 215, 91, 255} }},
	{{ {-19, -7, 8}, 0, {496, 880}, {142, 200, 0, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {149, 19, 66, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {137, 45, 0, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {149, 19, 190, 255} }},
	{{ {15, 8, -27}, 0, {624, 880}, {178, 215, 165, 255} }},
	{{ {26, -13, -17}, 0, {624, 1008}, {206, 158, 193, 255} }},
	{{ {31, -22, 8}, 0, {496, 1008}, {218, 135, 0, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 2, 1, 3, 0),
	gsSP2Triangles(2, 3, 4, 0, 2, 4, 5, 0),
	gsSP2Triangles(2, 5, 6, 0, 7, 2, 6, 0),
	gsSP2Triangles(7, 8, 2, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_1[37] = {
	{{ {56, -7, 38}, 0, {368, 112}, {33, 185, 100, 255} }},
	{{ {26, -13, 33}, 0, {368, -16}, {12, 173, 95, 255} }},
	{{ {31, -22, 8}, 0, {496, -16}, {20, 131, 254, 255} }},
	{{ {64, -18, 8}, 0, {496, 112}, {48, 139, 249, 255} }},
	{{ {26, -13, -17}, 0, {624, -16}, {19, 175, 160, 255} }},
	{{ {56, -7, -17}, 0, {624, 112}, {37, 179, 162, 255} }},
	{{ {82, 8, -13}, 0, {624, 240}, {86, 214, 172, 255} }},
	{{ {90, 5, 8}, 0, {496, 240}, {117, 208, 247, 255} }},
	{{ {91, 37, 8}, 0, {496, 368}, {118, 46, 0, 255} }},
	{{ {78, 33, -17}, 0, {624, 368}, {74, 30, 157, 255} }},
	{{ {56, -7, -17}, 0, {752, 240}, {37, 179, 162, 255} }},
	{{ {45, 21, -27}, 0, {752, 368}, {12, 6, 130, 255} }},
	{{ {26, -13, -17}, 0, {880, 240}, {19, 175, 160, 255} }},
	{{ {15, 8, -27}, 0, {880, 368}, {253, 1, 129, 255} }},
	{{ {33, 49, -17}, 0, {752, 496}, {232, 85, 165, 255} }},
	{{ {4, 30, -17}, 0, {880, 496}, {210, 73, 162, 255} }},
	{{ {63, 54, -13}, 0, {624, 496}, {34, 91, 174, 255} }},
	{{ {67, 61, 8}, 0, {496, 496}, {47, 118, 0, 255} }},
	{{ {29, 60, 8}, 0, {496, 624}, {214, 120, 0, 255} }},
	{{ {33, 49, -17}, 0, {624, 624}, {232, 85, 165, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {184, 105, 0, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {210, 73, 162, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {210, 72, 94, 255} }},
	{{ {33, 49, 33}, 0, {368, 624}, {231, 85, 91, 255} }},
	{{ {63, 54, 29}, 0, {368, 496}, {35, 91, 82, 255} }},
	{{ {78, 33, 33}, 0, {368, 368}, {75, 30, 98, 255} }},
	{{ {45, 21, 43}, 0, {240, 368}, {29, 17, 122, 255} }},
	{{ {33, 49, 33}, 0, {240, 496}, {231, 85, 91, 255} }},
	{{ {83, 0, 27}, 0, {368, 240}, {89, 199, 71, 255} }},
	{{ {56, -7, 38}, 0, {240, 240}, {33, 185, 100, 255} }},
	{{ {15, 8, 44}, 0, {112, 368}, {248, 3, 127, 255} }},
	{{ {26, -13, 33}, 0, {112, 240}, {12, 173, 95, 255} }},
	{{ {15, 8, 44}, 0, {112, 368}, {248, 3, 127, 255} }},
	{{ {56, -7, 38}, 0, {240, 240}, {33, 185, 100, 255} }},
	{{ {45, 21, 43}, 0, {240, 368}, {248, 2, 127, 255} }},
	{{ {4, 30, 33}, 0, {112, 496}, {210, 72, 94, 255} }},
	{{ {33, 49, 33}, 0, {240, 496}, {231, 85, 91, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_1 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 3, 5, 0, 6, 7, 3, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 6, 9, 0),
	gsSP2Triangles(9, 6, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSP2Triangles(14, 11, 13, 0, 14, 13, 15, 0),
	gsSP2Triangles(16, 11, 14, 0, 16, 9, 11, 0),
	gsSP2Triangles(16, 8, 9, 0, 16, 17, 8, 0),
	gsSP2Triangles(18, 17, 16, 0, 18, 16, 19, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 19, 21, 0),
	gsSP2Triangles(22, 18, 20, 0, 22, 23, 18, 0),
	gsSP2Triangles(23, 17, 18, 0, 23, 24, 17, 0),
	gsSP2Triangles(24, 8, 17, 0, 24, 25, 8, 0),
	gsSP2Triangles(24, 26, 25, 0, 24, 27, 26, 0),
	gsSP2Triangles(26, 28, 25, 0, 26, 29, 28, 0),
	gsSP2Triangles(3, 28, 29, 0, 3, 7, 28, 0),
	gsSP2Triangles(8, 28, 7, 0, 8, 25, 28, 0),
	gsSP1Triangle(30, 31, 29, 0),
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_1 + 32, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP1Triangle(3, 2, 4, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_2[24] = {
	{{ {31, -22, 8}, 0, {496, -16}, {248, 129, 254, 255} }},
	{{ {39, -13, 36}, 0, {368, -16}, {244, 158, 80, 255} }},
	{{ {26, -13, 33}, 0, {368, -16}, {244, 164, 87, 255} }},
	{{ {45, -24, 9}, 0, {496, -16}, {248, 129, 1, 255} }},
	{{ {15, 8, 44}, 0, {368, 880}, {220, 237, 120, 255} }},
	{{ {26, -13, 33}, 0, {368, 1008}, {244, 164, 87, 255} }},
	{{ {39, -13, 36}, 0, {368, 1008}, {244, 158, 80, 255} }},
	{{ {26, 14, 47}, 0, {368, 880}, {220, 239, 120, 255} }},
	{{ {4, 30, 33}, 0, {368, 752}, {175, 44, 87, 255} }},
	{{ {12, 41, 36}, 0, {368, 752}, {169, 49, 79, 255} }},
	{{ {7, 52, 9}, 0, {496, 752}, {149, 69, 1, 255} }},
	{{ {-1, 39, 8}, 0, {496, 752}, {149, 69, 254, 255} }},
	{{ {4, 30, -17}, 0, {624, 752}, {182, 49, 165, 255} }},
	{{ {12, 41, -18}, 0, {624, 752}, {174, 55, 176, 255} }},
	{{ {15, 8, -27}, 0, {880, 368}, {232, 243, 132, 255} }},
	{{ {39, -13, -18}, 0, {880, 240}, {252, 158, 175, 255} }},
	{{ {26, -13, -17}, 0, {880, 240}, {253, 168, 165, 255} }},
	{{ {26, 14, -30}, 0, {880, 368}, {231, 245, 132, 255} }},
	{{ {4, 30, -17}, 0, {880, 496}, {182, 49, 165, 255} }},
	{{ {12, 41, -18}, 0, {880, 496}, {174, 55, 176, 255} }},
	{{ {31, -22, 8}, 0, {496, 1008}, {248, 129, 254, 255} }},
	{{ {26, -13, -17}, 0, {624, 1008}, {253, 168, 165, 255} }},
	{{ {39, -13, -18}, 0, {624, 1008}, {252, 158, 175, 255} }},
	{{ {45, -24, 9}, 0, {496, 1008}, {248, 129, 1, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_2 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(8, 4, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 10, 13, 0),
	gsSP2Triangles(14, 15, 16, 0, 14, 17, 15, 0),
	gsSP2Triangles(18, 17, 14, 0, 18, 19, 17, 0),
	gsSP2Triangles(20, 21, 22, 0, 20, 22, 23, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_3[28] = {
	{{ {92, 143, 210}, 0, {381, 266}, {251, 120, 42, 255} }},
	{{ {102, 148, 107}, 0, {432, 112}, {240, 126, 4, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {240, 126, 4, 255} }},
	{{ {125, 147, 203}, 0, {432, 266}, {251, 120, 42, 255} }},
	{{ {106, 98, 271}, 0, {381, 368}, {12, 53, 115, 255} }},
	{{ {140, 99, 265}, 0, {432, 368}, {12, 51, 116, 255} }},
	{{ {104, 2, 261}, 0, {381, 522}, {4, 199, 113, 255} }},
	{{ {139, -3, 258}, 0, {432, 522}, {3, 195, 111, 255} }},
	{{ {89, -52, 194}, 0, {381, 624}, {241, 141, 52, 255} }},
	{{ {123, -59, 190}, 0, {432, 624}, {241, 141, 52, 255} }},
	{{ {105, -69, 103}, 0, {432, 522}, {228, 135, 227, 255} }},
	{{ {71, -63, 109}, 0, {381, 522}, {228, 137, 223, 255} }},
	{{ {88, -3, 27}, 0, {432, 368}, {218, 210, 144, 255} }},
	{{ {54, -1, 37}, 0, {381, 368}, {218, 212, 143, 255} }},
	{{ {89, 77, 38}, 0, {432, 266}, {218, 56, 149, 255} }},
	{{ {56, 74, 49}, 0, {381, 266}, {218, 56, 148, 255} }},
	{{ {102, 148, 107}, 0, {432, 112}, {221, 89, 172, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {221, 89, 172, 255} }},
	{{ {92, 143, 210}, 0, {381, 266}, {85, 94, 12, 255} }},
	{{ {221, 36, 128}, 0, {-16, 1008}, {124, 252, 230, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {73, 102, 238, 255} }},
	{{ {106, 98, 271}, 0, {381, 368}, {102, 41, 64, 255} }},
	{{ {104, 2, 261}, 0, {381, 522}, {95, 210, 71, 255} }},
	{{ {89, -52, 194}, 0, {381, 624}, {78, 159, 24, 255} }},
	{{ {71, -63, 109}, 0, {381, 522}, {69, 160, 210, 255} }},
	{{ {54, -1, 37}, 0, {381, 368}, {64, 225, 151, 255} }},
	{{ {56, 74, 49}, 0, {381, 266}, {59, 45, 153, 255} }},
	{{ {69, 143, 116}, 0, {381, 112}, {58, 73, 170, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_3[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_vtx_3 + 0, 28, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 5, 3, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 7, 5, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 9, 7, 0),
	gsSP2Triangles(8, 10, 9, 0, 8, 11, 10, 0),
	gsSP2Triangles(11, 12, 10, 0, 11, 13, 12, 0),
	gsSP2Triangles(13, 14, 12, 0, 13, 15, 14, 0),
	gsSP2Triangles(15, 16, 14, 0, 15, 17, 16, 0),
	gsSP2Triangles(18, 19, 20, 0, 21, 19, 18, 0),
	gsSP2Triangles(22, 19, 21, 0, 23, 19, 22, 0),
	gsSP2Triangles(23, 24, 19, 0, 24, 25, 19, 0),
	gsSP2Triangles(25, 26, 19, 0, 26, 27, 19, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_5_vtx_0[7] = {
	{{ {63, 54, 29}, 0, {416, 115}, {38, 55, 108, 255} }},
	{{ {33, 49, 33}, 0, {623, 748}, {9, 44, 119, 255} }},
	{{ {45, 21, 43}, 0, {-16, 748}, {28, 17, 123, 255} }},
	{{ {78, 33, 34}, 0, {-16, 122}, {75, 30, 98, 255} }},
	{{ {83, 0, 28}, 0, {416, 115}, {68, 250, 107, 255} }},
	{{ {56, -7, 38}, 0, {623, 748}, {46, 253, 118, 255} }},
	{{ {91, 37, 8}, 0, {-16, -244}, {106, 38, 58, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_5_vtx_0 + 0, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(2, 4, 3, 0, 2, 5, 4, 0),
	gsSP2Triangles(6, 3, 4, 0, 0, 3, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_vtx_0[8] = {
	{{ {119, -50, 246}, 0, {-16, 2032}, {201, 150, 213, 255} }},
	{{ {311, -139, 219}, 0, {-16, -16}, {201, 150, 213, 255} }},
	{{ {307, -177, 319}, 0, {974, -16}, {201, 150, 213, 255} }},
	{{ {115, -88, 344}, 0, {974, 2032}, {201, 150, 213, 255} }},
	{{ {341, 290, 156}, 0, {974, -16}, {214, 62, 154, 255} }},
	{{ {335, 199, 103}, 0, {-16, -16}, {214, 63, 154, 255} }},
	{{ {135, 172, 170}, 0, {-16, 2032}, {214, 63, 154, 255} }},
	{{ {141, 264, 223}, 0, {974, 2032}, {214, 62, 154, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_vtx_0 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 0, 2, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_vtx_1[8] = {
	{{ {335, 199, 103}, 0, {974, -16}, {214, 63, 154, 255} }},
	{{ {129, 81, 116}, 0, {-16, 2032}, {214, 63, 154, 255} }},
	{{ {135, 172, 170}, 0, {974, 2032}, {214, 63, 154, 255} }},
	{{ {329, 108, 49}, 0, {-16, -16}, {214, 63, 154, 255} }},
	{{ {119, -50, 246}, 0, {974, 2032}, {201, 150, 213, 255} }},
	{{ {124, -12, 146}, 0, {-16, 2032}, {201, 150, 213, 255} }},
	{{ {311, -139, 219}, 0, {974, -16}, {201, 150, 213, 255} }},
	{{ {315, -100, 121}, 0, {-16, -16}, {201, 150, 212, 255} }},
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_vtx_1 + 0, 8, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 5, 6, 0, 5, 7, 6, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Thigh_Color_mesh_layer_1_vtx_0[48] = {
	{{ {111, -15, 24}, 0, {368, 112}, {99, 177, 246, 255} }},
	{{ {57, -36, 4}, 0, {496, -16}, {1, 152, 182, 255} }},
	{{ {99, -10, -7}, 0, {368, -16}, {68, 189, 172, 255} }},
	{{ {71, -43, 41}, 0, {496, 112}, {40, 136, 15, 255} }},
	{{ {76, -21, 75}, 0, {496, 240}, {48, 190, 97, 255} }},
	{{ {116, 3, 53}, 0, {368, 240}, {107, 220, 58, 255} }},
	{{ {111, 33, 62}, 0, {368, 368}, {89, 39, 81, 255} }},
	{{ {122, 30, 12}, 0, {240, 368}, {116, 33, 217, 255} }},
	{{ {111, -15, 24}, 0, {240, 240}, {99, 177, 246, 255} }},
	{{ {99, -10, -7}, 0, {112, 240}, {68, 189, 172, 255} }},
	{{ {87, 14, -23}, 0, {112, 368}, {33, 251, 134, 255} }},
	{{ {82, 44, -14}, 0, {112, 496}, {22, 72, 154, 255} }},
	{{ {87, 62, 14}, 0, {240, 496}, {35, 117, 221, 255} }},
	{{ {99, 57, 46}, 0, {368, 496}, {62, 103, 41, 255} }},
	{{ {68, 21, 83}, 0, {496, 368}, {26, 24, 122, 255} }},
	{{ {52, 57, 65}, 0, {496, 496}, {247, 102, 76, 255} }},
	{{ {87, 62, 14}, 0, {368, 624}, {35, 117, 221, 255} }},
	{{ {37, 64, 28}, 0, {496, 624}, {215, 119, 241, 255} }},
	{{ {82, 44, -14}, 0, {368, 752}, {22, 72, 154, 255} }},
	{{ {32, 42, -6}, 0, {496, 752}, {201, 65, 162, 255} }},
	{{ {87, 14, -23}, 0, {368, 880}, {33, 251, 134, 255} }},
	{{ {42, 0, -14}, 0, {496, 880}, {216, 228, 139, 255} }},
	{{ {99, -10, -7}, 0, {368, 1008}, {68, 189, 172, 255} }},
	{{ {57, -36, 4}, 0, {496, 1008}, {1, 152, 182, 255} }},
	{{ {4, -9, 12}, 0, {624, 880}, {163, 216, 180, 255} }},
	{{ {16, -36, 27}, 0, {624, 1008}, {190, 155, 215, 255} }},
	{{ {-2, 21, 19}, 0, {624, 752}, {147, 31, 199, 255} }},
	{{ {1, 38, 43}, 0, {624, 624}, {155, 76, 11, 255} }},
	{{ {12, 32, 70}, 0, {624, 496}, {186, 62, 86, 255} }},
	{{ {24, 6, 84}, 0, {624, 368}, {217, 3, 121, 255} }},
	{{ {-8, -8, 56}, 0, {752, 368}, {140, 223, 39, 255} }},
	{{ {1, 38, 43}, 0, {752, 496}, {155, 76, 11, 255} }},
	{{ {-2, 21, 19}, 0, {880, 496}, {147, 31, 199, 255} }},
	{{ {-8, -8, 56}, 0, {752, 368}, {140, 223, 39, 255} }},
	{{ {1, 38, 43}, 0, {752, 496}, {155, 76, 11, 255} }},
	{{ {4, -9, 12}, 0, {880, 368}, {163, 216, 180, 255} }},
	{{ {16, -36, 27}, 0, {880, 240}, {190, 155, 215, 255} }},
	{{ {26, -42, 54}, 0, {752, 240}, {219, 140, 35, 255} }},
	{{ {30, -24, 77}, 0, {624, 240}, {230, 186, 103, 255} }},
	{{ {24, 6, 84}, 0, {624, 368}, {217, 3, 121, 255} }},
	{{ {68, 21, 83}, 0, {496, 368}, {26, 24, 122, 255} }},
	{{ {76, -21, 75}, 0, {496, 240}, {48, 190, 97, 255} }},
	{{ {26, -42, 54}, 0, {624, 112}, {219, 140, 35, 255} }},
	{{ {71, -43, 41}, 0, {496, 112}, {40, 136, 15, 255} }},
	{{ {16, -36, 27}, 0, {624, -16}, {190, 155, 215, 255} }},
	{{ {57, -36, 4}, 0, {496, -16}, {1, 152, 182, 255} }},
	{{ {111, 33, 62}, 0, {368, 368}, {89, 39, 81, 255} }},
	{{ {52, 57, 65}, 0, {496, 496}, {247, 102, 76, 255} }},
};

Gfx landie_alt_collar_Left_Thigh_Color_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Thigh_Color_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 0, 5, 0),
	gsSP2Triangles(6, 4, 5, 0, 7, 6, 5, 0),
	gsSP2Triangles(7, 5, 8, 0, 7, 8, 9, 0),
	gsSP2Triangles(7, 9, 10, 0, 11, 7, 10, 0),
	gsSP2Triangles(11, 12, 7, 0, 13, 7, 12, 0),
	gsSP2Triangles(13, 6, 7, 0, 13, 14, 6, 0),
	gsSP2Triangles(13, 15, 14, 0, 16, 15, 13, 0),
	gsSP2Triangles(16, 17, 15, 0, 18, 17, 16, 0),
	gsSP2Triangles(18, 19, 17, 0, 20, 19, 18, 0),
	gsSP2Triangles(20, 21, 19, 0, 22, 21, 20, 0),
	gsSP2Triangles(22, 23, 21, 0, 23, 24, 21, 0),
	gsSP2Triangles(23, 25, 24, 0, 21, 24, 26, 0),
	gsSP2Triangles(21, 26, 19, 0, 19, 26, 27, 0),
	gsSP2Triangles(19, 27, 17, 0, 17, 27, 28, 0),
	gsSP2Triangles(17, 28, 15, 0, 15, 28, 29, 0),
	gsSP2Triangles(28, 30, 29, 0, 28, 31, 30, 0),
	gsSPVertex(landie_alt_collar_Left_Thigh_Color_mesh_layer_1_vtx_0 + 32, 16, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(1, 3, 4, 0, 1, 4, 5, 0),
	gsSP2Triangles(1, 5, 6, 0, 1, 6, 7, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 6, 9, 0),
	gsSP2Triangles(9, 6, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSP2Triangles(14, 8, 9, 0, 15, 7, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Thigh_Color_mesh_layer_5_vtx_0[5] = {
	{{ {76, -21, 75}, 0, {48, -16}, {80, 168, 45, 255} }},
	{{ {111, -15, 24}, 0, {579, 887}, {77, 157, 20, 255} }},
	{{ {116, 3, 53}, 0, {48, 887}, {78, 166, 44, 255} }},
	{{ {71, -43, 41}, 0, {579, -16}, {74, 153, 2, 255} }},
	{{ {57, -36, 4}, 0, {1008, -16}, {57, 150, 214, 255} }},
};

Gfx landie_alt_collar_Left_Thigh_Color_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Thigh_Color_mesh_layer_5_vtx_0 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP1Triangle(1, 3, 4, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Leg_mesh_layer_1_vtx_0[24] = {
	{{ {-20, -64, 27}, 0, {368, 112}, {133, 0, 33, 255} }},
	{{ {-19, -12, 8}, 0, {624, -16}, {154, 49, 199, 255} }},
	{{ {-19, -64, 8}, 0, {368, -16}, {144, 255, 195, 255} }},
	{{ {-21, -11, 26}, 0, {624, 112}, {143, 49, 30, 255} }},
	{{ {-10, -11, 41}, 0, {624, 240}, {196, 50, 100, 255} }},
	{{ {-10, -64, 42}, 0, {368, 240}, {190, 1, 109, 255} }},
	{{ {8, -65, 45}, 0, {368, 368}, {35, 1, 122, 255} }},
	{{ {8, -12, 44}, 0, {624, 368}, {32, 50, 112, 255} }},
	{{ {21, -13, 33}, 0, {624, 496}, {105, 47, 54, 255} }},
	{{ {21, -66, 33}, 0, {368, 496}, {113, 1, 59, 255} }},
	{{ {23, -66, 15}, 0, {368, 624}, {123, 0, 223, 255} }},
	{{ {23, -14, 14}, 0, {624, 624}, {114, 45, 225, 255} }},
	{{ {12, -14, -1}, 0, {624, 752}, {63, 46, 156, 255} }},
	{{ {12, -66, 0}, 0, {368, 752}, {68, 255, 149, 255} }},
	{{ {-5, -65, -3}, 0, {368, 880}, {225, 255, 133, 255} }},
	{{ {-5, -13, -4}, 0, {624, 880}, {227, 48, 142, 255} }},
	{{ {-19, -64, 8}, 0, {368, 1008}, {144, 255, 195, 255} }},
	{{ {-19, -12, 8}, 0, {624, 1008}, {154, 49, 199, 255} }},
	{{ {1, 8, 20}, 0, {752, 368}, {3, 127, 254, 255} }},
	{{ {23, -14, 14}, 0, {752, 496}, {114, 45, 225, 255} }},
	{{ {12, -14, -1}, 0, {880, 496}, {63, 46, 156, 255} }},
	{{ {-5, -13, -4}, 0, {880, 368}, {227, 48, 142, 255} }},
	{{ {-19, -12, 8}, 0, {880, 240}, {154, 49, 199, 255} }},
	{{ {-21, -11, 26}, 0, {752, 240}, {143, 49, 30, 255} }},
};

Gfx landie_alt_collar_Left_Leg_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Leg_mesh_layer_1_vtx_0 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 0, 5, 0),
	gsSP2Triangles(6, 4, 5, 0, 6, 7, 4, 0),
	gsSP2Triangles(8, 7, 6, 0, 8, 6, 9, 0),
	gsSP2Triangles(10, 8, 9, 0, 10, 11, 8, 0),
	gsSP2Triangles(12, 11, 10, 0, 12, 10, 13, 0),
	gsSP2Triangles(14, 12, 13, 0, 14, 15, 12, 0),
	gsSP2Triangles(16, 15, 14, 0, 16, 17, 15, 0),
	gsSP2Triangles(8, 18, 7, 0, 8, 19, 18, 0),
	gsSP2Triangles(20, 18, 19, 0, 20, 21, 18, 0),
	gsSP2Triangles(18, 21, 22, 0, 18, 22, 23, 0),
	gsSP2Triangles(18, 23, 4, 0, 18, 4, 7, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Leg_mesh_layer_1_vtx_1[9] = {
	{{ {2, -81, 21}, 0, {240, 368}, {253, 129, 2, 255} }},
	{{ {-19, -64, 8}, 0, {112, 240}, {188, 153, 225, 255} }},
	{{ {-5, -65, -3}, 0, {112, 368}, {231, 150, 190, 255} }},
	{{ {-20, -64, 27}, 0, {240, 240}, {181, 156, 21, 255} }},
	{{ {-10, -64, 42}, 0, {368, 240}, {213, 154, 63, 255} }},
	{{ {8, -65, 45}, 0, {368, 368}, {12, 151, 71, 255} }},
	{{ {21, -66, 33}, 0, {368, 496}, {60, 151, 39, 255} }},
	{{ {23, -66, 15}, 0, {240, 496}, {70, 151, 238, 255} }},
	{{ {12, -66, 0}, 0, {112, 496}, {32, 150, 194, 255} }},
};

Gfx landie_alt_collar_Left_Leg_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Left_Leg_mesh_layer_1_vtx_1 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 0, 5, 4, 0),
	gsSP2Triangles(6, 5, 0, 0, 6, 0, 7, 0),
	gsSP2Triangles(8, 7, 0, 0, 8, 0, 2, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Leg_mesh_layer_1_vtx_2[20] = {
	{{ {-19, -64, 8}, 0, {112, 240}, {146, 236, 195, 255} }},
	{{ {-21, -51, 7}, 0, {112, 240}, {144, 236, 199, 255} }},
	{{ {-6, -52, -5}, 0, {112, 368}, {221, 239, 135, 255} }},
	{{ {-5, -65, -3}, 0, {112, 368}, {225, 239, 134, 255} }},
	{{ {-19, -64, 8}, 0, {368, -16}, {146, 236, 195, 255} }},
	{{ {-23, -51, 27}, 0, {368, 112}, {135, 235, 33, 255} }},
	{{ {-21, -51, 7}, 0, {368, -16}, {144, 236, 199, 255} }},
	{{ {-20, -64, 27}, 0, {368, 112}, {135, 235, 33, 255} }},
	{{ {-11, -51, 43}, 0, {368, 240}, {188, 238, 106, 255} }},
	{{ {-10, -64, 42}, 0, {368, 240}, {192, 238, 108, 255} }},
	{{ {8, -52, 46}, 0, {368, 368}, {30, 241, 122, 255} }},
	{{ {8, -65, 45}, 0, {368, 368}, {34, 241, 121, 255} }},
	{{ {23, -53, 34}, 0, {368, 496}, {110, 240, 61, 255} }},
	{{ {21, -66, 33}, 0, {368, 496}, {111, 240, 60, 255} }},
	{{ {25, -53, 14}, 0, {368, 624}, {121, 238, 223, 255} }},
	{{ {23, -66, 15}, 0, {368, 624}, {121, 238, 223, 255} }},
	{{ {13, -53, -2}, 0, {368, 752}, {65, 239, 148, 255} }},
	{{ {12, -66, 0}, 0, {368, 752}, {66, 239, 149, 255} }},
	{{ {-6, -52, -5}, 0, {368, 880}, {221, 239, 135, 255} }},
	{{ {-5, -65, -3}, 0, {368, 880}, {225, 239, 134, 255} }},
};

Gfx landie_alt_collar_Left_Leg_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Left_Leg_mesh_layer_1_vtx_2 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 7, 5, 0),
	gsSP2Triangles(7, 8, 5, 0, 7, 9, 8, 0),
	gsSP2Triangles(9, 10, 8, 0, 9, 11, 10, 0),
	gsSP2Triangles(11, 12, 10, 0, 11, 13, 12, 0),
	gsSP2Triangles(13, 14, 12, 0, 13, 15, 14, 0),
	gsSP2Triangles(15, 16, 14, 0, 15, 17, 16, 0),
	gsSP2Triangles(17, 18, 16, 0, 17, 19, 18, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Shoe_mesh_layer_1_vtx_0[39] = {
	{{ {13, 14, 53}, 0, {496, 368}, {251, 15, 126, 255} }},
	{{ {47, 23, 41}, 0, {368, 240}, {83, 24, 93, 255} }},
	{{ {22, 32, 43}, 0, {368, 368}, {9, 55, 114, 255} }},
	{{ {46, 5, 45}, 0, {496, 240}, {78, 234, 98, 255} }},
	{{ {32, -13, 43}, 0, {624, 240}, {32, 162, 79, 255} }},
	{{ {1, -5, 47}, 0, {624, 408}, {226, 184, 100, 255} }},
	{{ {-12, 12, 45}, 0, {496, 496}, {165, 23, 86, 255} }},
	{{ {1, 30, 41}, 0, {368, 496}, {192, 73, 82, 255} }},
	{{ {-22, 11, 20}, 0, {496, 624}, {132, 29, 1, 255} }},
	{{ {-19, -6, 20}, 0, {624, 624}, {153, 182, 0, 255} }},
	{{ {-12, 12, -5}, 0, {496, 496}, {165, 18, 169, 255} }},
	{{ {-1, 31, -1}, 0, {368, 496}, {187, 71, 176, 255} }},
	{{ {-3, 33, 20}, 0, {368, 624}, {159, 82, 7, 255} }},
	{{ {13, 13, -13}, 0, {496, 368}, {251, 14, 130, 255} }},
	{{ {22, 32, -3}, 0, {368, 368}, {10, 54, 142, 255} }},
	{{ {49, 22, -1}, 0, {368, 240}, {87, 18, 166, 255} }},
	{{ {46, 5, -5}, 0, {496, 240}, {75, 230, 157, 255} }},
	{{ {58, 1, 20}, 0, {496, 112}, {120, 214, 2, 255} }},
	{{ {55, 24, 20}, 0, {368, 112}, {126, 13, 7, 255} }},
	{{ {41, -16, 20}, 0, {624, 112}, {60, 144, 0, 255} }},
	{{ {32, -13, -3}, 0, {624, 240}, {32, 162, 177, 255} }},
	{{ {1, -5, -7}, 0, {624, 408}, {226, 183, 156, 255} }},
	{{ {10, -18, 20}, 0, {752, 368}, {235, 131, 0, 255} }},
	{{ {41, -16, 20}, 0, {752, 240}, {60, 144, 0, 255} }},
	{{ {-9, -6, 41}, 0, {624, 496}, {184, 176, 68, 255} }},
	{{ {-19, -6, 20}, 0, {752, 496}, {153, 182, 0, 255} }},
	{{ {-9, -6, -1}, 0, {624, 496}, {184, 176, 188, 255} }},
	{{ {26, 36, 20}, 0, {240, 368}, {21, 125, 1, 255} }},
	{{ {47, 23, 41}, 0, {368, 240}, {46, 115, 28, 255} }},
	{{ {55, 24, 20}, 0, {240, 240}, {48, 118, 255, 255} }},
	{{ {22, 32, 43}, 0, {368, 368}, {13, 124, 24, 255} }},
	{{ {1, 30, 41}, 0, {368, 496}, {241, 125, 18, 255} }},
	{{ {1, 30, 41}, 0, {368, 496}, {241, 125, 18, 255} }},
	{{ {26, 36, 20}, 0, {240, 368}, {21, 125, 1, 255} }},
	{{ {-3, 33, 20}, 0, {240, 496}, {240, 126, 3, 255} }},
	{{ {-1, 31, -1}, 0, {368, 496}, {244, 126, 241, 255} }},
	{{ {22, 32, -3}, 0, {368, 368}, {16, 123, 231, 255} }},
	{{ {49, 22, -1}, 0, {368, 240}, {46, 115, 228, 255} }},
	{{ {55, 24, 20}, 0, {240, 240}, {48, 118, 255, 255} }},
};

Gfx landie_alt_collar_Left_Shoe_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Shoe_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 0, 5, 4, 0),
	gsSP2Triangles(6, 5, 0, 0, 7, 6, 0, 0),
	gsSP2Triangles(7, 0, 2, 0, 8, 6, 7, 0),
	gsSP2Triangles(9, 6, 8, 0, 10, 9, 8, 0),
	gsSP2Triangles(11, 10, 8, 0, 11, 8, 12, 0),
	gsSP2Triangles(8, 7, 12, 0, 11, 13, 10, 0),
	gsSP2Triangles(11, 14, 13, 0, 15, 13, 14, 0),
	gsSP2Triangles(15, 16, 13, 0, 15, 17, 16, 0),
	gsSP2Triangles(15, 18, 17, 0, 1, 17, 18, 0),
	gsSP2Triangles(1, 3, 17, 0, 4, 17, 3, 0),
	gsSP2Triangles(4, 19, 17, 0, 17, 19, 20, 0),
	gsSP2Triangles(17, 20, 16, 0, 13, 16, 20, 0),
	gsSP2Triangles(13, 20, 21, 0, 22, 21, 20, 0),
	gsSP2Triangles(22, 20, 23, 0, 22, 23, 4, 0),
	gsSP2Triangles(22, 4, 5, 0, 24, 22, 5, 0),
	gsSP2Triangles(6, 24, 5, 0, 9, 24, 6, 0),
	gsSP2Triangles(24, 25, 22, 0, 26, 22, 25, 0),
	gsSP2Triangles(26, 21, 22, 0, 10, 21, 26, 0),
	gsSP2Triangles(10, 26, 9, 0, 10, 13, 21, 0),
	gsSP2Triangles(27, 28, 29, 0, 27, 30, 28, 0),
	gsSP1Triangle(31, 30, 27, 0),
	gsSPVertex(landie_alt_collar_Left_Shoe_mesh_layer_1_vtx_0 + 32, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 1, 3, 2, 0),
	gsSP2Triangles(1, 4, 3, 0, 1, 5, 4, 0),
	gsSP1Triangle(1, 6, 5, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Left_Shoe_mesh_layer_5_vtx_0[9] = {
	{{ {27, 36, 20}, 0, {-16, 509}, {21, 125, 1, 255} }},
	{{ {47, 23, 41}, 0, {455, 106}, {47, 115, 29, 255} }},
	{{ {55, 24, 20}, 0, {-16, -16}, {49, 117, 255, 255} }},
	{{ {22, 32, 43}, 0, {496, 552}, {13, 124, 25, 255} }},
	{{ {1, 30, 41}, 0, {465, 902}, {241, 125, 18, 255} }},
	{{ {-3, 33, 20}, 0, {-16, 1008}, {240, 126, 3, 255} }},
	{{ {-1, 31, -1}, 0, {465, 902}, {243, 125, 241, 255} }},
	{{ {22, 32, -3}, 0, {496, 552}, {16, 123, 230, 255} }},
	{{ {49, 22, -1}, 0, {455, 106}, {47, 115, 228, 255} }},
};

Gfx landie_alt_collar_Left_Shoe_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Left_Shoe_mesh_layer_5_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 0, 5, 0),
	gsSP2Triangles(0, 6, 5, 0, 0, 7, 6, 0),
	gsSP2Triangles(0, 8, 7, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Thigh_Color_mesh_layer_1_vtx_0[47] = {
	{{ {111, -15, -24}, 0, {368, 112}, {99, 177, 10, 255} }},
	{{ {99, -10, 7}, 0, {368, -16}, {68, 189, 84, 255} }},
	{{ {57, -36, -4}, 0, {496, -16}, {1, 152, 74, 255} }},
	{{ {71, -43, -41}, 0, {496, 112}, {40, 136, 241, 255} }},
	{{ {16, -36, -27}, 0, {624, -16}, {190, 155, 41, 255} }},
	{{ {26, -42, -54}, 0, {624, 112}, {219, 140, 221, 255} }},
	{{ {76, -21, -75}, 0, {496, 240}, {48, 190, 159, 255} }},
	{{ {30, -24, -77}, 0, {624, 240}, {230, 186, 153, 255} }},
	{{ {68, 21, -83}, 0, {496, 368}, {26, 24, 134, 255} }},
	{{ {24, 6, -84}, 0, {624, 368}, {217, 3, 135, 255} }},
	{{ {-8, -8, -56}, 0, {752, 368}, {140, 223, 217, 255} }},
	{{ {26, -42, -54}, 0, {752, 240}, {219, 140, 221, 255} }},
	{{ {16, -36, -27}, 0, {880, 240}, {190, 155, 41, 255} }},
	{{ {4, -9, -12}, 0, {880, 368}, {163, 216, 76, 255} }},
	{{ {-2, 21, -19}, 0, {880, 496}, {147, 31, 57, 255} }},
	{{ {1, 38, -43}, 0, {752, 496}, {155, 76, 245, 255} }},
	{{ {12, 32, -70}, 0, {624, 496}, {186, 62, 170, 255} }},
	{{ {52, 57, -65}, 0, {496, 496}, {247, 102, 180, 255} }},
	{{ {37, 64, -28}, 0, {496, 624}, {215, 119, 15, 255} }},
	{{ {1, 38, -43}, 0, {624, 624}, {155, 76, 245, 255} }},
	{{ {32, 42, 6}, 0, {496, 752}, {201, 65, 94, 255} }},
	{{ {-2, 21, -19}, 0, {624, 752}, {147, 31, 57, 255} }},
	{{ {42, 0, 14}, 0, {496, 880}, {216, 228, 117, 255} }},
	{{ {4, -9, -12}, 0, {624, 880}, {163, 216, 76, 255} }},
	{{ {57, -36, -4}, 0, {496, 1008}, {1, 152, 74, 255} }},
	{{ {16, -36, -27}, 0, {624, 1008}, {190, 155, 41, 255} }},
	{{ {99, -10, 7}, 0, {368, 1008}, {68, 189, 84, 255} }},
	{{ {87, 14, 23}, 0, {368, 880}, {33, 251, 122, 255} }},
	{{ {82, 44, 14}, 0, {368, 752}, {22, 72, 102, 255} }},
	{{ {87, 62, -14}, 0, {368, 624}, {35, 117, 35, 255} }},
	{{ {99, 57, -46}, 0, {368, 496}, {62, 103, 215, 255} }},
	{{ {111, 33, -62}, 0, {368, 368}, {89, 39, 175, 255} }},
	{{ {99, 57, -46}, 0, {368, 496}, {62, 103, 215, 255} }},
	{{ {122, 30, -12}, 0, {240, 368}, {116, 33, 39, 255} }},
	{{ {111, 33, -62}, 0, {368, 368}, {89, 39, 175, 255} }},
	{{ {87, 62, -14}, 0, {240, 496}, {35, 117, 35, 255} }},
	{{ {82, 44, 14}, 0, {112, 496}, {22, 72, 102, 255} }},
	{{ {87, 14, 23}, 0, {112, 368}, {33, 251, 122, 255} }},
	{{ {99, -10, 7}, 0, {112, 240}, {68, 189, 84, 255} }},
	{{ {111, -15, -24}, 0, {240, 240}, {99, 177, 10, 255} }},
	{{ {116, 3, -53}, 0, {368, 240}, {107, 220, 198, 255} }},
	{{ {76, -21, -75}, 0, {496, 240}, {48, 190, 159, 255} }},
	{{ {111, -15, -24}, 0, {368, 112}, {99, 177, 10, 255} }},
	{{ {71, -43, -41}, 0, {496, 112}, {40, 136, 241, 255} }},
	{{ {68, 21, -83}, 0, {496, 368}, {26, 24, 134, 255} }},
	{{ {52, 57, -65}, 0, {496, 496}, {247, 102, 180, 255} }},
	{{ {24, 6, -84}, 0, {624, 368}, {217, 3, 135, 255} }},
};

Gfx landie_alt_collar_Right_Thigh_Color_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Thigh_Color_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(3, 2, 4, 0, 3, 4, 5, 0),
	gsSP2Triangles(6, 3, 5, 0, 6, 5, 7, 0),
	gsSP2Triangles(8, 6, 7, 0, 8, 7, 9, 0),
	gsSP2Triangles(10, 9, 7, 0, 10, 7, 11, 0),
	gsSP2Triangles(10, 11, 12, 0, 10, 12, 13, 0),
	gsSP2Triangles(14, 10, 13, 0, 14, 15, 10, 0),
	gsSP2Triangles(16, 10, 15, 0, 16, 9, 10, 0),
	gsSP2Triangles(17, 9, 16, 0, 18, 17, 16, 0),
	gsSP2Triangles(18, 16, 19, 0, 20, 18, 19, 0),
	gsSP2Triangles(20, 19, 21, 0, 22, 20, 21, 0),
	gsSP2Triangles(22, 21, 23, 0, 24, 22, 23, 0),
	gsSP2Triangles(24, 23, 25, 0, 26, 22, 24, 0),
	gsSP2Triangles(26, 27, 22, 0, 27, 20, 22, 0),
	gsSP2Triangles(27, 28, 20, 0, 28, 18, 20, 0),
	gsSP2Triangles(28, 29, 18, 0, 29, 17, 18, 0),
	gsSP2Triangles(29, 30, 17, 0, 30, 8, 17, 0),
	gsSP1Triangle(30, 31, 8, 0),
	gsSPVertex(landie_alt_collar_Right_Thigh_Color_mesh_layer_1_vtx_0 + 32, 15, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 1, 3, 0, 4, 5, 1, 0),
	gsSP2Triangles(1, 5, 6, 0, 1, 6, 7, 0),
	gsSP2Triangles(1, 7, 8, 0, 1, 8, 2, 0),
	gsSP2Triangles(2, 8, 9, 0, 9, 8, 10, 0),
	gsSP2Triangles(9, 10, 11, 0, 2, 9, 12, 0),
	gsSP1Triangle(13, 12, 14, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Thigh_Color_mesh_layer_5_vtx_0[5] = {
	{{ {76, -21, -75}, 0, {48, -16}, {80, 168, 211, 255} }},
	{{ {116, 3, -53}, 0, {48, 887}, {78, 166, 212, 255} }},
	{{ {111, -15, -24}, 0, {579, 887}, {77, 157, 236, 255} }},
	{{ {71, -43, -42}, 0, {579, -16}, {74, 153, 254, 255} }},
	{{ {57, -36, -4}, 0, {1008, -16}, {57, 150, 42, 255} }},
};

Gfx landie_alt_collar_Right_Thigh_Color_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Thigh_Color_mesh_layer_5_vtx_0 + 0, 5, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP1Triangle(2, 4, 3, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Leg_mesh_layer_1_vtx_0[24] = {
	{{ {-20, -64, -27}, 0, {368, 112}, {133, 0, 223, 255} }},
	{{ {-19, -64, -8}, 0, {368, -16}, {144, 255, 61, 255} }},
	{{ {-19, -12, -8}, 0, {624, -16}, {154, 49, 57, 255} }},
	{{ {-21, -11, -26}, 0, {624, 112}, {143, 49, 226, 255} }},
	{{ {-10, -11, -41}, 0, {624, 240}, {196, 50, 156, 255} }},
	{{ {-10, -64, -42}, 0, {368, 240}, {190, 1, 147, 255} }},
	{{ {8, -65, -45}, 0, {368, 368}, {35, 1, 134, 255} }},
	{{ {8, -12, -44}, 0, {624, 368}, {32, 50, 144, 255} }},
	{{ {1, 8, -20}, 0, {752, 368}, {3, 127, 2, 255} }},
	{{ {-21, -11, -26}, 0, {752, 240}, {143, 49, 226, 255} }},
	{{ {-19, -12, -8}, 0, {880, 240}, {154, 49, 57, 255} }},
	{{ {-5, -13, 4}, 0, {880, 368}, {227, 48, 114, 255} }},
	{{ {12, -14, 1}, 0, {880, 496}, {63, 46, 100, 255} }},
	{{ {23, -14, -14}, 0, {752, 496}, {114, 45, 31, 255} }},
	{{ {21, -13, -33}, 0, {624, 496}, {105, 47, 202, 255} }},
	{{ {21, -66, -33}, 0, {368, 496}, {113, 1, 197, 255} }},
	{{ {23, -66, -15}, 0, {368, 624}, {123, 0, 33, 255} }},
	{{ {23, -14, -14}, 0, {624, 624}, {114, 45, 31, 255} }},
	{{ {12, -14, 1}, 0, {624, 752}, {63, 46, 100, 255} }},
	{{ {12, -66, 0}, 0, {368, 752}, {68, 255, 107, 255} }},
	{{ {-5, -65, 3}, 0, {368, 880}, {225, 255, 123, 255} }},
	{{ {-5, -13, 4}, 0, {624, 880}, {227, 48, 114, 255} }},
	{{ {-19, -64, -8}, 0, {368, 1008}, {144, 255, 61, 255} }},
	{{ {-19, -12, -8}, 0, {624, 1008}, {154, 49, 57, 255} }},
};

Gfx landie_alt_collar_Right_Leg_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Leg_mesh_layer_1_vtx_0 + 0, 24, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 0, 3, 0, 4, 5, 0, 0),
	gsSP2Triangles(6, 5, 4, 0, 6, 4, 7, 0),
	gsSP2Triangles(8, 7, 4, 0, 8, 4, 9, 0),
	gsSP2Triangles(8, 9, 10, 0, 8, 10, 11, 0),
	gsSP2Triangles(12, 8, 11, 0, 12, 13, 8, 0),
	gsSP2Triangles(14, 8, 13, 0, 14, 7, 8, 0),
	gsSP2Triangles(14, 6, 7, 0, 14, 15, 6, 0),
	gsSP2Triangles(16, 15, 14, 0, 16, 14, 17, 0),
	gsSP2Triangles(18, 16, 17, 0, 18, 19, 16, 0),
	gsSP2Triangles(20, 19, 18, 0, 20, 18, 21, 0),
	gsSP2Triangles(22, 20, 21, 0, 22, 21, 23, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Leg_mesh_layer_1_vtx_1[9] = {
	{{ {2, -81, -21}, 0, {240, 368}, {253, 129, 254, 255} }},
	{{ {-5, -65, 3}, 0, {112, 368}, {231, 150, 66, 255} }},
	{{ {-19, -64, -8}, 0, {112, 240}, {188, 153, 31, 255} }},
	{{ {12, -66, 0}, 0, {112, 496}, {32, 150, 62, 255} }},
	{{ {23, -66, -15}, 0, {240, 496}, {70, 151, 18, 255} }},
	{{ {21, -66, -33}, 0, {368, 496}, {60, 151, 217, 255} }},
	{{ {8, -65, -45}, 0, {368, 368}, {12, 151, 185, 255} }},
	{{ {-10, -64, -42}, 0, {368, 240}, {213, 154, 193, 255} }},
	{{ {-20, -64, -27}, 0, {240, 240}, {181, 156, 235, 255} }},
};

Gfx landie_alt_collar_Right_Leg_mesh_layer_1_tri_1[] = {
	gsSPVertex(landie_alt_collar_Right_Leg_mesh_layer_1_vtx_1 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(3, 0, 4, 0, 5, 4, 0, 0),
	gsSP2Triangles(5, 0, 6, 0, 0, 7, 6, 0),
	gsSP2Triangles(0, 8, 7, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Leg_mesh_layer_1_vtx_2[20] = {
	{{ {-19, -64, -8}, 0, {112, 240}, {146, 236, 61, 255} }},
	{{ {-5, -65, 3}, 0, {112, 368}, {225, 239, 122, 255} }},
	{{ {-6, -52, 5}, 0, {112, 368}, {221, 239, 121, 255} }},
	{{ {-21, -51, -7}, 0, {112, 240}, {144, 236, 57, 255} }},
	{{ {-19, -64, -8}, 0, {368, -16}, {146, 236, 61, 255} }},
	{{ {-21, -51, -7}, 0, {368, -16}, {144, 236, 57, 255} }},
	{{ {-23, -51, -27}, 0, {368, 112}, {135, 235, 223, 255} }},
	{{ {-20, -64, -27}, 0, {368, 112}, {135, 235, 223, 255} }},
	{{ {-11, -51, -43}, 0, {368, 240}, {188, 238, 150, 255} }},
	{{ {-10, -64, -42}, 0, {368, 240}, {192, 238, 148, 255} }},
	{{ {8, -52, -46}, 0, {368, 368}, {30, 241, 134, 255} }},
	{{ {8, -65, -45}, 0, {368, 368}, {34, 241, 135, 255} }},
	{{ {23, -53, -34}, 0, {368, 496}, {110, 240, 195, 255} }},
	{{ {21, -66, -33}, 0, {368, 496}, {111, 240, 196, 255} }},
	{{ {25, -53, -14}, 0, {368, 624}, {121, 238, 33, 255} }},
	{{ {23, -66, -15}, 0, {368, 624}, {121, 238, 33, 255} }},
	{{ {13, -53, 2}, 0, {368, 752}, {65, 239, 108, 255} }},
	{{ {12, -66, 0}, 0, {368, 752}, {66, 239, 107, 255} }},
	{{ {-6, -52, 5}, 0, {368, 880}, {221, 239, 121, 255} }},
	{{ {-5, -65, 3}, 0, {368, 880}, {225, 239, 122, 255} }},
};

Gfx landie_alt_collar_Right_Leg_mesh_layer_1_tri_2[] = {
	gsSPVertex(landie_alt_collar_Right_Leg_mesh_layer_1_vtx_2 + 0, 20, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 2, 3, 0),
	gsSP2Triangles(4, 5, 6, 0, 4, 6, 7, 0),
	gsSP2Triangles(7, 6, 8, 0, 7, 8, 9, 0),
	gsSP2Triangles(9, 8, 10, 0, 9, 10, 11, 0),
	gsSP2Triangles(11, 10, 12, 0, 11, 12, 13, 0),
	gsSP2Triangles(13, 12, 14, 0, 13, 14, 15, 0),
	gsSP2Triangles(15, 14, 16, 0, 15, 16, 17, 0),
	gsSP2Triangles(17, 16, 18, 0, 17, 18, 19, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Shoe_DL_mesh_layer_1_vtx_0[39] = {
	{{ {13, 13, -53}, 0, {496, 368}, {251, 15, 130, 255} }},
	{{ {22, 32, -43}, 0, {368, 368}, {9, 55, 142, 255} }},
	{{ {47, 23, -41}, 0, {368, 240}, {83, 24, 163, 255} }},
	{{ {1, 30, -41}, 0, {368, 496}, {192, 73, 174, 255} }},
	{{ {-12, 12, -45}, 0, {496, 496}, {165, 23, 170, 255} }},
	{{ {1, -5, -47}, 0, {624, 408}, {226, 184, 156, 255} }},
	{{ {32, -13, -43}, 0, {624, 240}, {32, 162, 177, 255} }},
	{{ {46, 5, -45}, 0, {496, 240}, {78, 234, 158, 255} }},
	{{ {58, 1, -20}, 0, {496, 112}, {120, 214, 254, 255} }},
	{{ {55, 24, -20}, 0, {368, 112}, {126, 13, 249, 255} }},
	{{ {49, 22, 1}, 0, {368, 240}, {87, 18, 90, 255} }},
	{{ {46, 5, 5}, 0, {496, 240}, {75, 230, 99, 255} }},
	{{ {13, 13, 13}, 0, {496, 368}, {251, 14, 126, 255} }},
	{{ {22, 32, 3}, 0, {368, 368}, {10, 54, 114, 255} }},
	{{ {-1, 31, 1}, 0, {368, 496}, {187, 71, 80, 255} }},
	{{ {-12, 12, 5}, 0, {496, 496}, {165, 18, 87, 255} }},
	{{ {-22, 11, -20}, 0, {496, 624}, {132, 29, 255, 255} }},
	{{ {-3, 33, -20}, 0, {368, 624}, {159, 82, 249, 255} }},
	{{ {-19, -6, -20}, 0, {624, 624}, {153, 182, 0, 255} }},
	{{ {-9, -6, -41}, 0, {624, 496}, {184, 176, 188, 255} }},
	{{ {10, -18, -20}, 0, {752, 368}, {235, 131, 0, 255} }},
	{{ {41, -16, -20}, 0, {752, 240}, {60, 144, 0, 255} }},
	{{ {32, -13, 3}, 0, {624, 240}, {32, 162, 79, 255} }},
	{{ {1, -5, 7}, 0, {624, 408}, {226, 184, 100, 255} }},
	{{ {41, -16, -20}, 0, {624, 112}, {60, 144, 0, 255} }},
	{{ {-9, -6, 1}, 0, {624, 496}, {184, 176, 68, 255} }},
	{{ {-19, -6, -20}, 0, {752, 496}, {153, 182, 0, 255} }},
	{{ {26, 36, -20}, 0, {240, 368}, {21, 125, 255, 255} }},
	{{ {55, 24, -20}, 0, {240, 240}, {48, 118, 1, 255} }},
	{{ {47, 23, -41}, 0, {368, 240}, {46, 115, 228, 255} }},
	{{ {49, 22, 1}, 0, {368, 240}, {46, 115, 28, 255} }},
	{{ {22, 32, 3}, 0, {368, 368}, {16, 123, 25, 255} }},
	{{ {26, 36, -20}, 0, {240, 368}, {21, 125, 255, 255} }},
	{{ {-1, 31, 1}, 0, {368, 496}, {244, 126, 14, 255} }},
	{{ {22, 32, 3}, 0, {368, 368}, {16, 123, 25, 255} }},
	{{ {-3, 33, -20}, 0, {240, 496}, {240, 126, 253, 255} }},
	{{ {1, 30, -41}, 0, {368, 496}, {241, 125, 238, 255} }},
	{{ {22, 32, -43}, 0, {368, 368}, {13, 124, 232, 255} }},
	{{ {47, 23, -41}, 0, {368, 240}, {46, 115, 228, 255} }},
};

Gfx landie_alt_collar_Right_Shoe_DL_mesh_layer_1_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Shoe_DL_mesh_layer_1_vtx_0 + 0, 32, 0),
	gsSP2Triangles(0, 1, 2, 0, 3, 1, 0, 0),
	gsSP2Triangles(3, 0, 4, 0, 4, 0, 5, 0),
	gsSP2Triangles(0, 6, 5, 0, 0, 7, 6, 0),
	gsSP2Triangles(0, 2, 7, 0, 2, 8, 7, 0),
	gsSP2Triangles(2, 9, 8, 0, 10, 8, 9, 0),
	gsSP2Triangles(10, 11, 8, 0, 10, 12, 11, 0),
	gsSP2Triangles(10, 13, 12, 0, 14, 12, 13, 0),
	gsSP2Triangles(14, 15, 12, 0, 14, 16, 15, 0),
	gsSP2Triangles(14, 17, 16, 0, 16, 17, 3, 0),
	gsSP2Triangles(16, 3, 4, 0, 18, 16, 4, 0),
	gsSP2Triangles(18, 4, 19, 0, 4, 5, 19, 0),
	gsSP2Triangles(19, 5, 20, 0, 20, 5, 6, 0),
	gsSP2Triangles(20, 6, 21, 0, 20, 21, 22, 0),
	gsSP2Triangles(20, 22, 23, 0, 12, 23, 22, 0),
	gsSP2Triangles(12, 22, 11, 0, 8, 11, 22, 0),
	gsSP2Triangles(8, 22, 24, 0, 6, 8, 24, 0),
	gsSP2Triangles(6, 7, 8, 0, 15, 23, 12, 0),
	gsSP2Triangles(15, 25, 23, 0, 15, 18, 25, 0),
	gsSP2Triangles(15, 16, 18, 0, 25, 20, 23, 0),
	gsSP2Triangles(25, 26, 20, 0, 19, 20, 26, 0),
	gsSP2Triangles(27, 28, 29, 0, 27, 30, 28, 0),
	gsSP1Triangle(27, 31, 30, 0),
	gsSPVertex(landie_alt_collar_Right_Shoe_DL_mesh_layer_1_vtx_0 + 32, 7, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(4, 3, 0, 0, 4, 0, 5, 0),
	gsSP1Triangle(0, 6, 5, 0),
	gsSPEndDisplayList(),
};

Vtx landie_alt_collar_Right_Shoe_DL_mesh_layer_5_vtx_0[9] = {
	{{ {27, 36, -20}, 0, {-16, 509}, {21, 125, 255, 255} }},
	{{ {55, 24, -20}, 0, {-16, -16}, {49, 117, 1, 255} }},
	{{ {47, 23, -41}, 0, {455, 106}, {47, 115, 227, 255} }},
	{{ {49, 22, 1}, 0, {455, 106}, {47, 115, 28, 255} }},
	{{ {22, 32, 3}, 0, {496, 552}, {16, 123, 26, 255} }},
	{{ {-1, 31, 1}, 0, {465, 902}, {243, 125, 15, 255} }},
	{{ {-3, 33, -20}, 0, {-16, 1008}, {240, 126, 253, 255} }},
	{{ {1, 30, -41}, 0, {465, 902}, {241, 125, 238, 255} }},
	{{ {22, 32, -43}, 0, {496, 552}, {13, 124, 231, 255} }},
};

Gfx landie_alt_collar_Right_Shoe_DL_mesh_layer_5_tri_0[] = {
	gsSPVertex(landie_alt_collar_Right_Shoe_DL_mesh_layer_5_vtx_0 + 0, 9, 0),
	gsSP2Triangles(0, 1, 2, 0, 0, 3, 1, 0),
	gsSP2Triangles(0, 4, 3, 0, 0, 5, 4, 0),
	gsSP2Triangles(0, 6, 5, 0, 7, 6, 0, 0),
	gsSP2Triangles(7, 0, 8, 0, 0, 2, 8, 0),
	gsSPEndDisplayList(),
};


Gfx mat_landie_alt_collar_Fur__Skin_[] = {
	gsSPCopyLightsPlayerPart(SKIN),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Fur__Skin_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Cap_No_Cull[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(CAP),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Cap_No_Cull[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Cuffs__Gloves_[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(GLOVES),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Cuffs__Gloves_[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Tail__Hair_[] = {
	gsSPCopyLightsPlayerPart(HAIR),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Tail__Hair_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Metal__CAP_[] = {
	gsSPGeometryMode(G_CULL_BACK, G_TEXTURE_GEN),
	gsSPLight(&landie_alt_collar_Metal__CAP__lights.l, 1),
    gsSPLight(&landie_alt_collar_Metal__CAP__lights.a, 2),
    gsSPCopyLightEXT(2, 15),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, TEXEL1, 0, 0, 0, ENVIRONMENT, TEXEL0, 0, SHADE, TEXEL1, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(4032, 1984, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, landie_alt_collar_Metal_Shade_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 2047, 128),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, landie_alt_collar_Metal_Light_rgba16_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 512, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 2047, 128),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 16, 512, 1, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(1, 0, 0, 252, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Metal__CAP_[] = {
	gsSPGeometryMode(G_TEXTURE_GEN, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Shirt_L__Gloves_[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(GLOVES),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_shirt_emblem_ia4),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 255, 1024),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_4b, 2, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Shirt_L__Gloves_[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Collar__Shirt_[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(SHIRT),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Collar__Shirt_[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Metal_Bell[] = {
	gsSPGeometryMode(G_CULL_BACK, G_TEXTURE_GEN),
	gsSPSetLights1(landie_alt_collar_Metal_Bell_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL1, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL1, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(4032, 1984, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_I, G_IM_SIZ_16b, 1, landie_alt_collar_Metal_Shade_rgba16_i4),
	gsDPSetTile(G_IM_FMT_I, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_I, G_IM_SIZ_4b, 4, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(0, 0, 0, 252, 124),
	gsDPSetTextureImage(G_IM_FMT_I, G_IM_SIZ_16b, 1, landie_alt_collar_Metal_Light_rgba16_i4),
	gsDPSetTile(G_IM_FMT_I, G_IM_SIZ_16b, 0, 128, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_I, G_IM_SIZ_4b, 4, 128, 1, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 6, 0),
	gsDPSetTileSize(1, 0, 1, 252, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Metal_Bell[] = {
	gsSPGeometryMode(G_TEXTURE_GEN, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Collar_Holes__Shirt_[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(SHIRT),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_collar_holes_ia4),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 63, 2048),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_4b, 1, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 60),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Collar_Holes__Shirt_[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Shirt_Heart__Gloves_[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(GLOVES),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_landie_shirt_heart_ia8),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 255, 1024),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b, 2, 0, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Shirt_Heart__Gloves_[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Bell_Hole[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPSetLights1(landie_alt_collar_Bell_Hole_lights),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_bell_hole_ia4),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 63, 2048),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_4b, 1, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 60),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Bell_Hole[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Hair[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(HAIR),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Hair[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Inner_Ear__Shoes_[] = {
	gsSPCopyLightsPlayerPart(SHOES),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Inner_Ear__Shoes_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_[] = {
	gsSPCopyLightsPlayerPart(SKIN),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_inner_hair_gradient_ia4),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 63, 2048),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_4b, 1, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0, G_TX_WRAP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 60),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Mouth_Neutral__Skin_[] = {
	gsSPCopyLightsPlayerPart(SKIN),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_mouth_neutral_ia4),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 255, 1024),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_4b, 2, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Mouth_Neutral__Skin_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Fur_Spots__Shoes_[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsSPCopyLightsPlayerPart(SHOES),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_landie_fur_spots_ia8),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Fur_Spots__Shoes_[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Eyes_Blink[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_eyes_blink_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 58),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_landie_eyes_blink_ci8),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Eyes_Blink[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Eyes_Closed[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_eyes_closed_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 12),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_16b, 1, landie_alt_collar_landie_eyes_closed_ci4),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 255, 1024),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_4b, 2, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Eyes_Closed[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Eyes_Look_Left[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_eyes_lookLeft_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 68),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_landie_eyes_lookLeft_ci8),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Eyes_Look_Left[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Eyes_Look_Right[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_eyes_lookRight_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 68),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_landie_eyes_lookRight_ci8),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Eyes_Look_Right[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Eyes_Look_Up[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_eyes_lookUp_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 72),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_landie_eyes_lookUp_ci8),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Eyes_Look_Up[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Eyes_Look_Down[] = {
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0, 0, 0, 0, TEXEL0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsDPSetTextureLUT(G_TT_RGBA16),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_eyes_lookDown_pal_rgba16),
	gsDPSetTile(0, 0, 0, 256, 5, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadTLUTCmd(5, 72),
	gsDPSetTextureImage(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_landie_eyes_lookDown_ci8),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 511, 512),
	gsDPSetTile(G_IM_FMT_CI, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Eyes_Look_Down[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsDPSetTextureLUT(G_TT_NONE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Mouth_Dead__Skin_[] = {
	gsSPCopyLightsPlayerPart(SKIN),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT, TEXEL0, SHADE, TEXEL0_ALPHA, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, landie_alt_collar_landie_mouth_dead_rgba16),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Mouth_Dead__Skin_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Wing_Tip[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_wing_2_ia8),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 512),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Wing_Tip[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Wing_Base[] = {
	gsSPGeometryMode(G_CULL_BACK, 0),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0, 0, 0, 0, TEXEL0, TEXEL0, 0, ENVIRONMENT, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 1, landie_alt_collar_wing1_ia8),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 512),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_8b, 4, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 6, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 252),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Wing_Base[] = {
	gsSPGeometryMode(0, G_CULL_BACK),
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Cap[] = {
	gsSPCopyLightsPlayerPart(CAP),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Cap[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Gloves[] = {
	gsSPCopyLightsPlayerPart(GLOVES),
	gsDPPipeSync(),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Gloves[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx mat_landie_alt_collar_Paw_Beans__Gloves_[] = {
	gsSPCopyLightsPlayerPart(GLOVES),
	gsDPPipeSync(),
	gsDPSetCombineLERP(TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0, TEXEL0, 0, SHADE, 0, TEXEL0, 0, PRIMITIVE, 0),
	gsDPSetAlphaDither(G_AD_NOISE),
	gsSPTexture(65535, 65535, 0, 0, 1),
	gsDPSetPrimColor(0, 0, 255, 255, 255, 255),
	gsDPSetTextureImage(G_IM_FMT_IA, G_IM_SIZ_16b, 1, landie_alt_collar_landie_paw_beans_ia4),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_16b, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 127, 2048),
	gsDPSetTile(G_IM_FMT_IA, G_IM_SIZ_4b, 1, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 4, 0),
	gsDPSetTileSize(0, 0, 0, 60, 124),
	gsSPEndDisplayList(),
};

Gfx mat_revert_landie_alt_collar_Paw_Beans__Gloves_[] = {
	gsDPPipeSync(),
	gsDPSetAlphaDither(G_AD_DISABLE),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Butt_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(mat_landie_alt_collar_Tail__Hair_),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Tail__Hair_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Butt_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Butt_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_skinned_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Torso_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Torso_skinned_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_skinned_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Torso_skinned_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Torso_skinned_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Collar__Shirt_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Collar__Shirt_),
	gsSPDisplayList(mat_landie_alt_collar_Metal_Bell),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal_Bell),
	gsSPDisplayList(mat_landie_alt_collar_Collar_Holes__Shirt_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_6),
	gsSPDisplayList(mat_revert_landie_alt_collar_Collar_Holes__Shirt_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_3),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_4),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_5),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_1_tri_6),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_skinned_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Shirt_L__Gloves_),
	gsSPDisplayList(landie_alt_collar_Torso_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Shirt_L__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_skinned_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Torso_skinned_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Shirt_L__Gloves_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Shirt_L__Gloves_),
	gsSPDisplayList(mat_landie_alt_collar_Shirt_Heart__Gloves_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Shirt_Heart__Gloves_),
	gsSPDisplayList(mat_landie_alt_collar_Shirt_L__Gloves_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Shirt_L__Gloves_),
	gsSPDisplayList(mat_landie_alt_collar_Bell_Hole),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Bell_Hole),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Torso_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_0),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_1),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_2),
	gsSPDisplayList(landie_alt_collar_Torso_mesh_layer_5_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_1_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_DL_mesh_layer_5_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_1_tri_5),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Head_Dead_Switch_Option_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Neutral__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Hair),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Hair),
	gsSPDisplayList(mat_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inner_Ear__Shoes_),
	gsSPDisplayList(mat_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Inside_Hair__Eyeless___Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_1_tri_4),
	gsSPDisplayList(mat_revert_landie_alt_collar_Mouth_Dead__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_mat_override_Eyes_Blink_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_mat_override_Eyes_Closed_2[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Left_3[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Right_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Up_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_mat_override_Eyes_Look_Down_6[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Capless_Head_Switch_Option_Capless_Head_Dead_Switch_Option_Capless_Head_Dead_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Wing_DL_mesh_layer_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(landie_alt_collar_Left_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(mat_landie_alt_collar_Wing_Base),
	gsSPDisplayList(landie_alt_collar_Left_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Base),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Wing_DL_mesh_layer_4_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(landie_alt_collar_Left_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(mat_landie_alt_collar_Wing_Base),
	gsSPDisplayList(landie_alt_collar_Left_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Base),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Wing_DL_mesh_layer_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(landie_alt_collar_Right_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(mat_landie_alt_collar_Wing_Base),
	gsSPDisplayList(landie_alt_collar_Right_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Base),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Wing_DL_mesh_layer_4_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(landie_alt_collar_Right_Wing_DL_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(mat_landie_alt_collar_Wing_Base),
	gsSPDisplayList(landie_alt_collar_Right_Wing_DL_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Base),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Arm_Color_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Arm_Color_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Left_Arm_Color_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Forearm_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Left_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Forearm_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Forearm_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Left_Forearm_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Forearm_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Forearm_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_DL_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Hand_Open_Switch_Option_Left_Hand_Open_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Arm_Color_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Arm_Color_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Right_Arm_Color_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Forearm_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Right_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Forearm_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Forearm_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Forearm_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Right_Forearm_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Forearm_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Forearm_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_DL_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Open_Switch_Option_Right_Hand_Open_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Peace_Switch_Option_Right_Hand_Peace_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Cap_Switch_Option_Right_Hand_Cap_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(mat_landie_alt_collar_Cap_No_Cull),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap_No_Cull),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_2),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_1_tri_3),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Right_Hand_Wing_Cap_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4[] = {
	gsSPDisplayList(mat_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(mat_landie_alt_collar_Wing_Base),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Base),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Tip),
	gsSPDisplayList(mat_landie_alt_collar_Wing_Base),
	gsSPDisplayList(landie_alt_collar_Right_Hand_Wing_Cap_Swtich_Option_Wings_mesh_layer_4_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Wing_Base),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Thigh_Color_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Left_Thigh_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Thigh_Color_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Thigh_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Thigh_Color_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Left_Thigh_Color_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Thigh_Color_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Thigh_Color_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Leg_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Left_Leg_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Left_Leg_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Left_Leg_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Leg_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Leg_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Left_Leg_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Left_Leg_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Shoe_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Left_Shoe_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Shoe_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Shoe_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Shoe_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Left_Shoe_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Left_Shoe_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Left_Shoe_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Thigh_Color_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Right_Thigh_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Thigh_Color_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Thigh_Color_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Thigh_Color_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPDisplayList(landie_alt_collar_Right_Thigh_Color_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur_Spots__Shoes_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Thigh_Color_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Thigh_Color_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Leg_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(landie_alt_collar_Right_Leg_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Fur__Skin_),
	gsSPDisplayList(mat_landie_alt_collar_Gloves),
	gsSPDisplayList(landie_alt_collar_Right_Leg_mesh_layer_1_tri_1),
	gsSPDisplayList(mat_revert_landie_alt_collar_Gloves),
	gsSPDisplayList(mat_landie_alt_collar_Cuffs__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Leg_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cuffs__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Leg_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Leg_mesh_layer_1_tri_0),
	gsSPDisplayList(landie_alt_collar_Right_Leg_mesh_layer_1_tri_1),
	gsSPDisplayList(landie_alt_collar_Right_Leg_mesh_layer_1_tri_2),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Shoe_DL_mesh_layer_1[] = {
	gsSPDisplayList(mat_landie_alt_collar_Cap),
	gsSPDisplayList(landie_alt_collar_Right_Shoe_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Cap),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Shoe_DL_mesh_layer_1_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Shoe_DL_mesh_layer_1_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Shoe_DL_mesh_layer_5[] = {
	gsSPDisplayList(mat_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPDisplayList(landie_alt_collar_Right_Shoe_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Paw_Beans__Gloves_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_Right_Shoe_DL_mesh_layer_5_mat_override_Metal__CAP__0[] = {
	gsSPDisplayList(mat_landie_alt_collar_Metal__CAP_),
	gsSPDisplayList(landie_alt_collar_Right_Shoe_DL_mesh_layer_5_tri_0),
	gsSPDisplayList(mat_revert_landie_alt_collar_Metal__CAP_),
	gsSPEndDisplayList(),
};

Gfx landie_alt_collar_material_revert_render_settings[] = {
	gsDPPipeSync(),
	gsSPSetGeometryMode(G_LIGHTING),
	gsSPClearGeometryMode(G_TEXTURE_GEN),
	gsDPSetCombineLERP(0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT, 0, 0, 0, SHADE, 0, 0, 0, ENVIRONMENT),
	gsSPTexture(65535, 65535, 0, 0, 0),
	gsDPSetEnvColor(255, 255, 255, 255),
	gsDPSetAlphaCompare(G_AC_NONE),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, 0),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 0, 7, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP  | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(7, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 0, 0, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(0, 0, 0, 124, 124),
	gsDPSetTextureImage(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 1, 0),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b_LOAD_BLOCK, 0, 256, 6, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0, G_TX_WRAP | G_TX_NOMIRROR, 0, 0),
	gsDPLoadBlock(6, 0, 0, 1023, 256),
	gsDPSetTile(G_IM_FMT_RGBA, G_IM_SIZ_16b, 8, 256, 1, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0, G_TX_CLAMP | G_TX_NOMIRROR, 5, 0),
	gsDPSetTileSize(1, 0, 0, 124, 124),
	gsSPEndDisplayList(),
};

