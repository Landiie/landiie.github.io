-- name: [CS] \\#cbffa7\\Landie
-- description: [CS] Landie v1.0\nCustom character mod for @Landie!\n\nMade By: \\#dcd0ff\\Laventhey\n\n\\#ff7777\\This mod requires Character Select\nto use as a Library!

--[[
    API Documentation for Character Select can be found below:
    https://github.com/Squishy6094/character-select-coop/wiki/API-Documentation
]]

local TEXT_MOD_NAME = "Landie"
local TEXT_MOD_CREDIT = "Laventhey"
local TEXT_CHAR_DESC = "scree"
local CHAR_SELECT_COLOR = {r = 203, g = 255, b = 167}

-- Stops mod from loading if Character Select isn't on
if not _G.charSelectExists then
    djui_popup_create("\\#ffffdc\\\n"..TEXT_MOD_NAME.."\nRequires the Character Select Mod\nto use as a Library!\n\nPlease turn on the Character Select Mod\nand Restart the Room!", 6)
    return 0
end

local E_MODEL_LANDIE = smlua_model_util_get_id("landie_geo") -- Located in "actors"
local E_MODEL_LANDIE_COLLAR = smlua_model_util_get_id("landie_collar_geo")
local E_MODEL_LANDIE_ALT = smlua_model_util_get_id("landie_alt_geo")
local E_MODEL_LANDIE_ALT_COLLAR = smlua_model_util_get_id("landie_alt_collar_geo")

local TEX_CUSTOM_LIFE_ICON = get_texture_info("landie_icon") -- Located in "textures"
local TEX_CUSTOM_LIFE_ICON_ALT = get_texture_info("landie_collar_icon")

    -- =============================
    -- Place your ".ogg" files into the "sound" folder (might be able to use other file types maybe but ive only managed to get oggs working lol)
    -- Remove the "--" at the beginning of a sound you want to enable below and make sure the file name matches the files in "sound"
    -- You can also specify the same file for multiple sounds if ya wana otag
    -- If you want multiple sounds to play for one action at random set the file entry to something like "{'sound1.ogg', 'sound2.ogg', 'sound3.ogg'}," (you can add as many entries as you'd like and even reuse the same sound for multiple entries to make 'easter egg sounds' :3)
    -- =============================
local VOICETABLE_LANDIE = {
--    [CHAR_SOUND_OKEY_DOKEY] =        'Okey_Dokey.ogg', -- Starting game
--	[CHAR_SOUND_LETS_A_GO] =         'Letsa_Go.ogg', -- Starting level
--	[CHAR_SOUND_HERE_WE_GO] =        'Here_We_Go.ogg', -- Star get

    -- JUMPING --
--	[CHAR_SOUND_YAH_WAH_HOO] =       {'Yah.ogg', 'Wah.ogg', 'Hoo.ogg'}, -- First Jump Sounds
--	[CHAR_SOUND_HOOHOO] =            'HooHoo.ogg', -- Second jump sound
--	[CHAR_SOUND_YAHOO_WAHA_YIPPEE] = {'Yahoo.ogg', 'WaHa.ogg', 'Yippee.ogg'}, -- Triple jump sounds
--	[CHAR_SOUND_HAHA] =              'Haha.ogg', -- Landing triple jump
--	[CHAR_SOUND_YAHOO] =             'Yahoo.ogg', -- Long jump
--	[CHAR_SOUND_UH2] =               'Uh2.ogg', -- Landing after long jump
--	[CHAR_SOUND_UH2_2] =             'Uh2.ogg',
--	[CHAR_SOUND_TWIRL_BOUNCE] =      'Boing.ogg', -- Bouncing off of a flower spring

    -- ATTACKING --
--	[CHAR_SOUND_PUNCH_YAH] =         'Punch_Yah.ogg', -- Punch 1
--	[CHAR_SOUND_PUNCH_WAH] =         'Punch_Wah.ogg', -- Punch 2
--	[CHAR_SOUND_PUNCH_HOO] =         'Punch_Hoo.ogg', -- Punch 3
--	[CHAR_SOUND_GROUND_POUND_WAH] =  'Punch_Wah.ogg',
--	[CHAR_SOUND_HRMM] =              'Lifting_Something.ogg', -- Lifting something
--	[CHAR_SOUND_SO_LONGA_BOWSER] =   'So_Longay_Bowser.ogg', -- Throwing Bowser

    -- BONK --
--	[CHAR_SOUND_UH] =                'Uh.ogg', -- Wall bonk
--	[CHAR_SOUND_DOH] =               'Doh.ogg', -- Long jump wall bonk
--    [CHAR_SOUND_OOOF2] =             'Oof.ogg', -- Landing after bonking
--    [CHAR_SOUND_OOOF] =              'Oof.ogg', -- Landing in sand

    -- LEDGE/FALLING --
--	[CHAR_SOUND_WHOA] =              'Woah.ogg', -- Grabbing ledge
--	[CHAR_SOUND_EEUH] =              'Climbing_Ledge.ogg', -- Climbing over ledge
--	[CHAR_SOUND_WAAAOOOW] =          'Fall_Long.ogg', -- Falling a long distance

    -- DAMAGE --
--	[CHAR_SOUND_ATTACKED] =          'Damage.ogg', -- Damaged
--	[CHAR_SOUND_PANTING] =           'Panting.ogg', -- Low health
--	[CHAR_SOUND_ON_FIRE] =           'On_Fire.ogg', -- Burned

    -- DEATH --
--	[CHAR_SOUND_DYING] =             'Dying.ogg', -- Dying from damage
--	[CHAR_SOUND_DROWNING] =          'Drowning.ogg', -- Running out of air underwater
--	[CHAR_SOUND_MAMA_MIA] =          'Mama_Mia.ogg', -- Booted out of level

    -- SLEEP SOUNDS --
--	[CHAR_SOUND_IMA_TIRED] =         'Ima_Tired.ogg', -- Mario feeling tired
--	[CHAR_SOUND_YAWNING] =           'Yawn.ogg', -- Mario yawning before he sits down to sleep
--	[CHAR_SOUND_SNORING1] =          'Snore1.ogg', -- Snore Inhale
--	[CHAR_SOUND_SNORING2] =          'Snore2.ogg', -- Exhale
--	[CHAR_SOUND_SNORING3] =          'Snore3_Talk.ogg', -- Sleep talking / mumbling

    -- COUGHING (USED IN THE GAS MAZE) --
--	[CHAR_SOUND_COUGHING1] =         'Cough.ogg', -- Cough take 1
--	[CHAR_SOUND_COUGHING2] =         'Cough2.ogg', -- Cough take 2
--	[CHAR_SOUND_COUGHING3] =         'Cough3.ogg', -- Cough take 3

    -- OPTIONAL SOUNDS --
--    [CHAR_SOUND_HELLO] =             "Hello.ogg",
--    [CHAR_SOUND_GAME_OVER] =         "Game_Over.ogg",
--    [CHAR_SOUND_PRESS_START_TO_PLAY] = "Press_Start_to_Play.ogg"
}

-- All Located in "actors"
local CAPTABLE_CHAR = {
    normal = smlua_model_util_get_id("landie_cap_geo"),
    wing = smlua_model_util_get_id("landie_cap_wing_geo"),
    metal = smlua_model_util_get_id("landie_cap_metal_geo"),
    metalWing = smlua_model_util_get_id("landie_cap_mwing_geo")
}

local PALETTE_LANDIE = {
    [PANTS]  = "cbffa7", -- unused
    [SHIRT]  = "393837",
    [GLOVES] = "fffffe",
    [SHOES]  = "b9b99a",
    [HAIR]   = "393837",
    [SKIN]   = "ffffe2",
    [CAP]    = "cbffa7",
	[EMBLEM] = "cbffa7" -- unused
}

local PALETTE_LANDIE_COLLAR = {
    [PANTS]  = "cbffa7", -- unused
    [SHIRT]  = "bc121b",
    [GLOVES] = "fffffe",
    [SHOES]  = "b9b99a",
    [HAIR]   = "393837",
    [SKIN]   = "ffffe2",
    [CAP]    = "cbffa7",
	[EMBLEM] = "cbffa7" -- unused
}

local HM_LANDIE= {
    label = {
        left = get_texture_info("landie_hpL"),
        right = get_texture_info("landie_hpR"),
    },
    pie = {
        [1] = get_texture_info("landie_Pie1"),
        [2] = get_texture_info("landie_Pie2"),
        [3] = get_texture_info("landie_Pie3"),
        [4] = get_texture_info("landie_Pie4"),
        [5] = get_texture_info("landie_Pie5"),
        [6] = get_texture_info("landie_Pie6"),
        [7] = get_texture_info("landie_Pie7"),
        [8] = get_texture_info("landie_Pie8"),
    }
}

local CSloaded = false
local CT_LANDIE = nil
local function on_character_select_load()
    CT_LANDIE = _G.charSelect.character_add("Landie", TEXT_CHAR_DESC, TEXT_MOD_CREDIT, CHAR_SELECT_COLOR, E_MODEL_LANDIE, CT_MARIO, TEX_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_costume(CT_LANDIE, "Collared Landie", TEXT_CHAR_DESC, TEXT_MOD_CREDIT, CHAR_SELECT_COLOR, E_MODEL_LANDIE_COLLAR, CT_MARIO, TEX_CUSTOM_LIFE_ICON_ALT)
    _G.charSelect.character_add_costume(CT_LANDIE, "Landie (Eyeless)", TEXT_CHAR_DESC, TEXT_MOD_CREDIT, CHAR_SELECT_COLOR, E_MODEL_LANDIE_ALT, CT_MARIO, TEX_CUSTOM_LIFE_ICON)
    _G.charSelect.character_add_costume(CT_LANDIE, "Collared Landie (Eyeless)", TEXT_CHAR_DESC, TEXT_MOD_CREDIT, CHAR_SELECT_COLOR, E_MODEL_LANDIE_ALT_COLLAR, CT_MARIO, TEX_CUSTOM_LIFE_ICON_ALT)

    _G.charSelect.character_add_health_meter(CT_LANDIE, HM_LANDIE)
    _G.charSelect.character_add_caps(E_MODEL_LANDIE, CAPTABLE_CHAR)
    _G.charSelect.character_add_voice(E_MODEL_LANDIE, VOICETABLE_LANDIE)
    _G.charSelect.character_add_celebration_star(E_MODEL_LANDIE, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_LANDIE, PALETTE_LANDIE)

    _G.charSelect.character_add_caps(E_MODEL_LANDIE_COLLAR, CAPTABLE_CHAR)
    _G.charSelect.character_add_voice(E_MODEL_LANDIE_COLLAR, VOICETABLE_LANDIE)
    _G.charSelect.character_add_celebration_star(E_MODEL_LANDIE_COLLAR, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_LANDIE_COLLAR, PALETTE_LANDIE_COLLAR)

    _G.charSelect.character_add_caps(E_MODEL_LANDIE_ALT, CAPTABLE_CHAR)
    _G.charSelect.character_add_voice(E_MODEL_LANDIE_ALT, VOICETABLE_LANDIE)
    _G.charSelect.character_add_celebration_star(E_MODEL_LANDIE_ALT, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_LANDIE_ALT, PALETTE_LANDIE)

    _G.charSelect.character_add_caps(E_MODEL_LANDIE_ALT_COLLAR, CAPTABLE_CHAR)
    _G.charSelect.character_add_voice(E_MODEL_LANDIE_ALT_COLLAR, VOICETABLE_LANDIE)
    _G.charSelect.character_add_celebration_star(E_MODEL_LANDIE_ALT_COLLAR, E_MODEL_CUSTOM_STAR, TEX_CUSTOM_STAR_ICON)
    _G.charSelect.character_add_palette_preset(E_MODEL_LANDIE_ALT_COLLAR, PALETTE_LANDIE_COLLAR)

    CSloaded = true
end

local function on_character_sound(m, sound)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_LANDIE then return _G.charSelect.voice.sound(m, sound) end
end

local function on_character_snore(m)
    if not CSloaded then return end
    if _G.charSelect.character_get_voice(m) == VOICETABLE_LANDIE then return _G.charSelect.voice.snore(m) end
end

hook_event(HOOK_ON_MODS_LOADED, on_character_select_load)
hook_event(HOOK_CHARACTER_SOUND, on_character_sound)
hook_event(HOOK_MARIO_UPDATE, on_character_snore)
